# Link tetap selamanya (Cloudflare Tunnel bernama)

Link `trycloudflare.com` berubah tiap `npm run public` dijalankan. Untuk link yang TIDAK berubah,
pakai domain milik sendiri + Cloudflare Tunnel bernama. Gratis di sisi Cloudflare; yang berbayar hanya domain.

## A. Siapkan domain di Cloudflare (sekali)
1. Punya domain (beli di registrar mana pun, mis. .my.id atau .com).
2. Daftar gratis di dash.cloudflare.com -> Add a domain -> pilih paket Free.
3. Cloudflare memberi 2 nameserver. Ganti nameserver domain di registrar dengan keduanya.
4. Tunggu status domain "Active" (beberapa menit sampai beberapa jam).

## B. Buat tunnel (sekali)
1. Buka one.dash.cloudflare.com -> Networks -> Tunnels -> Create a tunnel -> Cloudflared.
2. Beri nama "gacoan-member", klik Save tunnel.
3. Di bagian install, pilih sistem Windows. Salin HANYA token-nya (teks panjang setelah `--token`
   atau `service install`). Jangan jalankan perintah instalasinya.
4. Klik Next, tab Public Hostname -> Add:
   - Subdomain : member
   - Domain    : domainkamu.com
   - Type      : HTTP
   - URL       : localhost:3000
5. Save. Link tetapmu: https://member.domainkamu.com

## C. Isi .env
    PUBLIC_URL=https://member.domainkamu.com
    CLOUDFLARE_TUNNEL_TOKEN=token_yang_disalin

## D. Jalankan
    taskkill /IM node.exe /F
    npm run tetap

Pakai perintah ini SAJA (bukan npm start / npm run public). Setelah muncul "LINK TETAP AKTIF",
buka /daftar-qr.html (login admin), klik Perbarui QR, lalu cetak poster. Poster tidak perlu dicetak ulang lagi.

## Catatan
- Komputer dan jendela terminal harus tetap menyala. Untuk 24 jam penuh, pasang di VPS (lihat PANDUAN bagian 8).
- Token bersifat rahasia seperti password. Jangan dibagikan.
- Backup rutin file data/gacoan.db (isi seluruh data member).
