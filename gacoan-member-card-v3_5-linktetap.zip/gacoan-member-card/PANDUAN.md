# PANDUAN LENGKAP — Kartu Member Gacoan (dari nol sampai jalan)

Panduan ini urut dari awal sampai akhir. Kerjakan berurutan. Tiap bagian bisa dites sendiri,
jadi kalau ada yang macet kamu tahu persis di bagian mana.

## Gambaran: apa yang dilakukan website ini

1. **Customer scan QR poster** (pakai data seluler / WiFi mereka sendiri) → isi form (nama, HP, **Gmail**, outlet).
2. **Kartu member langsung jadi** di HP customer, dengan tiga level:
   | Level | Syarat koin | Klaim harian | Koin dari belanja | Diskon pesanan |
   |---|---|---|---|---|
   | Silver (awal) | 0 | 20 | x1 | - |
   | Gold | 150 | 30 | x1,5 | 5% |
   | Platinum | 400 | 40 | x2 | 10% |
   Naik level otomatis. Semua aturan dan daftar keuntungan ada di satu file: **`tiers.js`**
   (ubah angka di sana, maka server, email, PDF, dan halaman Keuntungan ikut berubah).
   Koin dihitung dari jumlah yang **dibayar** (setelah diskon): 5 koin per Rp10.000, lalu dikali pengali level.
3. **Kartu dikirim ke Gmail customer**: tampil di email, ada tombol **Unduh Kartu (PDF)**, dan
   **file PDF kartu (depan + belakang) terlampir** sehingga bisa diunduh langsung dari Gmail.
   Link kartu juga dikirim lewat **WhatsApp Business** (nomor bisnis `0895-2970-5141`).
4. **Privasi:** kartu hanya bisa dibuka lewat **link pribadi** (berisi token rahasia). Daftar semua member,
   data member lain, dan poster QR **hanya bisa dibuka admin** (login password).

---

## BAGIAN 1 — Persiapan komputer (sekali saja)

1. Install **Node.js versi 22.13 atau lebih baru** (pilih LTS) dari https://nodejs.org. Cek di terminal: `node -v`.
2. Ekstrak zip project, buka foldernya di VS Code (File → Open Folder).
3. Buka Terminal di VS Code, jalankan:
   ```
   npm install
   ```
   Ini juga otomatis menyiapkan alat untuk membuat link publik (cloudflared).

## BAGIAN 2 — Buat file `.env` (pengaturan rahasia)

1. File `.env` **sudah disertakan** dan berisi password admin acak serta nomor WhatsApp bisnis.
   (Kalau hilang, salin `.env.example` menjadi `.env`.)
2. **Password admin** ada di baris `ADMIN_PASSWORD=` pada `.env`. Mau ganti dengan yang baru dan acak:
   ```
   npm run gen-password
   ```
   lalu salin hasilnya ke `ADMIN_PASSWORD`, simpan, dan restart server.
   Sebaiknya **ganti sebelum website dibuka untuk umum**, karena password awal pernah terlihat di chat.
3. Jangan pernah membagikan file `.env` (sudah otomatis tidak ikut Git).

Bagian email dan WhatsApp diisi nanti (Bagian 4 dan 6). Selama kosong, website tetap jalan, hanya
pengiriman email/WA yang dilewati.

## BAGIAN 3 — Jalankan & tes di komputer sendiri

1. `npm start`
2. Buka http://localhost:3000 → daftar sebagai member percobaan → kartu muncul (level **Silver**).
3. Login admin: http://localhost:3000/admin-login.html → masukkan `ADMIN_PASSWORD`.
   Di halaman admin kamu bisa cari member, lihat kartu mereka, dan **Kirim ulang** kartu.
4. Tes privasi: buka jendela *Incognito* → buka alamat kartu **tanpa** `&t=...` → harus muncul
   "Kartu tidak ditemukan atau link tidak valid". Itu artinya orang lain tidak bisa mengintip.

## BAGIAN 4 — Kirim kartu ke Gmail pelanggan

Kamu butuh satu akun Gmail pengirim (boleh Gmail bisnis kamu). Google tidak mengizinkan password
biasa untuk aplikasi, jadi dibuat "App Password":

1. Buka https://myaccount.google.com/security → aktifkan **Verifikasi 2 Langkah** (wajib).
2. Buka https://myaccount.google.com/apppasswords → beri nama "Gacoan Member" → **Create**.
3. Google menampilkan 16 huruf (contoh `abcd efgh ijkl mnop`). Salin.
4. Isi di `.env`:
   ```
   GMAIL_USER=emailbisnis@gmail.com
   GMAIL_APP_PASSWORD=abcdefghijklmnop
   MAIL_FROM_NAME=Gacoan Member
   ```
5. Restart server (`Ctrl+C`, lalu `npm start`). Di terminal harus muncul `✉️ Email Gmail siap`.
6. Tes: daftar dengan email pribadimu → cek inbox (dan folder **Spam** untuk pertama kali).

Isi setiap email: kartu, lampiran **PDF depan-belakang**, tombol **Unduh Kartu (PDF)** (cadangan kalau
lampiran tidak terbuka), daftar **keuntungan level** pelanggan, dan nomor WhatsApp bantuan.
Email dikirim saat **daftar**, saat **naik level**, dan saat **kirim ulang**.

Catatan:
- Akun Gmail biasa punya batas kirim harian (sekitar 500 penerima/hari). Cukup untuk skala kecil-menengah.
  Untuk volume besar, pakai layanan email khusus (mis. Brevo, Resend, atau Google Workspace).
- Mau lihat tampilan email tanpa mengirim? Login admin lalu buka
  `http://localhost:3000/api/admin/email-preview/ID-MEMBER` (contoh ID: `GCN-26-1234`).
- Email juga otomatis dikirim saat member **naik level** (Gold/Platinum).
- Pelanggan bisa mencetak: tombol **Buka & Cetak Kartu** → halaman kartu → **Cetak Kartu** → pilih printer atau *Save as PDF*.

## BAGIAN 5 — QR yang bisa discan dari data seluler / WiFi mana pun

Alamat `192.168.x.x` atau `10.x.x.x` hanya jalan di WiFi yang sama. Supaya pendaftaran mandiri terbuka
untuk **semua jaringan** (data seluler Telkomsel/XL/Indosat/dll., WiFi outlet, WiFi rumah):

1. Hapus/kosongkan `PUBLIC_URL` di `.env` (kalau ada).
2. Jalankan: `npm run public`
3. Tunggu muncul **LINK PUBLIK AKTIF** dengan alamat `https://xxxx.trycloudflare.com`.
   (Pertama kali butuh internet biasa, bisa sedikit lama.)
4. Buka http://localhost:3000/admin-login.html → login → buka http://localhost:3000/daftar-qr.html
   → pastikan kolom alamat berisi link https tadi → **Simpan** → **Perbarui QR** → **Cetak Poster**.
5. **Tes wajib:** matikan WiFi di HP, pakai data seluler, buka `link-anda/api/ping` (harus muncul `{"ok":true,...}`),
   lalu scan QR poster → form pendaftaran harus terbuka.

Yang sudah dibuat terbuka untuk semua jaringan:
- Server mendengarkan semua antarmuka (`0.0.0.0`), tidak ada daftar IP yang diizinkan atau diblokir.
- Batas anti-spam per IP sengaja **longgar** (60 pendaftaran/jam per IP, bisa diubah di `.env`),
  karena banyak pelanggan memakai satu IP yang sama (data seluler dan WiFi outlet). Pencegahan akun ganda
  tetap lewat nomor HP: satu nomor hanya bisa daftar sekali.
- Kalau tunnel terputus, `npm run public` **menyambung ulang otomatis**. Kalau link berubah, cetak ulang poster.

Penting dipahami:
- Link `trycloudflare.com` **berubah setiap kali** `npm run public` dijalankan ulang → cetak poster **setelah** link muncul.
- Komputer harus **menyala** dan jendela terminal **terbuka** selama poster dipakai.
- Ini cocok untuk **demo / tugas / uji coba**. Untuk poster permanen di outlet, lihat Bagian 8.
- Kalau QR tetap tidak terbuka: pastikan komputer punya internet, jendela `npm run public` masih terbuka,
  dan link di poster sama dengan link yang sedang tampil di terminal.

## BAGIAN 6 — WhatsApp Business: chat otomatis ke member (nomor `089529705141`)

Setelah member mendaftar, website mengirim chat WhatsApp **dari nomor bisnis 089529705141 ke nomor HP yang
dimasukkan member**, tanpa admin menekan apa pun. Chat otomatis yang dikirim:

| Kejadian | Isi chat |
|---|---|
| Member daftar | Kartu member aktif, link kartu, link PDF, keuntungan level Silver |
| "Sudah Pernah Daftar" / tombol Kirim ulang admin | Link kartu & PDF dikirim lagi |
| Klaim koin harian | Koin yang didapat, total koin, sisa koin ke level berikutnya |
| Pesan menu | Nomor pesanan, total bayar, diskon level, koin yang didapat |
| Naik level (Gold / Platinum) | Ucapan selamat + keuntungan level baru |

Semua pengiriman tercatat di **halaman admin → Daftar Member → panel "Chat WhatsApp Otomatis"** lengkap dengan
status (Terkirim ✓, Sampai ✓✓, Dibaca ✓✓, atau Gagal ✗ + alasannya). Kalau WhatsApp gagal, pendaftaran,
klaim, dan pesanan member **tetap berhasil**.

> **Penting, kode saja tidak cukup.** Mengirim chat otomatis dari nomor 089529705141 butuh izin dari
> WhatsApp. Ada dua jalur, pilih salah satu. Tanpa salah satunya, fitur chat otomatis tetap mati
> (website, kartu, Gmail, dan tombol manual tetap jalan).

| | Jalur A: Cloud API resmi Meta | Jalur B: Fonnte |
|---|---|---|
| Status | Resmi dari WhatsApp (disarankan) | Gateway pihak ketiga, **bukan** jalur resmi |
| Persiapan | Akun Meta Business, token, template disetujui (menit sampai 1x24 jam) | Daftar di fonnte.com, scan QR dengan WhatsApp nomor 089529705141 |
| Template | Wajib untuk pesan pertama ke member | Tidak perlu |
| Risiko | Rendah | WhatsApp melarang kirim otomatis lewat WhatsApp Web, nomor bisa dibatasi atau diblokir |
| Biaya | Tarif per pesan dari Meta (tergantung kategori dan negara) | Langganan bulanan Fonnte |
| Bot balas otomatis (KOIN, KARTU, dst.) | Ada | Tidak ada |
| Cocok untuk | Outlet sungguhan | Uji coba / volume kecil |

### Jalur A — WhatsApp Cloud API resmi Meta

**1. Akun & aplikasi**
1. Siapkan **Meta Business Account** (https://business.facebook.com).
2. Buka https://developers.facebook.com → **My Apps → Create App** → tipe **Business** → tambahkan produk **WhatsApp**.
3. Di **WhatsApp → API Setup** kamu mendapat nomor uji, **Phone Number ID**, dan **WhatsApp Business Account ID**.
   Mode uji hanya bisa mengirim ke maksimal 5 nomor yang didaftarkan sebagai penerima uji.

**2. Pakai nomor 089529705141**
1. Di API Setup → **Add phone number** → masukkan 089529705141 → verifikasi lewat kode SMS / telepon.
2. Nomor yang sedang aktif di aplikasi WhatsApp biasa tidak bisa langsung didaftarkan. Meta punya opsi
   memakai nomor yang sama bersama WhatsApp Business App; cek syarat terbaru di dokumentasi Meta.
3. Lakukan **Business Verification** (Meta Business Settings) supaya batas pengiriman naik dan app bisa
   dijadikan **Live**, dengan begitu chat bisa terkirim ke pelanggan mana pun, bukan hanya 5 nomor uji.
4. Salin **Phone Number ID** milik nomor 089529705141 (bukan nomor HP-nya).

**3. Token permanen**
1. Business Settings → **Users → System Users** → buat System User (role Admin).
2. **Add Assets** → pilih app kamu (Full control) dan akun WhatsApp.
3. **Generate Token** → centang `whatsapp_business_messaging` dan `whatsapp_business_management` → salin tokennya.
   (Jangan pakai token sementara 24 jam.)

**4. Isi `.env`**
```
WA_TOKEN=token-permanen-tadi
WA_PHONE_NUMBER_ID=phone-number-id-nomor-089529705141
WA_BUSINESS_ACCOUNT_ID=whatsapp-business-account-id
```

**5. Tes dulu sebelum template jadi.** Restart server, login admin, buka **Daftar Member → Chat WhatsApp Otomatis**,
isi nomor HP penerima uji → **Tes kirim**. Tes ini memakai template bawaan Meta `hello_world`, jadi bisa dipakai
untuk memastikan token dan Phone Number ID sudah benar. Kalau gagal, alasannya tampil di tabel riwayat.

**6. Daftarkan template pesan** (otomatis lewat skrip, tidak perlu mengetik manual):
```
npm run wa-setup             # kirim 4 template ke Meta untuk ditinjau
npm run wa-setup -- --status # cek: PENDING / APPROVED / REJECTED
```
Chat otomatis ke member baru berjalan setelah semua template berstatus **APPROVED** (biasanya beberapa menit
sampai 1x24 jam). Template yang dibuat: `member_baru`, `klaim_koin`, `pesanan_sukses`, `naik_level`
(kategori Utility, bahasa Indonesia). Isinya ada di `scripts/wa-setup.js`. Kalau Meta menolak, ubah teksnya
di file itu lalu jalankan lagi dengan nama template baru (atur lewat `WA_TEMPLATE_*` di `.env`).

**7. (Opsional) Bot balas otomatis + status "Dibaca"**

Dengan webhook, member yang mengetik **KOIN**, **KEUNTUNGAN**, **KARTU**, **KLAIM**, atau **MENU** ke
089529705141 langsung dibalas otomatis. Nomor yang belum terdaftar dibalas link pendaftaran. Status Sampai
dan Dibaca juga masuk ke riwayat. Webhook tidak diperlukan untuk **mengirim** chat; ini hanya tambahan.
1. Isi `.env`: `WA_APP_SECRET` (Meta for Developers → App → Settings → Basic → App Secret). `WA_VERIFY_TOKEN`
   sudah terisi otomatis, atau ganti dengan karangan sendiri.
2. Di Meta: **WhatsApp → Configuration → Webhook → Edit**:
   - Callback URL: `https://alamat-publik-anda/webhook/whatsapp`
   - Verify token: isi sama dengan `WA_VERIFY_TOKEN` di `.env`
   - Klik **Verify and save**, lalu **Subscribe** pada field `messages`.
3. Restart server, terminal akan menampilkan `Balasan otomatis (bot): AKTIF`.

Alamat `trycloudflare.com` berubah setiap `npm run public` dijalankan ulang, sehingga webhook harus didaftarkan
ulang. Untuk webhook yang stabil pakai alamat tetap (Bagian 8).

### Jalur B — Fonnte (tanpa Meta, cepat untuk uji coba)
1. Daftar di https://fonnte.com → **Add Device** → masukkan nomor 089529705141 → scan QR dengan WhatsApp
   di HP yang memegang nomor itu sampai statusnya *Connected*.
2. Salin **token device**, lalu isi `.env`:
   ```
   FONNTE_TOKEN=token-device
   ```
3. Kosongkan `WA_TOKEN` dan `WA_PHONE_NUMBER_ID` (atau tambahkan `WA_PROVIDER=fonnte`), restart server, lalu
   coba **Tes kirim** di panel admin.
4. Karena pesan dikirim lewat sesi WhatsApp Web, HP harus tetap terhubung internet. Jangan kirim promosi massal.

### Kotak Masuk: admin membalas chat customer langsung dari website
Setelah customer mendapat chat otomatis (kartu baru, klaim, dst.) lalu **membalas**, pesannya masuk ke halaman
**`/inbox.html`** (atau tombol "📥 Kotak Masuk WhatsApp" di halaman daftar member, lengkap dengan lencana jumlah pesan baru).
Admin membaca dan membalas di situ, tanpa membuka WhatsApp di HP. Isi halaman diperbarui otomatis tiap beberapa detik.

Syarat: webhook harus aktif supaya chat masuk dari customer sampai ke website.
- **Jalur A (Meta):** `WA_APP_SECRET` + `WA_VERIFY_TOKEN` terisi dan webhook didaftarkan (langkah di atas).
- **Jalur B (Fonnte):** tambahkan di `.env` satu baris `FONNTE_WEBHOOK_KEY=karangan-panjang-dan-acak`, restart server,
  lalu di fonnte.com buka **Device → Webhook** dan isi `https://alamat-publik-anda/webhook/fonnte?key=ISI_KUNCI_YANG_SAMA`.
  Kalau kolom webhook Fonnte punya pilihan jenis kiriman, pilih JSON atau Form, keduanya dikenali.
- Terminal akan menampilkan `Kotak masuk admin: AKTIF`.

Aturan penting:
- **Cloud API Meta:** balasan teks bebas hanya boleh dalam **24 jam** sejak customer terakhir chat (aturan Meta).
  Lewat dari itu, kotak balasan terkunci dan muncul keterangannya. Pakai tombol **Kirim ulang** (template) atau tunggu
  customer chat lagi. Fonnte tidak punya batas 24 jam.
- **Bot dan admin tidak saling menyerobot.** Mode bawaan `WA_BOT_MODE=keyword`: bot hanya menjawab kata kunci
  (KOIN, KARTU, KEUNTUNGAN, KLAIM, MENU, BANTUAN). Pertanyaan bebas dibiarkan untuk admin. Begitu admin membalas satu
  nomor, bot diam untuk nomor itu selama `WA_BOT_PAUSE_HOURS` (12 jam). Mau bot menjawab semuanya seperti dulu: `WA_BOT_MODE=auto`.
  Mau bot mati total: `WA_BOT_MODE=off`.
- Halaman ini khusus admin (wajib login). Foto dan dokumen dari customer tampil sebagai keterangan jenisnya
  (mis. `[Foto]`), isi filenya dibuka di aplikasi WhatsApp.

### Cadangan manual (selalu jalan, tanpa API)
- Tombol hijau **Chat WhatsApp** di semua halaman, nomor bantuan di kartu PDF dan email.
- Tombol **WA** per member di halaman admin: membuka WhatsApp dengan pesan siap kirim berisi link kartu dan PDF.
  Pengirimnya akun WhatsApp Business yang sedang login di perangkat admin, jadi login dulu dengan nomor 089529705141.

## BAGIAN 7 — Cara kerja privasi (supaya kamu bisa menjelaskannya)

- Setiap member punya **token acak** yang hanya ada di link kartunya. ID member (`GCN-26-1234`) mudah ditebak,
  jadi ID saja **tidak cukup** untuk membuka kartu.
- Token dikirim ke email & WhatsApp pemilik, dan disimpan di HP-nya setelah daftar.
- "Lupa kartu?" → customer memasukkan No. HP → link **dikirim ulang ke email/WA yang terdaftar**
  (kartu tidak ditampilkan di layar). Jawaban website selalu sama, jadi orang iseng tidak bisa mengecek
  siapa yang sudah jadi member.
- **Hanya admin** (login password) yang bisa: melihat daftar semua member, membuka kartu siapa pun,
  melihat No. HP/email member, kirim ulang kartu, dan mencetak poster.
- Perlindungan lain: batas pendaftaran per jaringan, batas percobaan login admin, batas kirim email per alamat,
  semua teks dari form di-escape (nama berisi kode berbahaya tidak akan dijalankan), dan header
  `no-referrer` supaya token tidak bocor ke situs lain.
- Keterbatasan jujur: siapa pun yang memegang link kartu (mis. kamu forward emailnya) bisa membukanya.
  Untuk sistem sungguhan sebaiknya tambah verifikasi OTP WhatsApp saat daftar. Karena kamu menyimpan data
  pribadi pelanggan, sebaiknya tambahkan teks persetujuan data (UU PDP) di form.

## BAGIAN 8 — Supaya poster permanen (opsional, untuk pemakaian sungguhan)

Link `trycloudflare.com` berubah-ubah. Untuk alamat tetap, pilih salah satu:

1. **VPS + domain sendiri** (paling stabil): sewa VPS, install Node 22.13+, upload project, isi
   `PUBLIC_URL=https://member.domainkamu.com` di `.env`, jalankan `npm start` dengan PM2, pasang HTTPS (Caddy/Nginx).
   Database ada di file `data/gacoan.db` → **backup rutin**.
2. **Cloudflare Tunnel bernama** (komputer tetap di outlet): butuh domain yang DNS-nya di Cloudflare; tunnel
   mendapat alamat tetap. Isi `PUBLIC_URL` dan `CLOUDFLARE_TUNNEL_TOKEN` di `.env`, lalu jalankan **`npm run tetap`**
   (bukan `npm start` atau `npm run public`). Langkah lengkap: **LINK-TETAP.md**.
3. **Hosting Node.js (Render/Railway/dll.):** pastikan memakai *persistent disk*, karena database SQLite
   adalah file. Tanpa disk permanen, data member bisa hilang saat server restart.

## BAGIAN 9 — Daftar periksa sebelum dipakai pelanggan

- [ ] `npm run public` berjalan dan link publik muncul
- [ ] QR poster dites dari HP dengan **data seluler** (WiFi mati)
- [ ] Daftar → kartu tampil → email masuk (cek Spam) → **lampiran PDF bisa diunduh dari Gmail** → tombol cetak berfungsi
- [ ] Tombol **Chat WhatsApp** membuka chat ke 0895-2970-5141
- [ ] Panel **Chat WhatsApp Otomatis** di halaman admin: **Tes kirim** ke HP sendiri berhasil
- [ ] Daftar sebagai member baru dengan nomor HP lain: chat kartu masuk otomatis, status di riwayat Terkirim / Sampai
- [ ] (Jalur A) `npm run wa-setup -- --status` menampilkan semua template **APPROVED**
- [ ] Login admin → tombol **WA** pada daftar member membuka WhatsApp dengan pesan terisi
- [ ] Akun Gold (atau Platinum) mendapat **diskon** saat Pesan Menu
- [ ] WhatsApp masuk (mode uji: ke nomor penerima uji)
- [ ] Tes Incognito: link kartu tanpa `&t=` ditolak
- [ ] `members.html` tanpa login diarahkan ke halaman login
- [ ] Password admin sudah diganti dengan `npm run gen-password`, file `.env` tidak dibagikan, `data/gacoan.db` sudah di-backup

## Masalah umum

| Gejala | Penyebab / solusi |
|---|---|
| `node:sqlite` tidak dikenali | Node terlalu lama. Update ke 22.13+ |
| "Admin belum aktif" saat login | `ADMIN_PASSWORD` kosong atau kurang dari 8 karakter di `.env`, lalu restart |
| Log "Login Gmail gagal" | Verifikasi 2 Langkah belum aktif, atau yang dipakai bukan App Password |
| Email masuk Spam | Wajar untuk email pertama dari akun baru. Tandai "Bukan spam" |
| Email terkirim tanpa lampiran PDF | Lihat log terminal "PDF kartu gagal dibuat". Tombol Unduh Kartu (PDF) di email tetap bisa dipakai |
| Tombol WA admin tidak membuka apa-apa | Izinkan pop-up untuk situs ini di browser |
| Kotak Masuk kosong padahal customer sudah membalas | Webhook belum aktif atau salah alamat. Cek log terminal "Kotak masuk admin: AKTIF" dan daftarkan ulang webhook (alamat trycloudflare berubah tiap restart) |
| Kotak balasan terkunci | Cloud API: sudah lewat 24 jam sejak customer terakhir chat. Tunggu customer chat lagi atau kirim ulang kartu (template) |
| Bot ikut membalas padahal admin sedang menjawab | Bot diam setelah admin membalas satu nomor. Atur `WA_BOT_MODE=off` kalau mau bot mati total |
| WA error "template" | Template belum disetujui, atau nama berbeda dari `member_baru` dkk. |
| QR tidak terbuka di data seluler | Pakai `npm run public`, bukan alamat IP. Pastikan terminal tidak ditutup |
| Poster lama tidak jalan lagi | Link trycloudflare berubah saat restart. Cetak ulang atau pakai alamat tetap (Bagian 8) |
