# Kartu Member Gacoan — Tugas CRM

Website pendaftaran member dengan kartu **Silver / Gold / Platinum**, pendaftaran mandiri lewat **QR** (data seluler / WiFi mana saja),
kartu dikirim ke **Gmail** pelanggan (**lampiran PDF**, bisa diunduh langsung), **WhatsApp Business** (nomor 0895-2970-5141),
keuntungan per level + **diskon** Gold/Platinum, dan **privasi**: kartu hanya bisa dibuka pemiliknya
(lewat link pribadi) atau admin.

👉 **Mulai dari [PANDUAN.md](PANDUAN.md)** — langkah dari awal sampai akhir.

## Ringkas

```bash
npm install            # sekali saja
# file .env sudah disertakan (berisi password admin acak). Kalau hilang: cp .env.example .env
npm run gen-password   # buat password admin acak (lalu salin ke ADMIN_PASSWORD di .env)
npm start              # lokal:  http://localhost:3000
npm run wa-setup       # daftarkan template WhatsApp ke Meta (npm run wa-setup -- --status untuk cek)
npm run public         # link publik https untuk QR (data seluler / WiFi mana pun, tersambung ulang otomatis)
```

| Halaman | Siapa | Keterangan |
|---|---|---|
| `/` , `/scan.html` | Publik | Pendaftaran / gerbang QR |
| `/card.html?id=..&t=..` | Pemilik kartu (token) atau admin | Kartu depan-belakang + cetak |
| `/claim.html`, `/menu.html` | Pemilik (token) | Klaim koin, pesan menu |
| `/admin-login.html` | Admin | Login |
| `/api/card-pdf/ID?t=..` | Pemilik kartu (token) atau admin | Unduh kartu PDF |
| `/members.html`, `/daftar-qr.html` | **Admin saja** | Daftar member (tombol Kirim ulang dan WA), poster QR |
| `/inbox.html` | **Admin saja** | Kotak Masuk WhatsApp: baca dan balas chat customer langsung (butuh webhook, lihat PANDUAN Bagian 6) |

## Struktur

```
server.js      API + menu
tiers.js       aturan level + keuntungan + diskon (ubah di sini)
cardpdf.js     pembuat PDF kartu depan-belakang
auth.js        login admin, token member, pembatas permintaan
db.js          database SQLite (data/gacoan.db)
mailer.js      kirim kartu + lampiran PDF ke Gmail (nodemailer)
whatsapp.js    chat WA otomatis ke member (Cloud API Meta / Fonnte), log status, webhook
wabot.js       balasan otomatis WhatsApp (KOIN, KARTU, KEUNTUNGAN, dst.)
scripts/       gen-password.js (pembuat password admin)
tunnel.js      link publik (cloudflared) untuk `npm run public`
public/        halaman website (HTML/CSS/JS)
.env.example   contoh pengaturan rahasia
```

Data member ada di `data/gacoan.db` — **backup file ini secara rutin**.

## Link tetap (tidak berubah)

Pakai `npm run tetap` dengan domain sendiri + Cloudflare Tunnel. Lihat **LINK-TETAP.md**.
