// ---------- Keamanan: login admin, token member, pembatas permintaan ----------
// Aturan akses (inti permintaan "kartu member orang lain hanya bisa dilihat admin"):
//   - Member biasa  : hanya bisa membuka kartu MILIKNYA, lewat link yang berisi token rahasia
//                     (dikirim ke email / WhatsApp-nya). Tebak ID saja tidak cukup.
//   - Admin         : login dengan ADMIN_PASSWORD (di file .env), lalu bisa melihat semua member.
const crypto = require("crypto");
const store = require("./db");

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "";
const ADMIN_ENABLED = ADMIN_PASSWORD.length >= 8;
const COOKIE_NAME = "gc_admin";
const SESSION_HOURS = 12;

// Kunci penanda cookie. Dibuat acak sekali, disimpan di database supaya login tidak
// terhapus saat server di-restart.
function getSecret() {
  let secret = store.getConfig("sessionSecret");
  if (!secret) {
    secret = crypto.randomBytes(32).toString("hex");
    store.setConfig("sessionSecret", secret);
  }
  return secret;
}
const SECRET = getSecret();

function sign(value) {
  return crypto.createHmac("sha256", SECRET).update(value).digest("base64url");
}

function safeEqual(a, b) {
  const ha = crypto.createHash("sha256").update(String(a)).digest();
  const hb = crypto.createHash("sha256").update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}

function parseCookies(req) {
  const out = {};
  const header = req.headers.cookie || "";
  header.split(";").forEach((part) => {
    const i = part.indexOf("=");
    if (i === -1) return;
    out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  });
  return out;
}

function isAdmin(req) {
  if (!ADMIN_ENABLED) return false;
  const raw = parseCookies(req)[COOKIE_NAME];
  if (!raw) return false;
  const [expires, sig] = raw.split(".");
  if (!expires || !sig) return false;
  if (!safeEqual(sig, sign(expires))) return false;
  return Number(expires) > Date.now();
}

function setAdminCookie(req, res) {
  const expires = String(Date.now() + SESSION_HOURS * 3600 * 1000);
  const value = `${expires}.${sign(expires)}`;
  const secure = req.secure ? "; Secure" : "";
  res.setHeader(
    "Set-Cookie",
    `${COOKIE_NAME}=${encodeURIComponent(value)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_HOURS * 3600}${secure}`
  );
}

function clearAdminCookie(res) {
  res.setHeader("Set-Cookie", `${COOKIE_NAME}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0`);
}

function checkAdminPassword(input) {
  return ADMIN_ENABLED && safeEqual(input || "", ADMIN_PASSWORD);
}

// Middleware: hanya admin
function requireAdmin(req, res, next) {
  if (isAdmin(req)) return next();
  res.status(401).json({ error: "Khusus admin. Silakan login dulu.", needLogin: true });
}

// ---------- Token member ----------
function newToken() {
  return crypto.randomBytes(18).toString("base64url");
}

function tokenFromRequest(req) {
  return String(req.query.t || (req.body && req.body.t) || req.headers["x-member-token"] || "");
}

// Kembalikan member kalau: admin sedang login, ATAU token cocok. Selain itu null.
function authorizeMember(req, id) {
  const member = store.findMemberById(id);
  if (!member) return null;
  if (isAdmin(req)) return member;
  const t = tokenFromRequest(req);
  if (t && member.token && safeEqual(t, member.token)) return member;
  return null;
}

// ---------- Pembatas permintaan (anti spam / tebak password) ----------
const buckets = new Map();

// Alamat asli pengunjung untuk pembatas permintaan.
// Header cf-connecting-ip / x-forwarded-for HANYA dipercaya kalau permintaan datang lewat proxy:
// tunnel cloudflared (menyambung dari komputer ini sendiri) atau hosting yang diberi
// TRUST_PROXY_HEADERS=true. Kalau tidak, header itu bisa dipalsukan penyerang supaya lolos dari batas.
const TRUST_PROXY_HEADERS = /^(1|true|yes)$/i.test(process.env.TRUST_PROXY_HEADERS || "");
function clientKey(req) {
  const remote = String(req.socket.remoteAddress || "unknown").replace(/^::ffff:/, "");
  const viaLocalProxy = remote === "127.0.0.1" || remote === "::1";
  if (viaLocalProxy || TRUST_PROXY_HEADERS) {
    const cf = req.headers["cf-connecting-ip"];
    if (cf) return String(cf).trim();
    const xff = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim();
    if (xff) return xff;
  }
  return remote;
}

// true = masih boleh, false = sudah kena batas
function hit(name, key, max, windowMs) {
  const now = Date.now();
  const k = `${name}:${key}`;
  const arr = (buckets.get(k) || []).filter((t) => now - t < windowMs);
  if (arr.length >= max) {
    buckets.set(k, arr);
    return false;
  }
  arr.push(now);
  buckets.set(k, arr);
  return true;
}

setInterval(() => {
  const now = Date.now();
  for (const [k, arr] of buckets) {
    const fresh = arr.filter((t) => now - t < 3600 * 1000);
    if (fresh.length) buckets.set(k, fresh);
    else buckets.delete(k);
  }
}, 10 * 60 * 1000).unref();

module.exports = {
  ADMIN_ENABLED,
  isAdmin,
  requireAdmin,
  setAdminCookie,
  clearAdminCookie,
  checkAdminPassword,
  newToken,
  tokenFromRequest,
  authorizeMember,
  clientKey,
  hit,
};
