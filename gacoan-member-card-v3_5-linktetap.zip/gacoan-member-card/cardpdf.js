// ---------- PDF Kartu Member (halaman 1 = depan, halaman 2 = belakang) ----------
// Dipakai di dua tempat:
//   1. Lampiran email Gmail, jadi pelanggan tinggal tekan ikon unduh di Gmail.
//   2. Tombol "Unduh Kartu (PDF)" di halaman kartu (/api/card-pdf/:id).
// Memakai pdfkit (murni JavaScript, tanpa browser/Chrome), jadi ringan dan jalan di mana saja.
// Ukuran halaman memakai rasio kartu bank (85,6 x 54 mm) sehingga enak dilihat di HP
// dan bisa dicetak "fit to page".
const PDFDocument = require("pdfkit");
const QRCode = require("qrcode");
const whatsapp = require("./whatsapp");

const W = 486; // lebar halaman (pt)
const H = 306; // tinggi halaman (pt)
const GOLD = "#E8B84B";

// Warna gradien tiap level (sama dengan tampilan kartu di website)
const STYLE = {
  Silver:   { stops: ["#5c6166", "#9aa1a8", "#3d4044"],            accent: "#eef1f3", pill: "#ffffff" },
  Gold:     { stops: ["#4a3a0a", "#caa23a", "#8a6a14"],            accent: "#fff3cf", pill: "#ffeaa8" },
  Platinum: { stops: ["#0e1a24", "#1f3b52", "#3f6f8f", "#0e1a24"], accent: "#d6f1ff", pill: "#9fdcff" },
};

function formatDate(iso) {
  return new Date(iso).toLocaleDateString("id-ID", { day: "2-digit", month: "long", year: "numeric" });
}

// Pdfkit memakai font standar (Helvetica) yang tidak punya emoji, jadi teks dibersihkan
// dari karakter di luar Latin supaya tidak muncul kotak kosong.
function clean(text) {
  return String(text == null ? "" : text).replace(/[^\x20-\x7E\u00A0-\u00FF]/g, "").trim();
}

function paintBackground(doc, st) {
  const g = doc.linearGradient(0, 0, W, H);
  st.stops.forEach((c, i) => g.stop(i / (st.stops.length - 1), c));
  doc.rect(0, 0, W, H).fill(g);

  // Hiasan lingkaran transparan supaya kartu tidak terlihat polos
  doc.save();
  doc.fillOpacity(0.07).fillColor("#ffffff");
  doc.circle(W - 40, 20, 120).fill();
  doc.circle(40, H + 10, 90).fill();
  doc.restore();
}

// Logo teks: GA (putih) CO (emas) AN (putih) + "MIE PEDAS"
function paintLogo(doc, x, y, size) {
  doc.font("Helvetica-Bold").fontSize(size);
  doc.fillColor("#ffffff").text("GA", x, y, { continued: true, characterSpacing: 2 });
  doc.fillColor(GOLD).text("CO", { continued: true, characterSpacing: 2 });
  doc.fillColor("#ffffff").text("AN", { characterSpacing: 2 });
  doc.font("Helvetica-Bold").fontSize(Math.max(6, size * 0.3)).fillColor(GOLD);
  doc.text("MIE PEDAS", x + 1, y + size + 1, { characterSpacing: 3.5 });
}

function paintFront(doc, member, st, qrPng) {
  paintBackground(doc, st);
  paintLogo(doc, 30, 26, 28);

  // Lencana level di kanan atas
  const label = member.tier.toUpperCase();
  doc.font("Helvetica-Bold").fontSize(12);
  const pillW = doc.widthOfString(label, { characterSpacing: 1.5 }) + 30;
  const pillX = W - 30 - pillW;
  doc.save().fillOpacity(0.25).roundedRect(pillX, 28, pillW, 26, 13).fill(st.pill).restore();
  doc.fillColor("#ffffff").text(label, pillX, 35, { width: pillW, align: "center", characterSpacing: 1.5 });

  // Nama (diperkecil otomatis kalau panjang)
  const name = clean(member.name);
  let size = 30;
  doc.font("Helvetica-Bold");
  while (size > 14 && doc.fontSize(size).widthOfString(name) > W - 60 - 110) size -= 1;
  doc.fillColor("#ffffff").fontSize(size).text(name, 30, 128, { width: W - 60 - 110, lineBreak: false });

  doc.font("Courier-Bold").fontSize(17).fillColor(st.accent);
  doc.text(member.id, 30, 128 + size + 8, { characterSpacing: 2.5 });

  // Info bawah
  doc.font("Helvetica").fontSize(11).fillColor("#ffffff");
  const info = [
    `Bergabung: ${formatDate(member.joinDate)}`,
    `Outlet: ${clean(member.location) || "-"}`,
    `Koin: ${member.koin || 0}`,
  ];
  info.forEach((line, i) => doc.text(line, 30, H - 82 + i * 17, { width: 290, lineBreak: false }));

  // QR (kotak putih supaya mudah discan)
  const box = 104;
  const qx = W - 30 - box;
  const qy = H - 30 - box;
  doc.roundedRect(qx, qy, box, box, 10).fill("#ffffff");
  doc.image(qrPng, qx + 7, qy + 7, { width: box - 14, height: box - 14 });
}

function paintBack(doc, member, st) {
  paintBackground(doc, st);
  paintLogo(doc, 30, 22, 20);

  doc.font("Helvetica-Bold").fontSize(12).fillColor(st.accent);
  doc.text("SYARAT & KETENTUAN", 30, 76, { characterSpacing: 1.2 });

  const terms = [
    "Kartu ini milik pribadi dan tidak dapat dipindahtangankan.",
    "Scan QR di depan kartu untuk klaim koin harian, promo, dan pesan menu.",
    "Kartu hilang? Minta kirim ulang lewat halaman pendaftaran atau hubungi WhatsApp di bawah.",
    "Berlaku di seluruh outlet Gacoan.",
  ];
  doc.font("Helvetica").fontSize(10).fillColor("#ffffff");
  doc.y = 96;
  terms.forEach((t) => {
    doc.text(`\u2022  ${t}`, 30, doc.y, { width: W - 60, lineGap: 2 });
    doc.moveDown(0.35);
  });

  // Tanda tangan + kontak WhatsApp
  const ly = H - 52;
  doc.save().strokeColor("#ffffff").strokeOpacity(0.7).lineWidth(0.8).moveTo(30, ly).lineTo(200, ly).stroke().restore();
  doc.font("Helvetica").fontSize(8.5).fillColor("#ffffff").text("Tanda Tangan Member", 30, ly + 4);

  doc.font("Helvetica-Bold").fontSize(9).fillColor(st.accent);
  doc.text("Bantuan & info promo (WhatsApp)", 250, ly - 12, { width: W - 280, align: "right" });
  doc.font("Helvetica-Bold").fontSize(14).fillColor("#ffffff");
  doc.text(whatsapp.BUSINESS_DISPLAY, 250, ly + 2, { width: W - 280, align: "right" });
}

// Hasil: Promise<Buffer> berisi file PDF
async function buildCardPdf(member, urls) {
  const st = STYLE[member.tier] || STYLE.Silver;
  const qrPng = await QRCode.toBuffer(urls.claimUrl, { width: 300, margin: 1, errorCorrectionLevel: "M" });

  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({
      size: [W, H],
      margin: 0,
      info: {
        Title: `Kartu Member Gacoan - ${clean(member.name)}`,
        Author: "Gacoan Member",
        Subject: `Kartu member level ${member.tier}`,
      },
    });
    const chunks = [];
    doc.on("data", (c) => chunks.push(c));
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);

    paintFront(doc, member, st, qrPng);
    doc.addPage({ size: [W, H], margin: 0 });
    paintBack(doc, member, st);
    doc.end();
  });
}

module.exports = { buildCardPdf };
