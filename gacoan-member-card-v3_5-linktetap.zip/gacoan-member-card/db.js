// ---------- Database SQL (SQLite) ----------
// Memakai modul node:sqlite yang sudah built-in di Node.js 22+, jadi TIDAK perlu
// compiler/Visual Studio Build Tools seperti library SQL lain (better-sqlite3, dll).
// Kalau nanti proyek ini dipindah ke MySQL/PostgreSQL, cukup ganti isi file ini saja;
// seluruh server.js tetap memanggil fungsi-fungsi yang sama (readMembers, saveMember, dst).
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const { DatabaseSync } = require("node:sqlite");

const DB_FILE = path.join(__dirname, "data", "gacoan.db");
fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });

const db = new DatabaseSync(DB_FILE);
db.exec("PRAGMA foreign_keys = ON;");

db.exec(`
  CREATE TABLE IF NOT EXISTS members (
    id         TEXT PRIMARY KEY,
    name       TEXT NOT NULL,
    phone      TEXT NOT NULL,
    email      TEXT DEFAULT '',
    location   TEXT DEFAULT '',
    joinDate   TEXT NOT NULL,
    tier       TEXT NOT NULL,
    koin       INTEGER NOT NULL DEFAULT 0,
    lastClaim  TEXT
  );

  CREATE TABLE IF NOT EXISTS orders (
    id         TEXT PRIMARY KEY,
    memberId   TEXT NOT NULL REFERENCES members(id),
    items      TEXT NOT NULL,   -- disimpan sebagai JSON text: [{id,name,price,qty}]
    total      INTEGER NOT NULL,
    koinEarned INTEGER NOT NULL,
    createdAt  TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS config (
    key   TEXT PRIMARY KEY,
    value TEXT
  );

  CREATE INDEX IF NOT EXISTS idx_orders_memberId ON orders(memberId);
`);

// ---------- Migrasi satu kali dari data lama (members.json / orders.json) ----------
// Kalau kamu sebelumnya sudah punya data di file JSON, data itu otomatis
// dipindahkan ke database SQL saat pertama kali server dijalankan dengan versi ini.
function migrateFromJsonIfNeeded() {
  const row = db.prepare("SELECT COUNT(*) AS n FROM members").get();
  if (row.n > 0) return; // sudah ada data di DB, tidak perlu migrasi lagi

  const membersJsonPath = path.join(__dirname, "data", "members.json");
  const ordersJsonPath = path.join(__dirname, "data", "orders.json");

  if (fs.existsSync(membersJsonPath)) {
    try {
      const members = JSON.parse(fs.readFileSync(membersJsonPath, "utf-8"));
      const insert = db.prepare(`
        INSERT OR IGNORE INTO members (id, name, phone, email, location, joinDate, tier, koin, lastClaim)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      for (const m of members) {
        insert.run(m.id, m.name, m.phone, m.email || "", m.location || "", m.joinDate, m.tier, m.koin || 0, m.lastClaim || null);
      }
      if (members.length) console.log(`🗄️  Migrasi ${members.length} member dari members.json ke database SQL.`);
    } catch (e) {
      console.error("Gagal migrasi members.json:", e.message);
    }
  }

  if (fs.existsSync(ordersJsonPath)) {
    try {
      const orders = JSON.parse(fs.readFileSync(ordersJsonPath, "utf-8"));
      const insert = db.prepare(`
        INSERT OR IGNORE INTO orders (id, memberId, items, total, koinEarned, createdAt)
        VALUES (?, ?, ?, ?, ?, ?)
      `);
      for (const o of orders) {
        insert.run(o.id, o.memberId, JSON.stringify(o.items || []), o.total, o.koinEarned, o.createdAt);
      }
      if (orders.length) console.log(`🗄️  Migrasi ${orders.length} pesanan dari orders.json ke database SQL.`);
    } catch (e) {
      console.error("Gagal migrasi orders.json:", e.message);
    }
  }
}

migrateFromJsonIfNeeded();

// ---------- Migrasi: kolom "token" (kunci rahasia per member) ----------
// ID member (GCN-26-1234) mudah ditebak. Supaya kartu orang lain TIDAK bisa dibuka
// hanya dengan menebak ID, setiap member punya token acak yang hanya ada di link
// kartu miliknya (dikirim ke email / WhatsApp-nya). Tanpa token -> hanya admin yang bisa lihat.
function ensureTokenColumn() {
  const cols = db.prepare("PRAGMA table_info(members)").all().map((c) => c.name);
  if (!cols.includes("token")) db.exec("ALTER TABLE members ADD COLUMN token TEXT");
  const missing = db.prepare("SELECT id FROM members WHERE token IS NULL OR token = ''").all();
  const upd = db.prepare("UPDATE members SET token = ? WHERE id = ?");
  for (const r of missing) upd.run(crypto.randomBytes(18).toString("base64url"), r.id);
  if (missing.length) console.log(`🔑 Token dibuat untuk ${missing.length} member lama.`);
}
ensureTokenColumn();

// ---------- Migrasi: kolom "discount" (diskon level Gold/Platinum per pesanan) ----------
// Kolom "total" = jumlah yang DIBAYAR (sudah dipotong diskon). Pesanan lama otomatis discount = 0.
function ensureDiscountColumn() {
  const cols = db.prepare("PRAGMA table_info(orders)").all().map((c) => c.name);
  if (!cols.includes("discount")) db.exec("ALTER TABLE orders ADD COLUMN discount INTEGER NOT NULL DEFAULT 0");
}
ensureDiscountColumn();

// ---------- Log pengiriman WhatsApp ----------
// Setiap pesan otomatis dicatat: terkirim / gagal (beserta alasannya) / sudah sampai / sudah dibaca,
// supaya admin tahu pasti apakah member benar-benar menerima chat dari nomor WhatsApp Business.
db.exec(`
  CREATE TABLE IF NOT EXISTS wa_log (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    createdAt     TEXT NOT NULL,
    memberId      TEXT,
    phone         TEXT NOT NULL,
    kind          TEXT NOT NULL,       -- welcome | resend | claim | order | tier_up | bot | test
    provider      TEXT NOT NULL,       -- cloud | fonnte
    status        TEXT NOT NULL,       -- queued | sent | delivered | read | failed
    error         TEXT,
    providerMsgId TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_wa_log_msgid ON wa_log(providerMsgId);
  CREATE INDEX IF NOT EXISTS idx_wa_log_created ON wa_log(createdAt);
`);

function addWaLog(entry) {
  const r = db.prepare(`
    INSERT INTO wa_log (createdAt, memberId, phone, kind, provider, status, error, providerMsgId)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    new Date().toISOString(), entry.memberId || null, String(entry.phone || ""), entry.kind, entry.provider,
    entry.status || "queued", entry.error || null, entry.providerMsgId || null
  );
  return Number(r.lastInsertRowid);
}

function updateWaLog(id, fields) {
  db.prepare("UPDATE wa_log SET status = ?, error = ?, providerMsgId = COALESCE(?, providerMsgId) WHERE id = ?")
    .run(fields.status, fields.error || null, fields.providerMsgId || null, id);
}

// Status dari webhook Meta (sent -> delivered -> read, atau failed). Status tidak boleh "mundur".
const STATUS_RANK = { queued: 0, sent: 1, delivered: 2, read: 3, failed: 4 };
function updateWaStatusByMsgId(providerMsgId, status, error) {
  updateChatStatusByMsgId(providerMsgId, status, error); // ikut memperbarui centang di kotak masuk admin
  const row = db.prepare("SELECT id, status FROM wa_log WHERE providerMsgId = ?").get(providerMsgId);
  if (!row) return false;
  if (status !== "failed" && (STATUS_RANK[status] ?? 0) <= (STATUS_RANK[row.status] ?? 0)) return true;
  db.prepare("UPDATE wa_log SET status = ?, error = ? WHERE id = ?").run(status, error || null, row.id);
  return true;
}

// ---------- Kotak masuk WhatsApp (percakapan admin <-> customer) ----------
// wa_chat  : setiap pesan, masuk (customer) maupun keluar (admin / bot / sistem).
// wa_convo : ringkasan satu percakapan per nomor HP (pesan terakhir, jumlah belum dibaca, kapan
//            customer terakhir chat, kapan admin terakhir membalas).
// Nomor HP selalu disimpan dalam format lokal (08xxxxxxxxxx) supaya satu orang = satu percakapan.
db.exec(`
  CREATE TABLE IF NOT EXISTS wa_chat (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    createdAt     TEXT NOT NULL,
    phone         TEXT NOT NULL,
    memberId      TEXT,
    direction     TEXT NOT NULL,       -- in | out
    sender        TEXT NOT NULL,       -- customer | admin | bot | system
    body          TEXT NOT NULL,
    status        TEXT,                -- khusus pesan keluar: queued | sent | delivered | read | failed
    error         TEXT,
    providerMsgId TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_wa_chat_phone ON wa_chat(phone, id);
  CREATE INDEX IF NOT EXISTS idx_wa_chat_msgid ON wa_chat(providerMsgId);
  -- Meta kadang mengirim webhook yang sama dua kali: pesan masuk dengan ID sama hanya dicatat sekali.
  CREATE UNIQUE INDEX IF NOT EXISTS idx_wa_chat_in_unique
    ON wa_chat(providerMsgId) WHERE direction = 'in' AND providerMsgId IS NOT NULL;

  CREATE TABLE IF NOT EXISTS wa_convo (
    phone         TEXT PRIMARY KEY,
    name          TEXT,
    memberId      TEXT,
    lastAt        TEXT NOT NULL,
    lastText      TEXT,
    unread        INTEGER NOT NULL DEFAULT 0,
    lastInboundAt TEXT,
    lastAdminAt   TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_wa_convo_last ON wa_convo(lastAt);
`);

const preview = (s) => String(s || "").replace(/\s+/g, " ").trim().slice(0, 140);

// Catat satu pesan. Mengembalikan { id, duplicate }.
function addChatMessage(m) {
  const now = new Date().toISOString();
  const incoming = m.direction === "in";
  let id;
  try {
    const r = db.prepare(`
      INSERT INTO wa_chat (createdAt, phone, memberId, direction, sender, body, status, error, providerMsgId)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(now, m.phone, m.memberId || null, m.direction, m.sender, String(m.body || ""), incoming ? null : (m.status || "queued"), m.error || null, m.providerMsgId || null);
    id = Number(r.lastInsertRowid);
  } catch (e) {
    if (/UNIQUE/i.test(e.message)) return { id: null, duplicate: true };
    throw e;
  }
  db.prepare(`
    INSERT INTO wa_convo (phone, name, memberId, lastAt, lastText, unread, lastInboundAt, lastAdminAt)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(phone) DO UPDATE SET
      name          = COALESCE(NULLIF(excluded.name, ''), wa_convo.name),
      memberId      = COALESCE(excluded.memberId, wa_convo.memberId),
      lastAt        = excluded.lastAt,
      lastText      = excluded.lastText,
      unread        = CASE WHEN excluded.lastAdminAt IS NOT NULL THEN 0 ELSE wa_convo.unread + excluded.unread END,
      lastInboundAt = COALESCE(excluded.lastInboundAt, wa_convo.lastInboundAt),
      lastAdminAt   = COALESCE(excluded.lastAdminAt, wa_convo.lastAdminAt)
  `).run(
    m.phone, m.name || "", m.memberId || null, now,
    preview((incoming ? "" : m.sender === "admin" ? "Anda: " : "") + m.body),
    incoming ? 1 : 0,
    incoming ? now : null,
    !incoming && m.sender === "admin" ? now : null
  );
  return { id, duplicate: false };
}

// Perbarui hasil kirim pesan keluar (mis. gagal + alasannya)
function setChatResult(id, { status, error, providerMsgId }) {
  db.prepare("UPDATE wa_chat SET status = ?, error = ?, providerMsgId = COALESCE(?, providerMsgId) WHERE id = ?")
    .run(status, error || null, providerMsgId || null, id);
}

function updateChatStatusByMsgId(providerMsgId, status, error) {
  if (!providerMsgId) return;
  const row = db.prepare("SELECT id, status FROM wa_chat WHERE providerMsgId = ? AND direction = 'out'").get(providerMsgId);
  if (!row) return;
  if (status !== "failed" && (STATUS_RANK[status] ?? 0) <= (STATUS_RANK[row.status] ?? 0)) return;
  db.prepare("UPDATE wa_chat SET status = ?, error = ? WHERE id = ?").run(status, error || null, row.id);
}

function listConvos(limit = 200) {
  return db.prepare(`
    SELECT c.*, m.name AS memberName, m.tier AS memberTier
    FROM wa_convo c LEFT JOIN members m ON m.id = c.memberId
    ORDER BY c.lastAt DESC LIMIT ?
  `).all(Math.min(500, Math.max(1, limit | 0)));
}

function getConvo(phone) {
  return db.prepare(`
    SELECT c.*, m.name AS memberName
    FROM wa_convo c LEFT JOIN members m ON m.id = c.memberId
    WHERE c.phone = ?
  `).get(phone) || null;
}

function readChat(phone, limit = 300) {
  const rows = db.prepare("SELECT * FROM wa_chat WHERE phone = ? ORDER BY id DESC LIMIT ?")
    .all(phone, Math.min(1000, Math.max(1, limit | 0)));
  return rows.reverse();
}

function markConvoRead(phone) {
  db.prepare("UPDATE wa_convo SET unread = 0 WHERE phone = ?").run(phone);
}

function countUnread() {
  const r = db.prepare("SELECT COALESCE(SUM(unread), 0) AS messages, COALESCE(SUM(unread > 0), 0) AS chats FROM wa_convo").get();
  return { messages: Number(r.messages), chats: Number(r.chats) };
}

// Apakah admin sudah membalas nomor ini dalam N jam terakhir? (bot diam supaya tidak "menyerobot" admin)
function adminHandledRecently(phone, hours) {
  const c = db.prepare("SELECT lastAdminAt FROM wa_convo WHERE phone = ?").get(phone);
  if (!c || !c.lastAdminAt) return false;
  return Date.now() - new Date(c.lastAdminAt).getTime() < hours * 3600 * 1000;
}

function readWaLog(limit = 100) {
  return db.prepare(`
    SELECT l.*, m.name AS memberName
    FROM wa_log l LEFT JOIN members m ON m.id = l.memberId
    ORDER BY l.id DESC LIMIT ?
  `).all(Math.min(500, Math.max(1, limit | 0)));
}

// ---------- Members ----------
function readMembers() {
  return db.prepare("SELECT * FROM members ORDER BY joinDate ASC").all();
}

function findMemberById(id) {
  return db.prepare("SELECT * FROM members WHERE id = ?").get(id) || null;
}

function findMemberByPhone(normalizedPhone, normalizeFn) {
  const members = readMembers();
  return members.find((m) => normalizeFn(m.phone) === normalizedPhone) || null;
}

function findMemberByPhoneAndName(normalizedPhone, name, normalizeFn) {
  const members = readMembers();
  return (
    members.find(
      (m) => normalizeFn(m.phone) === normalizedPhone && m.name.trim().toLowerCase() === name.trim().toLowerCase()
    ) || null
  );
}

function insertMember(member) {
  db.prepare(`
    INSERT INTO members (id, name, phone, email, location, joinDate, tier, koin, lastClaim, token)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(member.id, member.name, member.phone, member.email, member.location, member.joinDate, member.tier, member.koin, member.lastClaim, member.token);
  return member;
}

function updateMemberKoin(id, koin, tier, lastClaim) {
  db.prepare("UPDATE members SET koin = ?, tier = ?, lastClaim = ? WHERE id = ?").run(koin, tier, lastClaim, id);
}

// ---------- Orders ----------
function insertOrder(order) {
  db.prepare(`
    INSERT INTO orders (id, memberId, items, total, koinEarned, createdAt, discount)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(order.id, order.memberId, JSON.stringify(order.items), order.total, order.koinEarned, order.createdAt, order.discount || 0);
  return order;
}

function readOrdersByMember(memberId) {
  const rows = db.prepare("SELECT * FROM orders WHERE memberId = ? ORDER BY createdAt DESC").all(memberId);
  return rows.map((r) => ({ ...r, items: JSON.parse(r.items) }));
}

// ---------- Config (alamat QR publik, dll.) ----------
function getConfig(key) {
  const row = db.prepare("SELECT value FROM config WHERE key = ?").get(key);
  return row ? row.value : null;
}

function setConfig(key, value) {
  db.prepare("INSERT INTO config (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value").run(key, value);
}

function deleteConfig(key) {
  db.prepare("DELETE FROM config WHERE key = ?").run(key);
}

module.exports = {
  db,
  readMembers,
  findMemberById,
  findMemberByPhone,
  findMemberByPhoneAndName,
  insertMember,
  updateMemberKoin,
  insertOrder,
  readOrdersByMember,
  getConfig,
  setConfig,
  deleteConfig,
  addWaLog,
  updateWaLog,
  updateWaStatusByMsgId,
  readWaLog,
  addChatMessage,
  setChatResult,
  listConvos,
  getConvo,
  readChat,
  markConvoRead,
  countUnread,
  adminHandledRecently,
};
