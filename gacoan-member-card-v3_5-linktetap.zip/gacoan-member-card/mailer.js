// ---------- Kirim Kartu Member ke Gmail pelanggan ----------
// Memakai SMTP Gmail + "App Password" (BUKAN password Gmail biasa). Cara membuatnya ada di README.
// Isi .env:
//   GMAIL_USER=emailbisnis@gmail.com
//   GMAIL_APP_PASSWORD=abcd efgh ijkl mnop
// Kalau kosong, aplikasi tetap jalan normal dan pengiriman email dilewati (tidak error).
// Setiap email membawa: kartu (tampilan HTML), lampiran PDF kartu depan-belakang yang bisa langsung
// diunduh dari Gmail, tombol unduh cadangan, daftar keuntungan level, dan nomor WhatsApp bisnis.
const nodemailer = require("nodemailer");
const QRCode = require("qrcode");
const { TIERS, getTierByName } = require("./tiers");
const { buildCardPdf } = require("./cardpdf");
const whatsapp = require("./whatsapp");

const GMAIL_USER = process.env.GMAIL_USER || "";
const GMAIL_APP_PASSWORD = (process.env.GMAIL_APP_PASSWORD || "").replace(/\s+/g, "");
const MAIL_FROM_NAME = process.env.MAIL_FROM_NAME || "Gacoan Member";
const MAIL_ENABLED = Boolean(GMAIL_USER && GMAIL_APP_PASSWORD);

let transporter = null;
if (MAIL_ENABLED) {
  transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: { user: GMAIL_USER, pass: GMAIL_APP_PASSWORD },
  });
  transporter
    .verify()
    .then(() => console.log(`✉️  Email Gmail siap (${GMAIL_USER})`))
    .catch((e) => console.error(`⚠️  Login Gmail gagal: ${e.message}. Cek GMAIL_USER / GMAIL_APP_PASSWORD di .env`));
} else {
  console.log("ℹ️  Email belum dikonfigurasi (GMAIL_USER / GMAIL_APP_PASSWORD kosong). Pengiriman email dilewati.");
}

function esc(v) {
  return String(v == null ? "" : v)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// Warna per level kartu (sama dengan tampilan di website)
const TIER_STYLE = {
  Silver:   { solid: "#6f767c", grad: "linear-gradient(135deg,#5c6166 0%,#9aa1a8 50%,#3d4044 100%)", accent: "#eef1f3", pill: "rgba(255,255,255,0.22)" },
  Gold:     { solid: "#a8832a", grad: "linear-gradient(135deg,#4a3a0a 0%,#caa23a 50%,#8a6a14 100%)", accent: "#fff3cf", pill: "rgba(255,235,170,0.28)" },
  Platinum: { solid: "#1f3b52", grad: "linear-gradient(135deg,#0e1a24 0%,#1f3b52 45%,#3f6f8f 80%,#0e1a24 100%)", accent: "#d6f1ff", pill: "rgba(159,220,255,0.25)" },
};

function formatDate(iso) {
  return new Date(iso).toLocaleDateString("id-ID", { day: "2-digit", month: "long", year: "numeric" });
}

// Kotak "Keuntungan level kamu" + petunjuk naik level
function benefitsHtml(member) {
  const tier = getTierByName(member.tier);
  const idx = TIERS.indexOf(tier);
  const next = TIERS[idx + 1];
  const koin = member.koin || 0;
  const items = tier.perks
    .map((p) => `<li style="margin:0 0 3px;">${esc(p)}</li>`)
    .join("");
  const nextLine = next
    ? `<p style="margin:10px 0 0;font-size:12px;color:#8a6a14;">Kumpulkan <strong>${Math.max(0, next.minKoin - koin)} koin lagi</strong> untuk naik ke level <strong>${esc(next.name)}</strong> dan dapat diskon ${next.discountPercent}%.</p>`
    : `<p style="margin:10px 0 0;font-size:12px;color:#8a6a14;">Kamu sudah di level tertinggi. Terima kasih sudah jadi member setia!</p>`;
  return `<tr><td style="padding-top:14px;">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#fff8e6;border:1px solid #f0dba6;border-radius:12px;">
        <tr><td style="padding:14px 18px;font-size:13px;line-height:1.55;color:#4a3a14;">
          <strong style="font-size:14px;">Keuntungan kartu ${esc(member.tier)} kamu</strong>
          <ul style="margin:8px 0 0;padding-left:18px;">${items}</ul>
          ${nextLine}
        </td></tr>
      </table>
    </td></tr>`;
}

// qrMode: "cid" (dipakai saat kirim email sungguhan) atau "data" (untuk pratinjau di browser)
async function buildCardEmail(member, urls, opts = {}) {
  const { qrMode = "cid", reason = "welcome" } = opts;
  const st = TIER_STYLE[member.tier] || TIER_STYLE.Silver;
  const png = await QRCode.toBuffer(urls.claimUrl, { width: 240, margin: 1, errorCorrectionLevel: "M" });
  const qrSrc = qrMode === "cid" ? "cid:gacoan-qr" : `data:image/png;base64,${png.toString("base64")}`;

  const headline =
    reason === "tier_up"
      ? `Selamat! Kartu kamu naik ke level ${esc(member.tier)} 🎉`
      : reason === "resend"
      ? "Ini kartu member Gacoan kamu 💳"
      : "Kartu member Gacoan kamu sudah aktif 🎉";

  const subject =
    reason === "tier_up"
      ? `Selamat, kamu naik level ${member.tier} di Gacoan!`
      : reason === "resend"
      ? "Kartu Member Gacoan kamu"
      : "Kartu Member Gacoan kamu sudah aktif 🎉";

  const html = `<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(subject)}</title></head>
<body style="margin:0;padding:0;background:#f4efe9;font-family:Arial,Helvetica,sans-serif;color:#2a2a2a;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4efe9;padding:24px 12px;">
<tr><td align="center">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:480px;">
    <tr><td style="padding:0 4px 14px;text-align:center;">
      <div style="font-size:13px;letter-spacing:3px;font-weight:bold;color:#c8102e;">GACOAN</div>
      <h1 style="margin:8px 0 6px;font-size:21px;line-height:1.3;color:#1b1b1b;">${headline}</h1>
      <p style="margin:0;font-size:14px;line-height:1.5;color:#555;">Halo <strong>${esc(member.name)}</strong>, ini kartu member kamu. File <strong>PDF kartu</strong> (depan &amp; belakang) terlampir di email ini. Tekan ikon unduh di Gmail, atau pakai tombol di bawah.</p>
    </td></tr>

    <!-- ===== KARTU ===== -->
    <tr><td>
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0"
        style="background-color:${st.solid};background-image:${st.grad};border-radius:16px;color:#ffffff;">
        <tr><td style="padding:20px 22px 6px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>
            <td style="font-size:20px;font-weight:bold;letter-spacing:4px;color:#ffffff;">GACOAN</td>
            <td align="right"><span style="display:inline-block;background:${st.pill};border-radius:20px;padding:5px 14px;font-size:12px;font-weight:bold;letter-spacing:1px;text-transform:uppercase;color:#ffffff;">${esc(member.tier)}</span></td>
          </tr></table>
        </td></tr>
        <tr><td style="padding:22px 22px 4px;">
          <div style="font-size:22px;font-weight:bold;line-height:1.2;color:#ffffff;">${esc(member.name)}</div>
          <div style="margin-top:6px;font-family:'Courier New',monospace;font-size:15px;letter-spacing:2px;color:${st.accent};">${esc(member.id)}</div>
        </td></tr>
        <tr><td style="padding:14px 22px 22px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>
            <td valign="bottom" style="font-size:12px;line-height:1.7;color:#ffffff;">
              Bergabung: ${esc(formatDate(member.joinDate))}<br>
              Outlet: ${esc(member.location || "-")}<br>
              🪙 Koin: <strong>${esc(member.koin || 0)}</strong>
            </td>
            <td align="right" valign="bottom" width="104">
              <img src="${qrSrc}" width="92" height="92" alt="QR kartu member" style="display:block;background:#ffffff;padding:6px;border-radius:8px;">
            </td>
          </tr></table>
        </td></tr>
      </table>
    </td></tr>

    <!-- ===== TOMBOL ===== -->
    <tr><td align="center" style="padding:22px 0 8px;">
      <a href="${esc(urls.pdfUrl)}" style="display:inline-block;background:#c8102e;color:#ffffff;text-decoration:none;font-weight:bold;font-size:15px;padding:14px 26px;border-radius:10px;">⬇️ Unduh Kartu (PDF)</a>
    </td></tr>
    <tr><td align="center" style="padding:0 0 4px;">
      <a href="${esc(urls.cardUrl)}" style="display:inline-block;color:#c8102e;text-decoration:none;font-weight:bold;font-size:14px;padding:8px 14px;">🖨️ Buka &amp; Cetak Kartu</a>
    </td></tr>
    <tr><td align="center" style="padding:0 0 14px;">
      <a href="${esc(urls.claimUrl)}" style="display:inline-block;color:#c8102e;text-decoration:none;font-weight:bold;font-size:14px;padding:8px 14px;">🪙 Klaim Koin &amp; Pesan Menu</a>
    </td></tr>

    ${benefitsHtml(member)}

    <tr><td style="padding-top:14px;">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;">
        <tr><td style="padding:16px 18px;font-size:13px;line-height:1.6;color:#444;">
          <strong>Cara menyimpan &amp; mencetak kartu:</strong>
          <ol style="margin:6px 0 0;padding-left:20px;">
            <li>Buka lampiran <em>${esc(urls.pdfName)}</em> di bagian bawah email, lalu tekan ikon unduh.</li>
            <li>Halaman 1 adalah bagian depan kartu, halaman 2 bagian belakang.</li>
            <li>Untuk mencetak, buka PDF-nya lalu pilih Print, atau tekan <em>Buka &amp; Cetak Kartu</em> di atas.</li>
          </ol>
        </td></tr>
      </table>
    </td></tr>

    <tr><td align="center" style="padding:16px 8px 0;font-size:13px;color:#444;">
      Butuh bantuan? Chat WhatsApp Gacoan:
      <a href="${esc(whatsapp.businessChatUrl("Halo Gacoan, saya member " + member.id))}" style="color:#1e7a34;font-weight:bold;text-decoration:none;">${esc(whatsapp.BUSINESS_DISPLAY)}</a>
    </td></tr>

    <tr><td style="padding:16px 8px 0;text-align:center;font-size:11px;line-height:1.6;color:#888;">
      🔒 Link di email ini bersifat pribadi dan hanya untuk kamu. Jangan teruskan ke orang lain,<br>
      karena siapa pun yang memegang link ini bisa membuka kartu kamu.
    </td></tr>
  </table>
</td></tr></table>
</body></html>`;

  const text = [
    headline.replace(/&amp;/g, "&"),
    "",
    `Halo ${member.name}, ini kartu member Gacoan kamu.`,
    `ID Member : ${member.id}`,
    `Level     : ${member.tier}`,
    `Koin      : ${member.koin || 0}`,
    "",
    `Unduh kartu (PDF)  : ${urls.pdfUrl}`,
    `Buka & cetak kartu : ${urls.cardUrl}`,
    `Klaim koin & menu  : ${urls.claimUrl}`,
    "",
    `Keuntungan kartu ${member.tier}:`,
    ...getTierByName(member.tier).perks.map((p) => `- ${p}`),
    "",
    `Bantuan WhatsApp Gacoan: ${whatsapp.BUSINESS_DISPLAY}`,
    "Link ini pribadi, jangan dibagikan ke orang lain.",
  ].join("\n");

  const attachments = [];
  if (qrMode === "cid") {
    attachments.push({ filename: "qr-member.png", content: png, cid: "gacoan-qr", contentType: "image/png" });
    // Lampiran PDF kartu. Kalau pembuatan PDF gagal, email tetap terkirim tanpa lampiran
    // (tombol "Unduh Kartu (PDF)" di email tetap bisa dipakai).
    try {
      const pdf = await buildCardPdf(member, urls);
      attachments.push({ filename: urls.pdfName, content: pdf, contentType: "application/pdf" });
    } catch (e) {
      console.error(`⚠️  PDF kartu gagal dibuat untuk ${member.id}:`, e.message);
    }
  }

  return { subject, html, text, attachments };
}

// Batas kirim per alamat email (cegah email-bombing lewat form pendaftaran)
const sentLog = new Map();
function allowedToSend(email) {
  const now = Date.now();
  const arr = (sentLog.get(email) || []).filter((t) => now - t < 3600 * 1000);
  if (arr.length >= 4) return false;
  arr.push(now);
  sentLog.set(email, arr);
  return true;
}

// Kirim kartu. Aman gagal: tidak pernah melempar error ke pemanggil.
// Mengembalikan true kalau email benar-benar terkirim.
async function sendCardEmail(member, urls, reason = "welcome") {
  if (!MAIL_ENABLED) return false;
  const to = String(member.email || "").trim();
  if (!to) return false;
  if (!allowedToSend(to.toLowerCase())) {
    console.warn(`⚠️  Email ke ${to} ditahan (terlalu sering dalam 1 jam).`);
    return false;
  }
  try {
    const mail = await buildCardEmail(member, urls, { qrMode: "cid", reason });
    await transporter.sendMail({
      from: `"${MAIL_FROM_NAME.replace(/"/g, "")}" <${GMAIL_USER}>`,
      to,
      subject: mail.subject,
      text: mail.text,
      html: mail.html,
      attachments: mail.attachments,
    });
    console.log(`✉️  Email kartu (${reason}) terkirim ke ${to}`);
    return true;
  } catch (e) {
    console.error(`⚠️  Gagal kirim email ke ${to}:`, e.message);
    return false;
  }
}

module.exports = { MAIL_ENABLED, buildCardEmail, sendCardEmail };
