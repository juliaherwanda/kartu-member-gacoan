const form = document.getElementById("loginForm");
const errorMsg = document.getElementById("errorMsg");

// Hanya izinkan kembali ke halaman admin yang dikenal (cegah redirect ke situs lain)
const ALLOWED = ["members.html", "daftar-qr.html"];
const next = new URLSearchParams(window.location.search).get("next");
const target = ALLOWED.includes(next) ? next : "members.html";

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  errorMsg.textContent = "";
  try {
    const res = await fetch("/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password: document.getElementById("password").value }),
    });
    const data = await res.json();
    if (!res.ok) {
      errorMsg.textContent = data.error || "Login gagal.";
      return;
    }
    window.location.href = target;
  } catch (err) {
    errorMsg.textContent = "Tidak bisa terhubung ke server.";
  }
});
