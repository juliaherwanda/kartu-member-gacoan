const params = new URLSearchParams(window.location.search);
const cardWrapper = document.getElementById("cardWrapper");
const flipBtn = document.getElementById("flipBtn");
const noticeEl = document.getElementById("notice");

let isFlipped = false;

function formatDate(isoString) {
  const d = new Date(isoString);
  return d.toLocaleDateString("id-ID", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  });
}

function showNotice(html, kind) {
  if (!noticeEl) return;
  noticeEl.className = `notice-box no-print ${kind || ""}`;
  noticeEl.innerHTML = html;
  noticeEl.style.display = "block";
}

function showProblem(html) {
  cardWrapper.innerHTML = `<div class="card-problem">${html}</div>`;
  document.querySelector(".actions").style.display = "none";
}

async function loadCard() {
  // Sumber kredensial: link (?id=&t=) -> atau yang tersimpan di HP ini.
  // Admin boleh membuka dengan ?id= saja (login admin dibaca dari cookie).
  const urlId = params.get("id");
  const urlT = params.get("t");
  let creds = null;
  if (urlId && urlT) {
    creds = { id: urlId, t: urlT };
    saveMember(urlId, urlT);
  } else if (urlId) {
    creds = { id: urlId, t: "" };
  } else {
    creds = getSaved();
  }

  if (!creds) {
    showProblem(`
      <p>Kartu member hanya bisa dibuka lewat <strong>link pribadi</strong> yang dikirim ke email atau WhatsApp kamu.</p>
      <p><a href="index.html">Daftar member</a> atau pakai <em>Kirim ulang kartu saya</em> di halaman pendaftaran.</p>`);
    return;
  }

  try {
    const url = `/api/member/${encodeURIComponent(creds.id)}` + (creds.t ? `?t=${encodeURIComponent(creds.t)}` : "");
    const res = await fetch(url);
    if (!res.ok) {
      showProblem(`
        <p>Kartu tidak ditemukan atau link tidak valid.</p>
        <p>Kartu member bersifat pribadi. Buka lewat link di email/WhatsApp kamu, atau
        <a href="index.html">kirim ulang kartu</a> ke kontak yang terdaftar.</p>`);
      return;
    }
    const member = await res.json();
    renderCard(member);

    // Tombol unduh PDF memakai alamat relatif, jadi jalan di localhost maupun link publik.
    const pdfBtn = document.getElementById("pdfBtn");
    if (pdfBtn) {
      pdfBtn.href = `/api/card-pdf/${encodeURIComponent(creds.id)}` + (creds.t ? `?t=${encodeURIComponent(creds.t)}` : "");
    }

    const menuLink = document.getElementById("menuLink");
    if (menuLink) {
      if (creds.t) menuLink.href = `menu.html?${memberQuery(creds)}`;
      else menuLink.style.display = "none";
    }

    if (!creds.t) {
      showNotice("🔐 <strong>Mode admin:</strong> kamu sedang melihat kartu member lain. Kartu ini tidak terlihat oleh pelanggan lain.", "admin");
    } else if (params.get("new") === "1") {
      const mail = params.get("mail") === "1";
      showNotice(
        `🎉 <strong>Pendaftaran berhasil!</strong> ${
          mail ? "Kartu juga dikirim ke <strong>Gmail</strong> kamu lengkap dengan <strong>file PDF</strong> yang bisa langsung diunduh (cek folder Spam kalau belum masuk). " : ""
        }Kamu juga bisa mengunduh PDF atau mencetak kartu dengan tombol di bawah.`,
        "ok"
      );
    }
  } catch (err) {
    showProblem("<p>Gagal memuat data member.</p>");
  }
}

// Nama tier -> kelas CSS (silver/gold/platinum). Default "silver" kalau tidak dikenali.
function tierClass(tierName) {
  const t = String(tierName || "").toLowerCase();
  if (t.includes("platinum")) return "tier-platinum";
  if (t.includes("gold")) return "tier-gold";
  return "tier-silver";
}

function renderCard(member) {
  // Link yang dibuka saat QR di-scan: halaman klaim koin/promo (sudah berisi token, dari server)
  const claimUrl = member.claimUrl;
  const tCls = tierClass(member.tier);

  cardWrapper.innerHTML = `
    <div class="flip-container" id="flipContainer">
      <div class="flip-inner">

        <!-- ===== SISI DEPAN ===== -->
        <div class="member-card card-front ${tCls}">
          <div class="card-top">
            <img src="img/logo-gacoan-white.svg" alt="Gacoan" class="card-logo-img" />
            <div class="card-type">${esc(member.tier)}</div>
          </div>
          <div class="card-middle">
            <p class="card-name">${esc(member.name)}</p>
            <p class="card-id">${esc(member.id)}</p>
          </div>
          <div class="card-bottom">
            <div class="card-meta">
              Bergabung: ${formatDate(member.joinDate)}<br/>
              Outlet: ${esc(member.location || "-")}<br/>
              🪙 Koin: <strong>${esc(member.koin || 0)}</strong>
            </div>
            <div class="card-qr" id="qrcode"></div>
          </div>
        </div>

        <!-- ===== SISI BELAKANG ===== -->
        <div class="member-card card-back ${tCls}">
          <div class="card-back-header">
            <img src="img/logo-gacoan-white.svg" alt="Gacoan" class="card-logo-img small" />
          </div>
          <div class="card-back-body">
            <p class="back-title">Syarat &amp; Ketentuan</p>
            <ul class="back-terms">
              <li>Kartu ini adalah milik pribadi dan tidak dapat dipindahtangankan.</li>
              <li>Scan QR di depan kartu untuk klaim koin harian, promo, & pesan menu.</li>
              <li>Kartu hilang harap segera lapor ke outlet tempat pendaftaran.</li>
              <li>Berlaku di seluruh outlet Gacoan se-Indonesia.</li>
            </ul>
          </div>
          <div class="card-back-footer">
            <div class="signature-box">
              <div class="signature-line"></div>
              <span>Tanda Tangan Member</span>
            </div>
            <div class="card-meta small-meta">
              Terdaftar di:<br/>${esc(member.location || "-")}
            </div>
          </div>
        </div>

      </div>
    </div>
  `;

  // QR code -> membuka halaman klaim koin/promo/menu saat discan
  new QRCode(document.getElementById("qrcode"), {
    text: claimUrl,
    width: 76,
    height: 76,
    correctLevel: QRCode.CorrectLevel.M,
  });
}

flipBtn.addEventListener("click", () => {
  const el = document.getElementById("flipContainer");
  if (!el) return;
  isFlipped = !isFlipped;
  el.classList.toggle("flipped", isFlipped);
  flipBtn.textContent = isFlipped ? "🔄 Lihat Bagian Depan" : "🔄 Lihat Bagian Belakang";
});

document.getElementById("printBtn").addEventListener("click", () => {
  window.print();
});

loadCard();
