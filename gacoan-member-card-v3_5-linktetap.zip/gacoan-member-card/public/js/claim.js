const creds = memberCreds(); // { id, t } dari QR/link, atau tersimpan di HP ini
const claimBody = document.getElementById("claimBody");

async function loadMember() {
  if (!creds) {
    claimBody.innerHTML = `<p class="claim-error">Buka halaman ini lewat <strong>QR di kartu</strong> atau link pribadi member kamu.<br><a href="index.html">Daftar member</a></p>`;
    return;
  }

  try {
    const res = await fetch(`/api/member/${encodeURIComponent(creds.id)}?t=${encodeURIComponent(creds.t)}`);
    if (!res.ok) {
      clearSaved();
      claimBody.innerHTML = `<p class="claim-error">Link kartu tidak valid atau sudah tidak berlaku.<br><a href="index.html">Kirim ulang kartu saya</a></p>`;
      return;
    }
    const member = await res.json();
    let tiers = [];
    try {
      const tRes = await fetch("/api/tiers");
      tiers = await tRes.json();
    } catch (e) {}
    renderClaimScreen(member, tiers);
  } catch (err) {
    claimBody.innerHTML = `<p class="claim-error">Gagal terhubung ke server.</p>`;
  }
}

function buildTierProgress(member, tiers) {
  if (!tiers || tiers.length === 0) return "";
  const koin = member.koin || 0;
  let currentIdx = 0;
  tiers.forEach((t, i) => { if (koin >= t.minKoin) currentIdx = i; });
  const current = tiers[currentIdx];
  const next = tiers[currentIdx + 1];

  if (!next) {
    return `
      <div class="tier-progress">
        <div class="tier-progress-head"><span>${esc(current.name)}</span><span>Level tertinggi 🎉</span></div>
        <div class="tier-progress-bar"><div class="tier-progress-fill" style="width:100%"></div></div>
        <p class="tier-progress-note">Kamu sudah di level tertinggi. Terima kasih sudah jadi member setia Gacoan!</p>
      </div>`;
  }

  const range = next.minKoin - current.minKoin;
  const done = koin - current.minKoin;
  const percent = Math.min(100, Math.round((done / range) * 100));
  const sisa = next.minKoin - koin;

  return `
    <div class="tier-progress">
      <div class="tier-progress-head"><span>${esc(current.name)}</span><span>${esc(next.name)}</span></div>
      <div class="tier-progress-bar"><div class="tier-progress-fill" style="width:${percent}%"></div></div>
      <p class="tier-progress-note">Kumpulkan <strong>${sisa} koin lagi</strong> untuk naik ke ${esc(next.name)} dan dapat bonus lebih besar.</p>
    </div>`;
}

function renderClaimScreen(member, tiers) {
  claimBody.innerHTML = `
    <div class="claim-member-info">
      <p class="claim-name">${esc(member.name)}</p>
      <p class="claim-id">${esc(member.id)} · ${esc(member.tier)}</p>
      <div class="claim-koin-box">
        <span class="claim-koin-label">Koin saat ini</span>
        <span class="claim-koin-value" id="koinValue">${member.koin || 0}</span>
      </div>
    </div>

    ${buildTierProgress(member, tiers)}

    <div class="claim-promo-box">
      🎉 Tunjukkan halaman ini ke kasir untuk klaim <strong>promo member</strong>,
      atau tekan tombol di bawah untuk mengumpulkan <strong>koin harian</strong> Gacoan.
    </div>

    <button id="claimBtn">🪙 Klaim Koin Hari Ini</button>
    <p id="claimResult" class="claim-result"></p>

    <a href="menu.html?${memberQuery(creds)}" class="menu-cta-link">🍜 Pesan Menu &amp; Dapat Koin Lagi →</a>
  `;

  document.getElementById("claimBtn").addEventListener("click", () => claimKoin(member.id));
}

async function claimKoin(id) {
  const btn = document.getElementById("claimBtn");
  const resultEl = document.getElementById("claimResult");
  btn.disabled = true;
  btn.textContent = "Memproses...";

  try {
    const res = await fetch(`/api/claim/${encodeURIComponent(id)}?t=${encodeURIComponent(creds.t)}`, { method: "POST" });
    const data = await res.json();

    if (!res.ok) {
      resultEl.textContent = data.error || "Klaim gagal.";
      resultEl.className = "claim-result claim-fail";
      btn.textContent = "Sudah Diklaim Hari Ini";
      return;
    }

    document.getElementById("koinValue").textContent = data.koin;
    resultEl.textContent = `+${data.reward} koin! Total koin kamu sekarang: ${data.koin} 🎉`;
    resultEl.className = "claim-result claim-success";
    btn.textContent = "✅ Berhasil Diklaim";

    // Perbarui progress level setelah koin bertambah
    try {
      const tRes = await fetch("/api/tiers");
      const tiers = await tRes.json();
      const el = document.querySelector(".tier-progress");
      if (el) el.outerHTML = buildTierProgress(data.member, tiers);
    } catch (e) {}
  } catch (err) {
    resultEl.textContent = "Gagal terhubung ke server.";
    resultEl.className = "claim-result claim-fail";
    btn.disabled = false;
    btn.textContent = "🪙 Klaim Koin Hari Ini";
  }
}

loadMember();
