// Fungsi bersama untuk semua halaman.
// esc()  : amankan teks sebelum disisipkan ke HTML (nama member berasal dari form publik,
//          jadi WAJIB di-escape agar tidak bisa menyisipkan script).
// Saved* : simpan ID + token kartu di HP ini supaya customer tidak perlu login.
function esc(v) {
  return String(v == null ? "" : v)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

const SAVED_KEY = "gacoanMember";

function getSaved() {
  try {
    const raw = localStorage.getItem(SAVED_KEY);
    if (!raw) return null;
    const o = JSON.parse(raw);
    return o && o.id && o.t ? o : null;
  } catch (e) {
    return null;
  }
}

function saveMember(id, t) {
  try { localStorage.setItem(SAVED_KEY, JSON.stringify({ id, t })); } catch (e) {}
}

function clearSaved() {
  try { localStorage.removeItem(SAVED_KEY); localStorage.removeItem("gacoanMemberId"); } catch (e) {}
}

// Ambil id & token dari URL (?id=...&t=...). Kalau tidak ada, pakai yang tersimpan di HP ini.
function memberCreds() {
  const p = new URLSearchParams(window.location.search);
  const id = p.get("id");
  const t = p.get("t");
  if (id && t) {
    saveMember(id, t);
    return { id, t };
  }
  return getSaved();
}

function memberQuery(c) {
  return `id=${encodeURIComponent(c.id)}&t=${encodeURIComponent(c.t)}`;
}
