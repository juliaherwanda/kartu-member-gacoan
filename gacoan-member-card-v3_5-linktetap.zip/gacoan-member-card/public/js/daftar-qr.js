const baseUrlInput = document.getElementById("baseUrl");
const ipChips = document.getElementById("ipChips");
const urlWarning = document.getElementById("urlWarning");
const posterQr = document.getElementById("posterQr");
const posterUrl = document.getElementById("posterUrl");

function cleanBase(value) {
  let v = value.trim();
  if (!v) return "";
  if (!/^https?:\/\//i.test(v)) v = "http://" + v;
  return v.replace(/\/+$/, "");
}

function drawQr() {
  const base = cleanBase(baseUrlInput.value);
  posterQr.innerHTML = "";

  if (!base) {
    posterUrl.textContent = "";
    urlWarning.textContent = "Isi alamat website dulu.";
    return;
  }

  let host = "";
  try { host = new URL(base).hostname; } catch (e) {}
  const isLocal = /^(localhost|127\.0\.0\.1)$/i.test(host);
  const isPrivateIp = /^(10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+|169\.254\.\d+\.\d+)$/.test(host);
  if (isLocal) {
    urlWarning.textContent = "⚠️ Alamat 'localhost' hanya bisa dibuka di komputer ini. Jalankan 'npm run public' lalu pakai link https-nya agar bisa dibuka dari HP customer.";
  } else if (isPrivateIp) {
    urlWarning.textContent = "⚠️ Alamat IP lokal ini HANYA bisa dibuka dari WiFi yang sama. Customer yang pakai data seluler atau WiFi lain tidak akan bisa mendaftar. Jalankan 'npm run public' dan pakai link https-nya.";
  } else if (/^http:\/\//i.test(base)) {
    urlWarning.textContent = "ℹ️ Disarankan memakai https:// supaya aman dibuka dari HP.";
  } else {
    urlWarning.textContent = "";
  }

  const target = base + "/scan.html"; // satu QR untuk customer baru & lama
  new QRCode(posterQr, {
    text: target,
    width: 520,   // dibuat besar lalu diperkecil lewat CSS -> kotak tajam & mudah dibaca kamera
    height: 520,
    colorDark: "#000000",
    colorLight: "#ffffff",
    correctLevel: QRCode.CorrectLevel.M,
  });
  posterUrl.textContent = target;

  const testLink = document.getElementById("testLink");
  if (testLink) testLink.href = target;
}

async function init() {
  let addresses = [];
  let interfaces = [];
  let savedUrl = "";
  let staleUrl = "";
  let port = location.port || "3000";

  try {
    const res = await fetch("/api/server-info");
    const info = await res.json();
    addresses = info.addresses || [];
    interfaces = info.interfaces || [];
    savedUrl = info.publicUrl || "";
    staleUrl = info.staleUrl || "";
    port = info.port || port;
  } catch (e) {}

  const isLocalOrigin = /localhost|127\.0\.0\.1/i.test(location.hostname);

  if (savedUrl) {
    baseUrlInput.value = savedUrl;
  } else if (!isLocalOrigin) {
    baseUrlInput.value = location.origin;
  } else if (addresses.length) {
    baseUrlInput.value = `http://${addresses[0]}:${port}`;
  } else {
    baseUrlInput.value = `http://localhost:${port}`;
  }

  ipChips.innerHTML = interfaces
    .map((i) => `<button type="button" class="ip-chip" data-url="http://${i.address}:${port}">${i.name}: ${i.address}</button>`)
    .join("");

  ipChips.querySelectorAll(".ip-chip").forEach((btn) =>
    btn.addEventListener("click", () => {
      baseUrlInput.value = btn.dataset.url;
      drawQr();
    })
  );

  drawQr();

  if (staleUrl) {
    urlWarning.textContent =
      `ℹ️ Alamat lama (${staleUrl}) sudah tidak aktif di jaringan ini, jadi QR otomatis memakai alamat komputer sekarang: ${baseUrlInput.value}. ` +
      `Klik "Simpan sebagai alamat QR kartu member" agar kartu member juga memakai alamat ini.`;
  }
}

document.getElementById("saveUrlBtn").addEventListener("click", async () => {
  const msg = document.getElementById("saveMsg");
  const base = cleanBase(baseUrlInput.value);
  msg.style.color = "";
  if (!base) {
    msg.textContent = "Isi alamat website dulu.";
    return;
  }
  try {
    const res = await fetch("/api/config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ publicUrl: base }),
    });
    const data = await res.json();
    if (!res.ok) {
      msg.textContent = data.error || "Gagal menyimpan.";
      return;
    }
    msg.style.color = "#1e7a34";
    msg.textContent = "✅ Tersimpan. QR di semua kartu member sekarang memakai alamat ini.";
  } catch (e) {
    msg.textContent = "Tidak bisa terhubung ke server.";
  }
});

document.getElementById("refreshBtn").addEventListener("click", drawQr);
document.getElementById("printPosterBtn").addEventListener("click", () => window.print());
baseUrlInput.addEventListener("change", drawQr);
baseUrlInput.addEventListener("input", drawQr);

init();
