// Kotak Masuk WhatsApp: KHUSUS ADMIN (server menolak kalau belum login).
// Alur: customer membalas chat otomatis -> pesan masuk lewat webhook -> muncul di sini -> admin membalas.
// Halaman memeriksa pesan baru otomatis (polling) tiap beberapa detik.
const LIST_EVERY_MS = 6000;
const THREAD_EVERY_MS = 4000;

const $ = (id) => document.getElementById(id);
const chatList = $("chatList");
const listEmpty = $("listEmpty");
const messagesEl = $("messages");
const replyText = $("replyText");
const sendBtn = $("sendBtn");
const sendMsg = $("sendMsg");
const grid = $("inboxGrid");

const QUICK = [
  "Halo {nama}, terima kasih sudah menghubungi Gacoan. Ada yang bisa kami bantu?",
  "Baik {nama}, mohon ditunggu sebentar ya, kami cek dulu.",
  "Terima kasih {nama}, semoga harimu menyenangkan. Sampai ketemu di outlet Gacoan!",
];

let chats = [];
let unreadOnly = false;
let current = null; // { phone, canReply, ... }
let lastCount = null; // jumlah belum dibaca terakhir (untuk bunyi)
let listTimer = null;
let threadTimer = null;
let sending = false;

// ---------- Bantuan tampilan ----------
function fmtTime(iso) {
  const d = new Date(iso);
  const today = new Date();
  const sameDay = d.toDateString() === today.toDateString();
  return sameDay
    ? d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })
    : d.toLocaleDateString("id-ID", { day: "2-digit", month: "short" }) + " " +
      d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
}

// Teks pesan: aman dari script (esc), baris baru dipertahankan, link bisa diklik.
function bodyHtml(text) {
  return esc(text).replace(/(https?:\/\/[^\s<]+)/g, (u) => `<a href="${u}" target="_blank" rel="noopener noreferrer">${u}</a>`);
}

const STATUS = {
  queued: ["Mengirim...", ""],
  sent: ["✓", "st-sent"],
  delivered: ["✓✓", "st-delivered"],
  read: ["✓✓", "st-read"],
  failed: ["Gagal ✗", "st-failed"],
};
const SENDER = { admin: "Admin", bot: "Bot otomatis", system: "Pesan otomatis", customer: "" };

function beep() {
  try {
    if (!$("soundToggle").checked) return;
    const Ctx = window.AudioContext || window.webkitAudioContext;
    const ctx = new Ctx();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.connect(g);
    g.connect(ctx.destination);
    o.frequency.value = 880;
    g.gain.value = 0.08;
    o.start();
    o.stop(ctx.currentTime + 0.15);
    setTimeout(() => ctx.close(), 400);
  } catch (e) {}
}

// ---------- Daftar percakapan ----------
function renderList() {
  const q = $("chatSearch").value.trim().toLowerCase();
  const rows = chats
    .filter((c) => !unreadOnly || c.unread > 0)
    .filter((c) => !q || [c.name, c.waName, c.phone, c.memberId, c.lastText].join(" ").toLowerCase().includes(q));

  listEmpty.hidden = rows.length > 0;
  if (!rows.length) {
    listEmpty.textContent = chats.length
      ? "Tidak ada percakapan yang cocok."
      : "Belum ada chat masuk. Pesan dari customer akan muncul di sini begitu mereka membalas.";
  }

  chatList.innerHTML = rows
    .map((c) => {
      const title = c.name || c.waName || c.phone;
      const active = current && current.phone === c.phone ? " active" : "";
      return `<li>
        <button type="button" class="inbox-item${active}${c.unread ? " unread" : ""}" data-phone="${esc(c.phone)}">
          <span class="inbox-item-row">
            <strong>${esc(title)}</strong>
            <time>${esc(fmtTime(c.lastAt))}</time>
          </span>
          <span class="inbox-item-row">
            <span class="inbox-item-last">${esc(c.lastText)}</span>
            ${c.unread ? `<span class="inbox-badge">${esc(c.unread)}</span>` : ""}
          </span>
          <span class="inbox-item-meta">${esc(c.phone)}${c.memberId ? " · " + esc(c.memberId) : " · bukan member"}</span>
        </button>
      </li>`;
    })
    .join("");

  chatList.querySelectorAll("[data-phone]").forEach((b) =>
    b.addEventListener("click", () => openChat(b.dataset.phone))
  );
}

function updateUnread(total) {
  const badge = $("unreadBadge");
  badge.textContent = total;
  badge.hidden = !total;
  document.title = (total ? `(${total}) ` : "") + "Kotak Masuk WhatsApp Gacoan";
  if (lastCount !== null && total > lastCount) beep();
  lastCount = total;
}

async function loadList() {
  try {
    const res = await fetch("/api/admin/chats");
    if (res.status === 401) { window.location.href = "admin-login.html?next=inbox.html"; return; }
    if (!res.ok) return;
    const data = await res.json();
    chats = data.chats || [];
    updateUnread((data.unread && data.unread.messages) || 0);
    $("inboxStatus").innerHTML = data.enabled
      ? `Penerimaan chat: <b class="on">aktif</b> &nbsp;·&nbsp; Jalur: <b class="on">${esc(data.provider === "cloud" ? "Cloud API Meta" : "Fonnte")}</b> &nbsp;·&nbsp; Halaman ini memeriksa pesan baru otomatis.`
      : `Penerimaan chat: <b class="off">belum aktif</b>. Isi WA_TOKEN, WA_PHONE_NUMBER_ID, dan WA_APP_SECRET di .env (atau FONNTE_TOKEN), restart server, lalu daftarkan webhook. Lihat PANDUAN.`;
    renderList();
  } catch (e) {}
}

// ---------- Isi percakapan ----------
function renderThread(data, keepScroll) {
  const c = data.chat;
  current = c;
  $("thName").textContent = c.name || c.waName || c.phone;
  $("thSub").textContent = c.phone + (c.memberId ? ` · ${c.memberId}` : " · belum terdaftar sebagai member");

  const links = [];
  if (data.member) {
    links.push(`<a class="btn-small alt" href="card.html?id=${encodeURIComponent(data.member.id)}" target="_blank" rel="noopener">Lihat kartu</a>`);
    links.push(`<span class="inbox-member-chip">${esc(data.member.tier)} · 🪙 ${esc(data.member.koin)}</span>`);
  }
  $("thLinks").innerHTML = links.join(" ");

  const nearBottom = messagesEl.scrollHeight - messagesEl.scrollTop - messagesEl.clientHeight < 80;
  let lastDay = "";
  messagesEl.innerHTML = data.messages
    .map((m) => {
      const day = new Date(m.at).toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long" });
      const sep = day !== lastDay ? `<div class="inbox-day">${esc(day)}</div>` : "";
      lastDay = day;
      const mine = m.direction === "out";
      const st = mine ? STATUS[m.status] || ["", ""] : null;
      return `${sep}<div class="inbox-msg ${mine ? "out" : "in"} s-${esc(m.sender)}">
        ${mine && SENDER[m.sender] ? `<span class="inbox-who">${esc(SENDER[m.sender])}</span>` : ""}
        <div class="inbox-bubble">${bodyHtml(m.body)}</div>
        <span class="inbox-time">${esc(fmtTime(m.at))}${
          st ? ` <span class="inbox-tick ${st[1]}"${m.error ? ` title="${esc(m.error)}"` : ""}>${esc(st[0])}</span>` : ""
        }</span>
        ${mine && m.status === "failed" && m.error ? `<span class="inbox-err">${esc(m.error)}</span>` : ""}
      </div>`;
    })
    .join("");
  if (!keepScroll || nearBottom) messagesEl.scrollTop = messagesEl.scrollHeight;

  const note = $("windowNote");
  note.hidden = c.canReply;
  note.textContent = c.canReply ? "" : c.cannotReplyReason || "";
  replyText.disabled = !c.canReply || sending;
  sendBtn.disabled = !c.canReply || sending;

  const nama = (data.member && data.member.name) || c.waName || "kak";
  $("quickReplies").innerHTML = QUICK.map(
    (t, i) => `<button type="button" class="inbox-chip" data-q="${i}">${esc(t.replace("{nama}", nama))}</button>`
  ).join("");
  $("quickReplies").querySelectorAll("[data-q]").forEach((b) =>
    b.addEventListener("click", () => {
      replyText.value = QUICK[Number(b.dataset.q)].replace("{nama}", nama);
      replyText.focus();
    })
  );
}

async function fetchThread(phone, markRead) {
  const res = await fetch(`/api/admin/chats/${encodeURIComponent(phone)}?markRead=${markRead ? 1 : 0}`);
  if (res.status === 401) { window.location.href = "admin-login.html?next=inbox.html"; return null; }
  if (!res.ok) return null;
  return res.json();
}

async function openChat(phone) {
  const data = await fetchThread(phone, true);
  if (!data) return;
  $("threadPlaceholder").hidden = true;
  $("threadBox").hidden = false;
  grid.classList.add("show-thread");
  sendMsg.textContent = "";
  renderThread(data, false);
  renderList();
  loadList();
  clearInterval(threadTimer);
  threadTimer = setInterval(refreshThread, THREAD_EVERY_MS);
  if (!replyText.disabled) replyText.focus();
}

async function refreshThread() {
  if (!current || document.hidden || sending) return;
  const data = await fetchThread(current.phone, true); // sedang dibuka = otomatis terbaca
  if (data && current && data.chat.phone === current.phone) renderThread(data, true);
}

// ---------- Kirim balasan ----------
async function sendReply(ev) {
  if (ev) ev.preventDefault();
  if (!current || sending) return;
  const text = replyText.value.trim();
  if (!text) return;
  sending = true;
  replyText.disabled = true;
  sendBtn.disabled = true;
  sendBtn.textContent = "Mengirim...";
  sendMsg.style.color = "";
  sendMsg.textContent = "";
  try {
    const res = await fetch(`/api/admin/chats/${encodeURIComponent(current.phone)}/reply`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    });
    const out = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(out.error || "Gagal mengirim.");
    replyText.value = "";
  } catch (e) {
    sendMsg.style.color = "#c8102e";
    sendMsg.textContent = "❌ " + e.message;
  }
  sending = false;
  sendBtn.textContent = "Kirim";
  const data = await fetchThread(current.phone, true);
  if (data) renderThread(data, false);
  replyText.focus();
  loadList();
}

// ---------- Pasang pengendali ----------
$("composeForm").addEventListener("submit", sendReply);
replyText.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
    e.preventDefault();
    sendReply();
  }
});
$("chatSearch").addEventListener("input", renderList);
$("filterAll").addEventListener("click", () => {
  unreadOnly = false;
  $("filterAll").classList.remove("alt");
  $("filterUnread").classList.add("alt");
  renderList();
});
$("filterUnread").addEventListener("click", () => {
  unreadOnly = true;
  $("filterUnread").classList.remove("alt");
  $("filterAll").classList.add("alt");
  renderList();
});
$("backBtn").addEventListener("click", () => {
  grid.classList.remove("show-thread");
  clearInterval(threadTimer);
  current = null;
  $("threadBox").hidden = true;
  $("threadPlaceholder").hidden = false;
  renderList();
});

(async function init() {
  try {
    const me = await (await fetch("/api/admin/me")).json();
    if (!me.admin) { window.location.href = "admin-login.html?next=inbox.html"; return; }
  } catch (e) {}
  await loadList();
  const wanted = new URLSearchParams(window.location.search).get("phone");
  if (wanted) openChat(wanted);
  listTimer = setInterval(() => { if (!document.hidden) loadList(); }, LIST_EVERY_MS);
})();
