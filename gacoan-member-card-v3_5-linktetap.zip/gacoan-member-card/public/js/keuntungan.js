// esc() dipakai untuk mengamankan teks sebelum disisipkan ke HTML.
function esc(v) {
  return String(v == null ? "" : v)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

const TOTAL_BELANJA = 50000;
const KOIN_PER_10K = 5;

const simulationEl = document.getElementById("simulation");
const tierListEl = document.getElementById("tierList");

async function loadTiers() {
  try {
    const res = await fetch("/api/tiers");
    const tiers = await res.json();
    renderSimulation(tiers);
    renderTiers(tiers);
    renderCompare(tiers);
  } catch (err) {
    simulationEl.innerHTML = `<p class="claim-error">Gagal memuat data level member.</p>`;
  }
}

function formatRupiah(n) {
  return "Rp" + n.toLocaleString("id-ID");
}

// Rumus sama dengan calcOrder() di tiers.js (server): koin dihitung dari jumlah yang DIBAYAR.
function hitungBelanja(total, t) {
  const diskon = Math.floor((total * (t.discountPercent || 0)) / 100);
  const bayar = total - diskon;
  const koin = Math.floor(Math.floor(bayar / 10000) * KOIN_PER_10K * t.orderMultiplier);
  return { diskon, bayar, koin };
}

function renderSimulation(tiers) {
  const nonMember = `
    <div class="sim-item sim-non">
      <p class="sim-label">Non-Member</p>
      <p class="sim-value">0 koin</p>
      <p class="sim-label">Bayar ${formatRupiah(TOTAL_BELANJA)}</p>
    </div>`;

  const memberItems = tiers
    .map((t) => {
      const h = hitungBelanja(TOTAL_BELANJA, t);
      return `
        <div class="sim-item">
          <p class="sim-label">${esc(t.name)}</p>
          <p class="sim-value">+${h.koin} koin</p>
          <p class="sim-label">Bayar ${formatRupiah(h.bayar)}${h.diskon ? ` (hemat ${formatRupiah(h.diskon)})` : ""}</p>
        </div>`;
    })
    .join("");

  simulationEl.innerHTML = nonMember + memberItems;
}

function renderCompare(tiers) {
  const head = `<thead><tr><th>Keuntungan</th>${tiers
    .map((t) => `<th class="tier-col-${esc(t.key)}">${esc(t.name)}</th>`)
    .join("")}</tr></thead>`;
  const row = (label, fn) => `<tr><td>${label}</td>${tiers.map((t) => `<td>${fn(t)}</td>`).join("")}</tr>`;
  const body = [
    row("Syarat level", (t) => (t.minKoin === 0 ? "Otomatis saat daftar" : `${t.minKoin} koin`)),
    row("Koin dari belanja", (t) => `x${String(t.orderMultiplier).replace(".", ",")}`),
    row("Klaim koin harian", (t) => `${t.dailyClaim} koin`),
    row("Diskon pesanan di aplikasi", (t) => (t.discountPercent ? `${t.discountPercent}%` : "-")),
    row("Kartu PDF di Gmail", () => "✓"),
    row("Promo khusus level <small>(dikelola outlet)</small>", (t) => (t.key === "silver" ? "-" : "✓")),
    row("Info menu baru lebih awal <small>(dikelola outlet)</small>", (t) => (t.key === "platinum" ? "✓" : "-")),
  ].join("");
  document.getElementById("tierCompare").innerHTML = head + `<tbody>${body}</tbody>`;
}

function renderTiers(tiers) {
  tierListEl.innerHTML = tiers
    .map((t, i) => {
      const syarat =
        t.minKoin === 0
          ? "Otomatis saat daftar"
          : `Setelah kumpulkan ${t.minKoin} koin`;
      return `
        <div class="tier-item tier-${i + 1}">
          <div class="tier-head">
            <span class="tier-name">${esc(t.name)}</span>
            <span class="tier-req">${syarat}</span>
          </div>
          <ul class="tier-perks">
            ${t.perks.map((p) => `<li>${esc(p)}</li>`).join("")}
          </ul>
        </div>`;
    })
    .join("");
}

loadTiers();
