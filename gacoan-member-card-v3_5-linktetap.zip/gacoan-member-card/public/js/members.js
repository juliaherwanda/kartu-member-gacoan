// Halaman daftar member: KHUSUS ADMIN (server menolak kalau belum login).
const tbody = document.getElementById("memberTableBody");
const emptyMsg = document.getElementById("emptyMsg");
const searchBox = document.getElementById("searchBox");
const tierFilter = document.getElementById("tierFilter");
let allMembers = [];

function formatDate(isoString) {
  const d = new Date(isoString);
  return d.toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" });
}

function tierClass(tierName) {
  const t = String(tierName || "").toLowerCase();
  if (t.includes("platinum")) return "tier-platinum";
  if (t.includes("gold")) return "tier-gold";
  return "tier-silver";
}

function render() {
  const q = searchBox.value.trim().toLowerCase();
  const tier = tierFilter.value;
  const rows = allMembers
    .slice()
    .reverse()
    .filter((m) => (!tier || m.tier === tier))
    .filter((m) => !q || [m.id, m.name, m.phone, m.email, m.location].join(" ").toLowerCase().includes(q));

  if (rows.length === 0) {
    tbody.innerHTML = "";
    emptyMsg.textContent = allMembers.length ? "Tidak ada member yang cocok." : "Belum ada member terdaftar.";
    emptyMsg.style.display = "block";
    return;
  }
  emptyMsg.style.display = "none";

  tbody.innerHTML = rows
    .map(
      (m) => `
      <tr>
        <td>${esc(m.id)}</td>
        <td>${esc(m.name)}</td>
        <td><span class="tier-badge ${tierClass(m.tier)}">${esc(m.tier)}</span></td>
        <td>${esc(m.phone)}</td>
        <td>${esc(m.email || "-")}</td>
        <td>${esc(m.location || "-")}</td>
        <td>🪙 ${esc(m.koin || 0)}</td>
        <td>${esc(formatDate(m.joinDate))}</td>
        <td class="col-action">
          <a class="btn-view" href="card.html?id=${encodeURIComponent(m.id)}">Lihat Kartu</a>
          <button class="btn-small" data-resend="${esc(m.id)}">Kirim ulang</button>
          <button class="btn-small wa" data-wa="${esc(m.id)}" title="Buka WhatsApp dengan pesan siap kirim">WA</button>
        </td>
      </tr>`
    )
    .join("");

  // Tombol WA: buka WhatsApp (Web / aplikasi) dengan pesan berisi link kartu + PDF, tinggal tekan Kirim.
  // Jalan tanpa Cloud API; pengirimnya akun WhatsApp Business yang sedang login di perangkat admin.
  tbody.querySelectorAll("[data-wa]").forEach((btn) =>
    btn.addEventListener("click", async () => {
      const win = window.open("about:blank", "_blank"); // dibuka dulu agar tidak diblokir pop-up
      try {
        const res = await fetch(`/api/admin/wa-link/${encodeURIComponent(btn.dataset.wa)}`);
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Gagal");
        if (win) win.location.href = data.url;
        else window.location.href = data.url;
      } catch (e) {
        if (win) win.close();
        alert("Gagal membuka WhatsApp: " + e.message);
      }
    })
  );

  tbody.querySelectorAll("[data-resend]").forEach((btn) =>
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      btn.textContent = "Mengirim...";
      try {
        const res = await fetch(`/api/admin/resend/${encodeURIComponent(btn.dataset.resend)}`, { method: "POST" });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Gagal");
        const parts = [];
        parts.push(data.email ? "email ✅" : "email ❌");
        parts.push(data.whatsapp ? "WhatsApp ✅" : "WhatsApp ❌");
        btn.textContent = parts.join(" · ");
      } catch (e) {
        btn.textContent = "Gagal";
      }
      setTimeout(() => { btn.disabled = false; btn.textContent = "Kirim ulang"; }, 4000);
    })
  );
}

async function loadMembers() {
  try {
    const me = await (await fetch("/api/admin/me")).json();
    if (!me.admin) {
      window.location.href = "admin-login.html?next=members.html";
      return;
    }
    document.getElementById("adminStatus").innerHTML =
      `Email Gmail: <b class="${me.emailEnabled ? "on" : "off"}">${me.emailEnabled ? "aktif" : "belum aktif"}</b> &nbsp;·&nbsp; ` +
      `Chat WhatsApp otomatis: <b class="${me.whatsappEnabled ? "on" : "off"}">${me.whatsappEnabled ? "aktif (" + esc(me.waProvider === "cloud" ? "Cloud API Meta" : "Fonnte") + ")" : "belum aktif"}</b> &nbsp;·&nbsp; ` +
      `Kotak masuk: <b class="${me.waInbox ? "on" : "off"}">${me.waInbox ? "aktif" : "belum aktif"}</b> &nbsp;·&nbsp; ` +
      `Bot balasan: <b class="${me.waBot ? "on" : "off"}">${me.waBot ? "aktif (" + esc(me.waBotMode) + ")" : "belum aktif"}</b> &nbsp;·&nbsp; ` +
      `Nomor WA bisnis: <b class="on">${esc(me.waDisplay || "-")}</b>`;

    const res = await fetch("/api/members");
    if (res.status === 401) {
      window.location.href = "admin-login.html?next=members.html";
      return;
    }
    allMembers = await res.json();
    render();
    loadWaLog();
    setInboxBadge(me.waUnread || 0);
    setInterval(refreshInboxBadge, 10000);
  } catch (err) {
    emptyMsg.textContent = "Gagal memuat data member.";
    emptyMsg.style.display = "block";
  }
}

searchBox.addEventListener("input", render);
tierFilter.addEventListener("change", render);
document.getElementById("logoutBtn").addEventListener("click", async () => {
  await fetch("/api/admin/logout", { method: "POST" });
  window.location.href = "admin-login.html";
});

// ---------- Lencana pesan baru di Kotak Masuk ----------
function setInboxBadge(n) {
  const b = document.getElementById("inboxBadge");
  if (!b) return;
  b.textContent = n;
  b.hidden = !n;
}
async function refreshInboxBadge() {
  try {
    const res = await fetch("/api/admin/chats-unread");
    if (res.ok) setInboxBadge((await res.json()).messages || 0);
  } catch (e) {}
}

// ---------- Riwayat chat WhatsApp otomatis ----------
const WA_KIND = {
  welcome: "Kartu baru", resend: "Kirim ulang kartu", claim: "Klaim koin", order: "Pesanan",
  tier_up: "Naik level", bot: "Balasan bot", admin: "Balasan admin", test: "Tes",
};
const WA_STATUS = {
  queued: ["Mengantre", "wa-st-queued"], sent: ["Terkirim ✓", "wa-st-sent"],
  delivered: ["Sampai ✓✓", "wa-st-delivered"], read: ["Dibaca ✓✓", "wa-st-read"], failed: ["Gagal ✗", "wa-st-failed"],
};

async function loadWaLog() {
  const body = document.getElementById("waLogBody");
  const empty = document.getElementById("waLogEmpty");
  try {
    const res = await fetch("/api/admin/wa-log?limit=100");
    if (!res.ok) return;
    const rows = await res.json();
    empty.style.display = rows.length ? "none" : "block";
    body.innerHTML = rows
      .map((r) => {
        const st = WA_STATUS[r.status] || [r.status, ""];
        const when = new Date(r.createdAt).toLocaleString("id-ID", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
        return `<tr>
          <td>${esc(when)}</td>
          <td>${esc(r.memberName || r.memberId || "-")}</td>
          <td>${esc(r.phone)}</td>
          <td>${esc(WA_KIND[r.kind] || r.kind)}</td>
          <td><span class="wa-st ${st[1]}">${esc(st[0])}</span></td>
          <td class="wa-err">${esc(r.error || "")}</td>
        </tr>`;
      })
      .join("");
  } catch (e) {}
}

document.getElementById("waLogRefresh").addEventListener("click", loadWaLog);
document.getElementById("waTestBtn").addEventListener("click", async () => {
  const msg = document.getElementById("waTestMsg");
  const phone = document.getElementById("waTestPhone").value.trim();
  msg.style.color = "";
  if (!phone) { msg.textContent = "Isi nomor HP tujuan tes dulu."; return; }
  msg.textContent = "Mengirim...";
  try {
    const res = await fetch("/api/admin/wa-test", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phone }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Gagal");
    msg.style.color = "#1e7a34";
    msg.textContent = "✅ Pesan tes terkirim. Cek WhatsApp di nomor itu.";
  } catch (e) {
    msg.style.color = "#c8102e";
    msg.textContent = "❌ " + e.message;
  }
  loadWaLog();
});

loadMembers();
