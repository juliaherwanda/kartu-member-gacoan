const creds = memberCreds(); // { id, t } dari link / tersimpan di HP ini

const memberBox = document.getElementById("memberBox");
const menuList = document.getElementById("menuList");
const cartTotalEl = document.getElementById("cartTotal");
const cartKoinEl = document.getElementById("cartKoin");
const orderBtn = document.getElementById("orderBtn");
const orderResult = document.getElementById("orderResult");

let currentMember = null;
let menu = [];
let tiers = [];
const cart = {}; // { menuId: qty }

function formatRupiah(num) {
  return "Rp " + num.toLocaleString("id-ID");
}

// ===================== MEMBER =====================
// Identitas member DIAMBIL dari link pribadi (berisi token), bukan diketik manual,
// supaya tidak ada yang bisa memesan/melihat data member lain hanya dengan menebak ID.
async function initMember() {
  if (!creds) {
    renderNoAccess();
    return;
  }
  memberBox.innerHTML = `<p style="text-align:center; color:#888;">Memuat data member...</p>`;
  try {
    const res = await fetch(`/api/member/${encodeURIComponent(creds.id)}?t=${encodeURIComponent(creds.t)}`);
    if (!res.ok) {
      clearSaved();
      renderNoAccess();
      return;
    }
    currentMember = await res.json();
    renderMemberConfirmed();
    updateCartSummary();
  } catch (err) {
    memberBox.innerHTML = `<p class="claim-error">Gagal terhubung ke server.</p>`;
  }
}

function renderNoAccess() {
  memberBox.innerHTML = `
    <p class="claim-error" style="margin:0 0 8px;">Buka halaman ini lewat <strong>link pribadi kartu member</strong> kamu (di email / WhatsApp, atau scan QR di kartu).</p>
    <p class="member-hint">Belum punya kartu member? <a href="index.html">Daftar gratis</a> · <a href="keuntungan.html">Lihat keuntungan member</a></p>
  `;
  updateOrderButtonState();
}

function renderMemberConfirmed() {
  memberBox.innerHTML = `
    <div class="member-confirmed">
      <div>
        <p class="member-confirmed-name">👤 ${esc(currentMember.name)}</p>
        <p class="member-confirmed-id">${esc(currentMember.id)} · ${esc(currentMember.tier)} · 🪙 ${esc(currentMember.koin || 0)} koin</p>
      </div>
      <a href="card.html?${memberQuery(creds)}" class="member-confirmed-link">Lihat kartu</a>
    </div>
  `;
  updateOrderButtonState();
}

// ===================== MENU =====================
async function loadMenu() {
  try {
    const res = await fetch("/api/menu");
    menu = await res.json();
    renderMenu();
  } catch (err) {
    menuList.innerHTML = `<p class="claim-error">Gagal memuat menu.</p>`;
  }
}

function renderMenu() {
  const categories = [...new Set(menu.map((m) => m.category))];

  menuList.innerHTML = categories
    .map(
      (cat) => `
      <p class="menu-category-title">${esc(cat)}</p>
      ${menu
        .filter((m) => m.category === cat)
        .map(
          (m) => `
          <div class="menu-item" data-id="${m.id}">
            <div class="menu-item-info">
              <span class="menu-item-icon">${m.icon}</span>
              <div>
                <p class="menu-item-name">${esc(m.name)}</p>
                <p class="menu-item-price">${formatRupiah(m.price)}</p>
              </div>
            </div>
            <div class="menu-item-qty">
              <button class="qty-btn qty-minus" data-id="${m.id}">−</button>
              <span class="qty-value" id="qty-${m.id}">0</span>
              <button class="qty-btn qty-plus" data-id="${m.id}">+</button>
            </div>
          </div>
        `
        )
        .join("")}
    `
    )
    .join("");

  menuList.querySelectorAll(".qty-plus").forEach((btn) =>
    btn.addEventListener("click", () => changeQty(btn.dataset.id, 1))
  );
  menuList.querySelectorAll(".qty-minus").forEach((btn) =>
    btn.addEventListener("click", () => changeQty(btn.dataset.id, -1))
  );
}

function changeQty(id, delta) {
  const current = cart[id] || 0;
  const next = Math.max(0, current + delta);
  if (next === 0) {
    delete cart[id];
  } else {
    cart[id] = next;
  }
  document.getElementById(`qty-${id}`).textContent = next;
  updateCartSummary();
}

// ===================== CART & CHECKOUT =====================
function updateCartSummary() {
  let total = 0;
  Object.entries(cart).forEach(([id, qty]) => {
    const item = menu.find((m) => m.id === id);
    if (item) total += item.price * qty;
  });

  // Rumus sama dengan calcOrder() di tiers.js (server). Server tetap menghitung ulang saat pesanan dikirim.
  let tier = { name: "Silver", orderMultiplier: 1, discountPercent: 0 };
  if (currentMember && tiers.length) {
    const k = currentMember.koin || 0;
    tiers.forEach((t) => { if (k >= t.minKoin) tier = t; });
  }
  const discount = Math.floor((total * (tier.discountPercent || 0)) / 100);
  const bayar = total - discount;
  const koin = Math.floor(Math.floor(bayar / 10000) * 5 * tier.orderMultiplier);

  document.getElementById("cartSubtotalRow").style.display = discount > 0 ? "flex" : "none";
  document.getElementById("cartDiscountRow").style.display = discount > 0 ? "flex" : "none";
  document.getElementById("cartSubtotal").textContent = formatRupiah(total);
  document.getElementById("cartDiscountLabel").textContent = `Diskon ${tier.name} ${tier.discountPercent}%`;
  document.getElementById("cartDiscount").textContent = `-${formatRupiah(discount)}`;

  cartTotalEl.textContent = formatRupiah(bayar);
  cartKoinEl.textContent = `+${koin} koin`;

  updateOrderButtonState();
}

function updateOrderButtonState() {
  const hasItems = Object.keys(cart).length > 0;
  const hasMember = !!currentMember;

  if (!hasMember) {
    orderBtn.disabled = true;
    orderBtn.textContent = "Buka lewat link kartu member";
  } else if (!hasItems) {
    orderBtn.disabled = true;
    orderBtn.textContent = "Pilih menu dulu";
  } else {
    orderBtn.disabled = false;
    orderBtn.textContent = "🧾 Pesan Sekarang & Dapat Koin";
  }
}

orderBtn.addEventListener("click", async () => {
  if (!currentMember || Object.keys(cart).length === 0) return;

  orderBtn.disabled = true;
  orderBtn.textContent = "Memproses pesanan...";
  orderResult.textContent = "";

  const items = Object.entries(cart).map(([id, qty]) => ({ id, qty }));

  try {
    const res = await fetch("/api/order", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ memberId: currentMember.id, t: creds.t, items }),
    });
    const data = await res.json();

    if (!res.ok) {
      orderResult.textContent = data.error || "Pesanan gagal.";
      orderResult.className = "claim-result claim-fail";
      updateOrderButtonState();
      return;
    }

    orderResult.textContent = `✅ ${data.message}`;
    orderResult.className = "claim-result claim-success";

    // Reset cart & refresh saldo koin member
    Object.keys(cart).forEach((id) => (cart[id] = 0));
    document.querySelectorAll(".qty-value").forEach((el) => (el.textContent = "0"));
    currentMember = data.member;
    renderMemberConfirmed();
    updateCartSummary();
  } catch (err) {
    orderResult.textContent = "Gagal terhubung ke server.";
    orderResult.className = "claim-result claim-fail";
    updateOrderButtonState();
  }
});

// ===================== INIT =====================
fetch("/api/tiers")
  .then((r) => r.json())
  .then((t) => { tiers = t; updateCartSummary(); })
  .catch(() => {});

initMember();
loadMenu();
