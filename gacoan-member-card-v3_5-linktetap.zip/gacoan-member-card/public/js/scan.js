// Halaman gerbang: satu QR untuk customer baru MAUPUN customer lama.
// Alur:
//  - HP ini menyimpan kartu member yang valid (ID + token) -> tampil "Sudah Terdaftar" + menu cepat
//  - Tidak ada / tidak valid                               -> pilihan "Belum daftar" / "Sudah daftar"
//    ("Sudah daftar" TIDAK menampilkan kartu langsung; link dikirim ke email/WhatsApp pemilik)
const $ = (id) => document.getElementById(id);

function show(stateId) {
  ["stateLoading", "stateMember", "stateChoose"].forEach((s) => {
    $(s).style.display = s === stateId ? "block" : "none";
  });
}

async function getSavedMember() {
  const c = getSaved();
  if (!c) return null;
  try {
    const res = await fetch(`/api/member/${encodeURIComponent(c.id)}?t=${encodeURIComponent(c.t)}`);
    if (res.ok) return { member: await res.json(), creds: c };
    if (res.status === 404) clearSaved(); // kartu sudah tidak ada / token tidak cocok
  } catch (e) {}
  return null;
}

function showMember(member, c) {
  const q = memberQuery(c);
  $("helloText").textContent = `Halo, ${member.name}! Kamu sudah jadi member.`;
  $("memberInfo").innerHTML =
    `${esc(member.id)} &bull; ${esc(member.tier)} &bull; 🪙 ${esc(member.koin || 0)} koin`;
  $("btnCard").href = `card.html?${q}`;
  $("btnClaim").href = `claim.html?${q}`;
  $("btnMenu").href = `menu.html?${q}`;
  show("stateMember");
}

$("notMe").addEventListener("click", (e) => {
  e.preventDefault();
  clearSaved();
  show("stateChoose");
});

$("btnAlready").addEventListener("click", () => {
  const box = $("lookupBox");
  box.style.display = box.style.display === "none" ? "block" : "none";
});

$("lookupBtn").addEventListener("click", async () => {
  const phone = $("lookupPhone").value.trim();
  const msg = $("lookupMsg");
  msg.style.color = "";
  msg.textContent = "";

  if (!phone) {
    msg.textContent = "Isi No. HP dulu.";
    return;
  }

  try {
    const res = await fetch("/api/lookup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phone }),
    });
    const data = await res.json();
    if (!res.ok) {
      msg.textContent = data.error || "Gagal memproses.";
      return;
    }
    msg.style.color = "#1e7a34";
    msg.textContent = data.message + ' Kalau memang belum pernah daftar, pilih "Belum Pernah Daftar".';
  } catch (err) {
    msg.textContent = "Tidak bisa terhubung ke server.";
  }
});

(async function init() {
  const saved = await getSavedMember();
  if (saved) showMember(saved.member, saved.creds);
  else show("stateChoose");
})();
