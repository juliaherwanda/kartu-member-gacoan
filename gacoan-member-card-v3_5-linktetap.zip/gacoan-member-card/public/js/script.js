const form = document.getElementById("registerForm");
const errorMsg = document.getElementById("errorMsg");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  errorMsg.textContent = "";

  const name = document.getElementById("name").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const email = document.getElementById("email").value.trim();
  const location = document.getElementById("location").value;

  if (!name || !phone || !email) {
    errorMsg.textContent = "Nama, No. HP, dan Email wajib diisi.";
    return;
  }

  if (!location) {
    errorMsg.textContent = "Silakan pilih lokasi outlet pendaftaran.";
    return;
  }

  try {
    const res = await fetch("/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, phone, email, location }),
    });

    const data = await res.json();

    if (!res.ok) {
      errorMsg.textContent = data.error || "Terjadi kesalahan.";
      return;
    }

    // Simpan ID + token di perangkat ini supaya kartu mudah dibuka lagi
    saveMember(data.id, data.token);

    // Redirect ke halaman kartu member (new=1 -> tampilkan info "kartu dikirim ke email")
    window.location.href = `card.html?${memberQuery({ id: data.id, t: data.token })}&new=1${data.emailWillBeSent ? "&mail=1" : ""}`;
  } catch (err) {
    errorMsg.textContent = "Tidak bisa terhubung ke server. Pastikan server berjalan.";
  }
});


// ===================== Kartu tersimpan di perangkat ini =====================
(function showSavedCard() {
  const c = getSaved();
  if (!c) return;

  fetch(`/api/member/${encodeURIComponent(c.id)}?t=${encodeURIComponent(c.t)}`)
    .then((r) => (r.ok ? r.json() : null))
    .then((member) => {
      if (!member) { clearSaved(); return; }
      const box = document.getElementById("savedCard");
      box.style.display = "block";
      box.innerHTML = `
        <p class="saved-card-title">👋 Halo, ${esc(member.name)}! Kamu sudah jadi member.</p>
        <a href="card.html?${memberQuery(c)}" class="saved-card-btn">Lihat Kartu Saya</a>
        <a href="menu.html?${memberQuery(c)}" class="saved-card-btn alt">🍜 Pesan Menu</a>`;
    })
    .catch(() => {});
})();

// ===================== Lupa kartu: kirim ulang ke email / WhatsApp =====================
document.getElementById("lookupBtn").addEventListener("click", async () => {
  const phone = document.getElementById("lookupPhone").value.trim();
  const msg = document.getElementById("lookupMsg");
  msg.style.color = "";
  msg.textContent = "";

  if (!phone) {
    msg.textContent = "Isi No. HP dulu.";
    return;
  }

  try {
    const res = await fetch("/api/lookup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phone }),
    });
    const data = await res.json();
    if (!res.ok) {
      msg.textContent = data.error || "Gagal memproses.";
      return;
    }
    msg.style.color = "#1e7a34";
    msg.textContent = data.message;
  } catch (err) {
    msg.textContent = "Tidak bisa terhubung ke server.";
  }
});
