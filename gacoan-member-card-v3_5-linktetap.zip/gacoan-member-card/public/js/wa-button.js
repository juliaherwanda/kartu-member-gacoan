// Tombol mengambang "Chat WhatsApp" ke nomor WhatsApp Business Gacoan.
// Nomor diambil dari server (/api/public-config), jadi cukup diubah di .env (WA_BUSINESS_NUMBER).
// Pesan awal hanya berisi ID member, TIDAK berisi token rahasia kartu.
(function () {
  fetch("/api/public-config")
    .then((r) => r.json())
    .then((cfg) => {
      if (!cfg || !cfg.waNumber) return;
      const p = new URLSearchParams(window.location.search);
      let id = p.get("id");
      if (!id && typeof getSaved === "function") {
        const s = getSaved();
        if (s) id = s.id;
      }
      const text = id
        ? "Halo Gacoan, saya member " + id + ". Saya ingin bertanya."
        : "Halo Gacoan, saya ingin bertanya tentang kartu member.";
      const a = document.createElement("a");
      a.className = "wa-fab no-print";
      a.href = "https://wa.me/" + cfg.waNumber + "?text=" + encodeURIComponent(text);
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      a.title = "Chat WhatsApp Gacoan " + (cfg.waDisplay || "");
      a.innerHTML = '<span aria-hidden="true">💬</span> Chat WhatsApp';
      document.body.appendChild(a);
    })
    .catch(() => {});
})();
