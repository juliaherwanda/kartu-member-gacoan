// Membuat password admin acak yang kuat (memakai crypto bawaan Node.js).
// Jalankan: npm run gen-password
// Lalu salin hasilnya ke ADMIN_PASSWORD di file .env dan restart server.
const crypto = require("crypto");

// Tanpa huruf/angka yang mirip (0 O o, 1 l I) supaya tidak salah ketik
const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";

function randomChars(n) {
  let out = "";
  while (out.length < n) {
    const b = crypto.randomBytes(1)[0];
    if (b < 256 - (256 % ALPHABET.length)) out += ALPHABET[b % ALPHABET.length]; // tanpa bias
  }
  return out;
}

const password = ["Gcn", randomChars(4), randomChars(4), randomChars(4), randomChars(4)].join("-");
console.log("\nPassword admin baru:\n\n  " + password + "\n");
console.log("Salin ke file .env:  ADMIN_PASSWORD=" + password + "\n");
