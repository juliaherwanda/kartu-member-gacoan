// Membuat (mendaftarkan) template pesan WhatsApp Gacoan ke Meta, dan memeriksa statusnya.
//
//   npm run wa-setup              -> buat 4 template, lalu kirim ke Meta untuk ditinjau
//   npm run wa-setup -- --status  -> lihat status template (PENDING / APPROVED / REJECTED)
//
// Butuh di .env:  WA_TOKEN  dan  WA_BUSINESS_ACCOUNT_ID  (ID "WhatsApp Business Account", bukan Phone Number ID)
// Token harus punya izin whatsapp_business_management.
// Persetujuan Meta biasanya beberapa menit sampai 24 jam. Chat otomatis ke member BARU baru jalan
// setelah status template = APPROVED.
const fs = require("fs");
const path = require("path");

// Muat .env (sama seperti server.js)
const envPath = path.join(__dirname, "..", ".env");
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, "utf-8").split("\n")) {
    const t = line.trim();
    if (!t || t.startsWith("#") || !t.includes("=")) continue;
    const i = t.indexOf("=");
    const k = t.slice(0, i).trim();
    let v = t.slice(i + 1).trim();
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    if (!(k in process.env)) process.env[k] = v;
  }
}

const TOKEN = process.env.WA_TOKEN || "";
const WABA = process.env.WA_BUSINESS_ACCOUNT_ID || "";
const VERSION = process.env.WA_API_VERSION || "v25.0";
const LANG = process.env.WA_TEMPLATE_LANG || "id";
const NAME = {
  welcome: process.env.WA_TEMPLATE_WELCOME || "member_baru",
  claim: process.env.WA_TEMPLATE_CLAIM || "klaim_koin",
  order: process.env.WA_TEMPLATE_ORDER || "pesanan_sukses",
  tierUp: process.env.WA_TEMPLATE_TIERUP || "naik_level",
};

// Urutan & jumlah variabel HARUS sama dengan yang dikirim whatsapp.js.
// Meta menolak template yang diawali / diakhiri variabel, jadi ada kalimat di depan dan belakang.
const TEMPLATES = [
  {
    name: NAME.welcome,
    text: "Halo {{1}}! Kartu member Gacoan kamu ({{2}}) sudah aktif. Buka dan unduh kartu di sini: {{3}} Link ini pribadi, jangan dibagikan ke orang lain. Balas KOIN, KEUNTUNGAN, atau KARTU kapan saja untuk info member.",
    example: ["Andi", "GCN-26-1234", "https://contoh.trycloudflare.com/card.html?id=GCN-26-1234&t=abc123"],
  },
  {
    name: NAME.claim,
    text: "Yeay {{1}}! Kamu dapat {{2}} koin Gacoan hari ini. Total koin kamu sekarang {{3}}. Sampai jumpa besok untuk klaim berikutnya!",
    example: ["Andi", "20", "140"],
  },
  {
    name: NAME.order,
    text: "Pesanan {{1}} berhasil dengan total Rp{{2}}. Kamu dapat {{3}} koin dari pesanan ini. Terima kasih sudah makan di Gacoan!",
    example: ["ORD-123456", "45.000", "20"],
  },
  {
    name: NAME.tierUp,
    text: "Selamat {{1}}! Level member Gacoan kamu naik menjadi {{2}}. Keuntungan barumu: {{3}}. Terima kasih sudah setia bersama Gacoan!",
    example: ["Andi", "Gold", "diskon 5% tiap pesanan, koin belanja x1,5, klaim 30 koin per hari"],
  },
];

async function graph(method, pathAndQuery, body) {
  const res = await fetch(`https://graph.facebook.com/${VERSION}/${pathAndQuery}`, {
    method,
    headers: { Authorization: `Bearer ${TOKEN}`, "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const e = data.error || {};
    throw new Error(e.error_user_msg || e.message || `HTTP ${res.status}`);
  }
  return data;
}

async function showStatus() {
  const data = await graph("GET", `${WABA}/message_templates?fields=name,language,status,rejected_reason&limit=100`);
  const mine = new Set(Object.values(NAME));
  const rows = (data.data || []).filter((t) => mine.has(t.name));
  if (!rows.length) return console.log("Belum ada template Gacoan. Jalankan: npm run wa-setup");
  for (const t of rows) {
    const why = t.status === "REJECTED" && t.rejected_reason && t.rejected_reason !== "NONE" ? `  (${t.rejected_reason})` : "";
    console.log(`${t.status.padEnd(9)} ${t.name} [${t.language}]${why}`);
  }
}

async function create() {
  for (const t of TEMPLATES) {
    try {
      const r = await graph("POST", `${WABA}/message_templates`, {
        name: t.name,
        language: LANG,
        category: "UTILITY",
        components: [{ type: "BODY", text: t.text, example: { body_text: [t.example] } }],
      });
      console.log(`✅ ${t.name}: dikirim ke Meta (status ${r.status || "PENDING"})`);
    } catch (e) {
      console.log(`⚠️  ${t.name}: ${e.message}`);
    }
  }
  console.log("\nCek status dengan: npm run wa-setup -- --status");
}

(async () => {
  if (!TOKEN || !WABA) {
    console.error("Isi WA_TOKEN dan WA_BUSINESS_ACCOUNT_ID di file .env dulu (lihat PANDUAN bagian 6).");
    process.exit(1);
  }
  try {
    if (process.argv.includes("--status")) await showStatus();
    else await create();
  } catch (e) {
    console.error("❌ Gagal:", e.message);
    process.exit(1);
  }
})();
