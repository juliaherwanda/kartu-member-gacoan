// ---------- Loader .env sederhana (tanpa dependency tambahan) ----------
// Supaya WA_TOKEN & WA_PHONE_NUMBER_ID bisa diisi lewat file .env, lihat README.
(function loadDotEnv() {
  const fs = require("fs");
  const path = require("path");
  const envPath = path.join(__dirname, ".env");
  if (!fs.existsSync(envPath)) return;
  const lines = fs.readFileSync(envPath, "utf-8").split("\n");
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eq = trimmed.indexOf("=");
    if (eq === -1) continue;
    const key = trimmed.slice(0, eq).trim();
    let value = trimmed.slice(eq + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    if (!(key in process.env)) process.env[key] = value;
  }
})();

const express = require("express");
const path = require("path");
const os = require("os");
const store = require("./db");
const whatsapp = require("./whatsapp");
const wabot = require("./wabot");
const mailer = require("./mailer");
const auth = require("./auth");
const cardpdf = require("./cardpdf");
const { TIERS, getTier, calcOrder } = require("./tiers");

const app = express();
const PORT = Number(process.env.PORT) || 3000;

// ---------- Batas permintaan (anti spam) ----------
// Data seluler (CGNAT) dan WiFi outlet dipakai BANYAK orang dengan satu alamat IP yang sama,
// jadi batas per-IP dibuat longgar supaya pelanggan sah tidak terblokir. Perlindungan utama
// tetap ada: satu nomor HP hanya bisa daftar sekali, dan email dibatasi per alamat.
// Semua angka bisa diubah lewat .env (lihat .env.example).
function envInt(name, def) {
  const n = parseInt(process.env[name], 10);
  return Number.isFinite(n) && n > 0 ? n : def;
}
const LIMITS = {
  registerPerIp: envInt("RATE_REGISTER_PER_IP", 60),       // pendaftaran per IP per jam
  registerGlobal: envInt("RATE_REGISTER_GLOBAL", 1000),    // pendaftaran seluruh dunia per jam
  lookupPerIp: envInt("RATE_LOOKUP_PER_IP", 30),           // "kirim ulang kartu" per IP per 15 menit
  memberGetPerIp: envInt("RATE_MEMBER_GET_PER_IP", 300),   // buka kartu per IP per menit
  pdfPerIp: envInt("RATE_PDF_PER_IP", 120),                // unduh PDF per IP per menit
};

// Di belakang tunnel/hosting (https), baca protokol asli dari header proxy.
app.set("trust proxy", true);

// Webhook WhatsApp dari Meta: butuh isi mentah (raw) untuk memeriksa tanda tangan X-Hub-Signature-256.
// Dipasang SEBELUM parser JSON global di bawah.
app.use("/webhook/whatsapp", express.json({
  limit: "1mb",
  verify: (req, res, buf) => { req.rawBody = buf; },
}));
// Webhook Fonnte: kiriman bisa JSON atau form biasa.
app.use("/webhook/fonnte", express.json({ limit: "200kb" }), express.urlencoded({ extended: false, limit: "200kb" }));
app.use(express.json({ limit: "20kb" }));

// Header keamanan. "no-referrer" PENTING: link kartu berisi token rahasia, jangan sampai
// ikut terkirim ke situs lain lewat header Referer.
app.use((req, res, next) => {
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "SAMEORIGIN");
  res.setHeader("X-Robots-Tag", "noindex, nofollow");
  if (req.path.startsWith("/api/")) res.setHeader("Cache-Control", "no-store");
  next();
});

// Halaman khusus admin: kalau belum login, arahkan ke halaman login.
const ADMIN_PAGES = new Set(["/members.html", "/daftar-qr.html", "/inbox.html"]);
app.use((req, res, next) => {
  if (ADMIN_PAGES.has(req.path) && !auth.isAdmin(req)) {
    return res.redirect(`/admin-login.html?next=${encodeURIComponent(req.path.slice(1))}`);
  }
  next();
});

app.use(express.static(path.join(__dirname, "public")));

// ---------- Menu Gacoan (contoh, untuk keperluan tugas CRM) ----------
const MENU = [
  // ----- MIE (satu ikon mangkuk mie untuk setiap menu) -----
  { id: "M1", category: "Mie", name: "Mie Suit Level 1", price: 10000, icon: "🍜" },
  { id: "M2", category: "Mie", name: "Mie Suit Level 8", price: 10000, icon: "🍜" },
  { id: "M3", category: "Mie", name: "Mie Hompimpa Level 1", price: 10000, icon: "🍜" },
  { id: "M4", category: "Mie", name: "Mie Hompimpa Level 8", price: 10000, icon: "🍜" },
  { id: "M5", category: "Mie", name: "Mie Gacoan Level 1", price: 10000, icon: "🍜" },
  { id: "M6", category: "Mie", name: "Mie Gacoan Level 8", price: 10000, icon: "🍜" },
  // ----- SNACK -----
  { id: "S1", category: "Snack", name: "Udang Keju", price: 12000, icon: "🍤" },
  { id: "S2", category: "Snack", name: "Siomay Ayam", price: 10000, icon: "🥟" },
  { id: "S3", category: "Snack", name: "Pangsit Goreng", price: 9000, icon: "🥟" },
  { id: "S4", category: "Snack", name: "Udang Rambutan", price: 12000, icon: "🍤" },
  // ----- MINUMAN -----
  { id: "D1", category: "Minuman", name: "Es Racun Gacoan", price: 8000, icon: "🥤" },
  { id: "D2", category: "Minuman", name: "Es Podeng Gacoan", price: 9000, icon: "🍧" },
  { id: "D3", category: "Minuman", name: "Es Teh Manis", price: 5000, icon: "🧋" },
  { id: "D4", category: "Minuman", name: "Es Lemon Tea", price: 7000, icon: "🍋" },
];

// Aturan level (Silver/Gold/Platinum), keuntungan, dan diskon ada di tiers.js.

// Samakan format nomor HP: hanya angka, awalan 62 diganti 0
function normalizePhone(p) {
  return String(p || "").replace(/\D/g, "").replace(/^62/, "0");
}

// Ambil alamat IP jaringan lokal (untuk QR yang bisa dibuka dari HP).
// Adapter virtual (VirtualBox, WSL, Docker, dll.) diurutkan paling belakang
// karena alamatnya tidak bisa dijangkau HP.
function getLocalInterfaces() {
  const virtualPattern = /virtual|vmware|vbox|vethernet|wsl|docker|hyper-v|loopback|bluetooth|tailscale|zerotier/i;
  const list = [];
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if (net.family === "IPv4" && !net.internal) {
        list.push({ name, address: net.address, virtual: virtualPattern.test(name) });
      }
    }
  }
  list.sort((a, b) => Number(a.virtual) - Number(b.virtual));
  return list;
}

function getLocalAddresses() {
  return getLocalInterfaces().map((i) => i.address);
}

// Alamat tersimpan (config SQL / PUBLIC_URL) bisa "basi" kalau komputer pindah WiFi:
// IP lokal lama (10.x / 172.16-31.x / 192.168.x) yang bukan milik komputer ini lagi
// tidak akan bisa dibuka dari HP. Alamat basi seperti itu diabaikan otomatis.
function resolvePublicUrl() {
  const saved = store.getConfig("publicUrl") || process.env.PUBLIC_URL || null;
  if (!saved) return { url: null, stale: null };
  try {
    const host = new URL(saved).hostname;
    const isPrivateIp = /^(10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+|169\.254\.\d+\.\d+)$/.test(host);
    if (isPrivateIp && !getLocalAddresses().includes(host)) {
      return { url: null, stale: saved };
    }
  } catch (e) {}
  return { url: saved, stale: null };
}

function generateMemberId() {
  const now = new Date();
  const year = now.getFullYear().toString().slice(-2);
  const random = Math.floor(1000 + Math.random() * 9000);
  return `GCN-${year}-${random}`;
}

function generateOrderId() {
  const random = Math.floor(100000 + Math.random() * 900000);
  return `ORD-${random}`;
}

// ---------- Alias pendek untuk QR: /scan -> halaman gerbang ----------
app.get("/scan", (req, res) => res.redirect("/scan.html"));

// ---------- Helper: alamat dasar & link kartu ----------
// Alamat yang dimasukkan ke QR / email / WhatsApp harus bisa dibuka dari HP customer.
function baseUrlFor(req) {
  const resolved = resolvePublicUrl();
  if (resolved.url) return resolved.url;
  const host = req.get("host") || "";
  if (/^(localhost|127\.0\.0\.1)(:|$)/i.test(host)) {
    const ip = getLocalAddresses()[0];
    if (ip) return `http://${ip}:${PORT}`;
  }
  return `${req.protocol}://${host}`;
}

function memberUrls(member, req) {
  const base = baseUrlFor(req);
  const q = `id=${encodeURIComponent(member.id)}&t=${encodeURIComponent(member.token)}`;
  return {
    cardUrl: `${base}/card.html?${q}`,
    claimUrl: `${base}/claim.html?${q}`,
    menuUrl: `${base}/menu.html?${q}`,
    pdfUrl: `${base}/api/card-pdf/${encodeURIComponent(member.id)}?t=${encodeURIComponent(member.token)}`,
    pdfName: `Kartu-Member-Gacoan-${member.id}.pdf`,
  };
}

// Data yang boleh dilihat pemilik kartu (tanpa no. HP/email/token)
function memberView(m, req) {
  const urls = memberUrls(m, req);
  return {
    id: m.id,
    name: m.name,
    location: m.location,
    joinDate: m.joinDate,
    tier: m.tier,
    koin: m.koin || 0,
    lastClaim: m.lastClaim,
    discountPercent: getTier(m.koin || 0).discountPercent,
    cardUrl: urls.cardUrl,
    claimUrl: urls.claimUrl,
  };
}

// Kirim kartu lewat email + WhatsApp (dua-duanya aman gagal, dan berjalan bersamaan
// supaya WhatsApp tidak menunggu email selesai).
async function deliverCard(member, req, reason) {
  const urls = memberUrls(member, req);
  const [email, wa] = await Promise.all([
    mailer.sendCardEmail(member, urls, reason),
    reason === "welcome"
      ? whatsapp.notifyRegistration(member, urls)
      : reason === "resend"
      ? whatsapp.resendCard(member, urls)
      : Promise.resolve({ ok: false }),
  ]);
  return { email: Boolean(email), whatsapp: Boolean(wa && wa.ok), whatsappError: (wa && wa.error) || null };
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

// ---------- Webhook WhatsApp (Meta) ----------
// Alamat yang didaftarkan di Meta: https://<alamat-publik-anda>/webhook/whatsapp
//   - GET  : verifikasi awal memakai WA_VERIFY_TOKEN
//   - POST : status pesan (terkirim/sampai/dibaca/gagal) + chat masuk dari member -> dibalas bot
app.get("/webhook/whatsapp", (req, res) => {
  const challenge = whatsapp.verifyChallenge(req.query);
  if (challenge === null) return res.sendStatus(403);
  res.status(200).type("text/plain").send(String(challenge));
});

app.post("/webhook/whatsapp", (req, res) => {
  if (!whatsapp.WEBHOOK_SECRET_READY) {
    console.warn("⚠️  Webhook WhatsApp ditolak: isi WA_APP_SECRET di .env (App Secret dari Meta) supaya tanda tangan bisa diperiksa.");
    return res.sendStatus(403);
  }
  if (!whatsapp.verifySignature(req.rawBody, req.get("x-hub-signature-256"))) return res.sendStatus(401);
  res.sendStatus(200); // balas cepat; Meta menunggu maksimal beberapa detik
  whatsapp
    .processWebhook(req.body, (msg) => onIncomingWhatsApp(msg, req))
    .catch((e) => console.error("Webhook WhatsApp:", e.message));
});

// Webhook Fonnte (jalur "fonnte"): daftarkan di fonnte.com -> Device -> Webhook:
//   https://<alamat-publik-anda>/webhook/fonnte?key=<FONNTE_WEBHOOK_KEY>
// (kalau FONNTE_WEBHOOK_KEY kosong, dipakai nilai WA_VERIFY_TOKEN)
app.all("/webhook/fonnte", (req, res) => {
  if (!whatsapp.INBOX_ENABLED || whatsapp.PROVIDER !== "fonnte") return res.sendStatus(404);
  if (!whatsapp.verifyFonnteKey(String(req.query.key || req.get("x-webhook-key") || ""))) return res.sendStatus(403);
  if (req.method !== "POST") return res.status(200).json({ ok: true }); // Fonnte kadang mengetes alamat dengan GET
  if (!auth.hit("fonnte-hook", auth.clientKey(req), 600, 60 * 1000)) return res.sendStatus(429);
  res.status(200).json({ ok: true });
  whatsapp
    .processFonnteWebhook(req.body, (msg) => onIncomingWhatsApp(msg, req))
    .catch((e) => console.error("Webhook Fonnte:", e.message));
});

// Chat masuk dari customer:
//   1. SELALU disimpan ke Kotak Masuk admin (inbox.html), ditandai belum dibaca
//   2. Bot menjawab hanya kalau: bot aktif, admin belum membalas nomor ini dalam beberapa jam terakhir,
//      dan (mode "keyword") pesannya berisi perintah seperti KOIN / KARTU, atau nomornya belum terdaftar
async function onIncomingWhatsApp(msg, req) {
  if (!whatsapp.INBOX_ENABLED || !msg || !msg.from) return;
  const phone = normalizePhone(msg.from);
  if (!/^0\d{8,14}$/.test(phone)) return;
  const member = store.findMemberByPhone(phone, normalizePhone);

  const saved = store.addChatMessage({
    phone, name: msg.name, memberId: member ? member.id : null,
    direction: "in", sender: "customer", body: String(msg.text || "[Pesan kosong]").slice(0, 4000),
    providerMsgId: msg.id,
  });
  if (saved.duplicate) return; // webhook yang sama terkirim dua kali

  if (!whatsapp.BOT_ENABLED) return;
  if (store.adminHandledRecently(phone, whatsapp.BOT_PAUSE_HOURS)) return; // admin sedang menangani
  if (whatsapp.BOT_MODE === "keyword" && member && !wabot.isCommand(msg.text)) return; // sisakan untuk admin
  if (!auth.hit("wa-bot", phone, 30, 3600 * 1000)) return; // cegah dipakai untuk spam
  const urls = member ? memberUrls(member, req) : null;
  const reply = wabot.buildReply(msg.text, member, urls, baseUrlFor(req));
  await whatsapp.sendChat({ phone, text: reply, memberId: member ? member.id : null, sender: "bot" });
}

// ---------- Tes koneksi: buka /api/ping dari HP (data seluler / WiFi mana saja) ----------
app.get("/api/ping", (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

// ---------- API: Pengaturan publik (nomor WhatsApp bisnis untuk tombol "Chat WhatsApp") ----------
app.get("/api/public-config", (req, res) => {
  res.json({ waNumber: whatsapp.BUSINESS_INTL, waDisplay: whatsapp.BUSINESS_DISPLAY });
});

// ---------- API: Unduh kartu PDF (pemilik via token, atau admin) ----------
// Link ini yang ada di tombol "Unduh Kartu (PDF)" pada email Gmail dan halaman kartu.
app.get("/api/card-pdf/:id", async (req, res) => {
  if (!auth.isAdmin(req) && !auth.hit("card-pdf", auth.clientKey(req), LIMITS.pdfPerIp, 60 * 1000)) {
    return res.status(429).send("Terlalu banyak permintaan. Tunggu sebentar.");
  }
  const member = auth.authorizeMember(req, req.params.id);
  if (!member) return res.status(404).send("Kartu tidak ditemukan atau link tidak valid.");
  try {
    const pdf = await cardpdf.buildCardPdf(member, memberUrls(member, req));
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="Kartu-Member-Gacoan-${member.id}.pdf"`);
    res.send(pdf);
  } catch (e) {
    console.error("PDF kartu gagal dibuat:", e.message);
    res.status(500).send("Gagal membuat PDF kartu.");
  }
});

// ---------- API: Daftar member baru ----------
app.post("/api/register", (req, res) => {
  if (
    !auth.hit("register", auth.clientKey(req), LIMITS.registerPerIp, 3600 * 1000) ||
    !auth.hit("register-all", "all", LIMITS.registerGlobal, 3600 * 1000)
  ) {
    return res.status(429).json({ error: "Pendaftaran sedang ramai. Tunggu beberapa menit lalu coba lagi." });
  }

  const name = String((req.body && req.body.name) || "").trim();
  const phone = String((req.body && req.body.phone) || "").trim();
  const email = String((req.body && req.body.email) || "").trim();
  const location = String((req.body && req.body.location) || "Tidak diketahui").trim();

  if (!name || !phone || !email) {
    return res.status(400).json({ error: "Nama, No. HP, dan Email wajib diisi." });
  }
  if (name.length < 2 || name.length > 60) {
    return res.status(400).json({ error: "Nama harus 2-60 karakter." });
  }
  const phoneKey = normalizePhone(phone);
  if (!/^0\d{8,13}$/.test(phoneKey)) {
    return res.status(400).json({ error: "Nomor HP tidak valid. Contoh: 081234567890" });
  }
  if (!EMAIL_RE.test(email) || email.length > 100) {
    return res.status(400).json({ error: "Format email tidak valid. Contoh: andi@gmail.com" });
  }

  // Cegah satu nomor HP mendaftar berkali-kali (anti akun ganda)
  if (store.findMemberByPhone(phoneKey, normalizePhone)) {
    return res.status(409).json({
      error: "Nomor HP ini sudah terdaftar sebagai member. Gunakan 'Kirim ulang kartu saya' di bawah form, kartu akan dikirim ke email/WhatsApp yang terdaftar.",
    });
  }

  const newMember = {
    id: generateMemberId(),
    name,
    phone,
    email,
    location: location.slice(0, 80),
    joinDate: new Date().toISOString(),
    tier: TIERS[0].name, // kartu Silver untuk member baru
    koin: 0,
    lastClaim: null,
    token: auth.newToken(),
  };

  store.insertMember(newMember);

  // Kartu juga dikirim ke email & WhatsApp setelah response, supaya pendaftaran tidak menunggu.
  deliverCard(newMember, req, "welcome").catch(() => {});

  res.json({
    ...memberView(newMember, req),
    token: newMember.token,
    emailWillBeSent: mailer.MAIL_ENABLED,
  });
});

// ---------- API: Daftar SEMUA member (khusus admin) ----------
app.get("/api/members", auth.requireAdmin, (req, res) => {
  res.json(store.readMembers().map(({ token, ...rest }) => rest));
});

// ---------- API: Ambil 1 member (pemilik via token, atau admin) ----------
app.get("/api/member/:id", (req, res) => {
  // Batasi percobaan menebak token dari satu jaringan
  if (!auth.isAdmin(req) && !auth.hit("member-get", auth.clientKey(req), LIMITS.memberGetPerIp, 60 * 1000)) {
    return res.status(429).json({ error: "Terlalu banyak permintaan. Tunggu sebentar." });
  }
  const member = auth.authorizeMember(req, req.params.id);
  // Pesan sama untuk "tidak ada" dan "token salah" supaya ID tidak bisa dites keberadaannya
  if (!member) return res.status(404).json({ error: "Kartu tidak ditemukan atau link tidak valid." });
  res.json(memberView(member, req));
});

// ---------- API: Klaim koin / promo (token member diperlukan) ----------
app.post("/api/claim/:id", (req, res) => {
  const member = auth.authorizeMember(req, req.params.id);
  if (!member) return res.status(404).json({ error: "Kartu tidak ditemukan atau link tidak valid." });

  const today = new Date().toISOString().slice(0, 10);
  const lastClaimDate = member.lastClaim ? member.lastClaim.slice(0, 10) : null;

  if (lastClaimDate === today) {
    return res.status(400).json({
      error: "Koin/promo hari ini sudah diklaim. Coba lagi besok ya!",
      koin: member.koin || 0,
      alreadyClaimed: true,
    });
  }

  const KOIN_REWARD = getTier(member.koin || 0).dailyClaim;
  const newKoin = (member.koin || 0) + KOIN_REWARD;
  const newTier = getTier(newKoin).name;
  const lastClaim = new Date().toISOString();
  store.updateMemberKoin(member.id, newKoin, newTier, lastClaim);

  const updated = { ...member, koin: newKoin, tier: newTier, lastClaim };
  res.json({
    message: `Berhasil klaim ${KOIN_REWARD} koin Gacoan!`,
    reward: KOIN_REWARD,
    koin: updated.koin,
    member: memberView(updated, req),
  });

  whatsapp.notifyClaim(updated, KOIN_REWARD);
  if (newTier !== member.tier) {
    mailer.sendCardEmail(updated, memberUrls(updated, req), "tier_up");
    whatsapp.notifyTierUp(updated, newTier);
  }
});

// ---------- API: "Lupa kartu" -> kirim ulang link ke email & WhatsApp yang terdaftar ----------
// Sengaja TIDAK menampilkan kartu di layar: kalau cukup dengan No. HP + nama, siapa pun yang
// tahu data orang lain bisa membuka kartunya. Link hanya dikirim ke kontak milik pemilik.
app.post("/api/lookup", (req, res) => {
  const phone = String((req.body && req.body.phone) || "").trim();
  if (!phone) return res.status(400).json({ error: "No. HP wajib diisi." });
  if (!auth.hit("lookup-ip", auth.clientKey(req), LIMITS.lookupPerIp, 15 * 60 * 1000)) {
    return res.status(429).json({ error: "Terlalu sering mencoba. Coba lagi 15 menit lagi." });
  }

  const key = normalizePhone(phone);
  res.json({
    ok: true,
    message: "Kalau nomor ini terdaftar, link kartu sudah dikirim ke email & WhatsApp yang terdaftar. Cek juga folder Spam.",
  });

  if (!auth.hit("lookup-phone", key, 3, 3600 * 1000)) return;
  const found = store.findMemberByPhone(key, normalizePhone);
  if (found) deliverCard(found, req, "resend").catch(() => {});
});

// ---------- API: Admin ----------
app.post("/api/admin/login", (req, res) => {
  if (!auth.ADMIN_ENABLED) {
    return res.status(503).json({ error: "Admin belum aktif. Isi ADMIN_PASSWORD (minimal 8 karakter) di file .env lalu restart server." });
  }
  const ip = auth.clientKey(req);
  if (!auth.hit("login-fail-ip", ip, 8, 15 * 60 * 1000) || !auth.hit("login-all", "all", 40, 15 * 60 * 1000)) {
    return res.status(429).json({ error: "Terlalu banyak percobaan login. Coba lagi 15 menit lagi." });
  }
  if (!auth.checkAdminPassword(String((req.body && req.body.password) || ""))) {
    return res.status(401).json({ error: "Password salah." });
  }
  auth.setAdminCookie(req, res);
  res.json({ ok: true });
});

app.post("/api/admin/logout", (req, res) => {
  auth.clearAdminCookie(res);
  res.json({ ok: true });
});

app.get("/api/admin/me", (req, res) => {
  res.json({
    admin: auth.isAdmin(req),
    adminEnabled: auth.ADMIN_ENABLED,
    emailEnabled: mailer.MAIL_ENABLED,
    whatsappEnabled: whatsapp.WA_ENABLED,
    waProvider: whatsapp.PROVIDER,
    waBot: whatsapp.BOT_ENABLED,
    waBotMode: whatsapp.BOT_MODE,
    waInbox: whatsapp.INBOX_ENABLED,
    waUnread: store.countUnread().messages,
    waDisplay: whatsapp.BUSINESS_DISPLAY,
  });
});

// Link WhatsApp siap kirim ke member (dibuka admin yang login di WhatsApp Business nomor bisnis).
// Cara cadangan yang jalan TANPA Cloud API: admin tinggal menekan "Kirim" di WhatsApp.
app.get("/api/admin/wa-link/:id", auth.requireAdmin, (req, res) => {
  const member = store.findMemberById(req.params.id);
  if (!member) return res.status(404).json({ error: "Member tidak ditemukan." });
  const urls = memberUrls(member, req);
  const text = [
    `Halo ${member.name}, kartu member Gacoan kamu (${member.id}, level ${member.tier}) sudah aktif.`,
    ``,
    `Buka kartu: ${urls.cardUrl}`,
    `Unduh PDF: ${urls.pdfUrl}`,
    ``,
    `Link ini pribadi, jangan dibagikan ke orang lain.`,
  ].join("\n");
  res.json({ url: whatsapp.memberChatUrl(member.phone, text) });
});

// Riwayat chat WhatsApp otomatis (terkirim / sampai / dibaca / gagal + alasan)
app.get("/api/admin/wa-log", auth.requireAdmin, (req, res) => {
  res.json(store.readWaLog(parseInt(req.query.limit, 10) || 100));
});

// Tes kirim WhatsApp ke satu nomor (untuk memastikan token & nomor pengirim sudah benar)
app.post("/api/admin/wa-test", auth.requireAdmin, async (req, res) => {
  if (!whatsapp.WA_ENABLED) {
    return res.status(400).json({ error: "Chat WhatsApp otomatis belum aktif. Isi WA_TOKEN + WA_PHONE_NUMBER_ID atau FONNTE_TOKEN di .env lalu restart server." });
  }
  const phone = normalizePhone((req.body && req.body.phone) || "");
  if (!/^0\d{8,13}$/.test(phone)) return res.status(400).json({ error: "Nomor HP tidak valid. Contoh: 081234567890" });
  if (!auth.hit("wa-test", "admin", 30, 3600 * 1000)) return res.status(429).json({ error: "Terlalu banyak tes. Coba lagi nanti." });
  const result = await whatsapp.sendTest(phone);
  res.status(result.ok ? 200 : 502).json(result.ok ? { ok: true } : { error: result.error || "Gagal mengirim." });
});

// ---------- Kotak Masuk WhatsApp (admin membalas chat customer secara langsung) ----------
const PHONE_PARAM_RE = /^0\d{8,14}$/;

// Percakapan boleh dibalas teks bebas? (Cloud API: hanya dalam 24 jam sejak customer terakhir chat)
function convoView(c) {
  const can = whatsapp.canReplyFreely(c);
  return {
    phone: c.phone,
    name: c.memberName || c.name || "",
    waName: c.name || "",
    memberId: c.memberId || null,
    memberTier: c.memberTier || null,
    lastAt: c.lastAt,
    lastText: c.lastText || "",
    unread: c.unread || 0,
    lastInboundAt: c.lastInboundAt || null,
    canReply: can.ok,
    cannotReplyReason: can.ok ? null : can.reason,
  };
}

app.get("/api/admin/chats", auth.requireAdmin, (req, res) => {
  res.json({
    enabled: whatsapp.INBOX_ENABLED,
    provider: whatsapp.PROVIDER,
    unread: store.countUnread(),
    chats: store.listConvos(200).map(convoView),
  });
});

app.get("/api/admin/chats-unread", auth.requireAdmin, (req, res) => {
  res.json(store.countUnread());
});

app.get("/api/admin/chats/:phone", auth.requireAdmin, (req, res) => {
  const phone = normalizePhone(req.params.phone);
  if (!PHONE_PARAM_RE.test(phone)) return res.status(400).json({ error: "Nomor tidak valid." });
  const convo = store.getConvo(phone);
  if (!convo) return res.status(404).json({ error: "Belum ada percakapan dengan nomor ini." });
  if (req.query.markRead !== "0") store.markConvoRead(phone);
  const member = convo.memberId ? store.findMemberById(convo.memberId) : null;
  res.json({
    chat: convoView({ ...convo, unread: req.query.markRead !== "0" ? 0 : convo.unread }),
    member: member
      ? { id: member.id, name: member.name, tier: member.tier, koin: member.koin || 0, email: member.email || "", location: member.location || "", joinDate: member.joinDate }
      : null,
    messages: store.readChat(phone, 300).map((m) => ({
      id: m.id, at: m.createdAt, direction: m.direction, sender: m.sender,
      body: m.body, status: m.status, error: m.error,
    })),
  });
});

app.post("/api/admin/chats/:phone/reply", auth.requireAdmin, async (req, res) => {
  const phone = normalizePhone(req.params.phone);
  if (!PHONE_PARAM_RE.test(phone)) return res.status(400).json({ error: "Nomor tidak valid." });
  const text = String((req.body && req.body.text) || "").trim();
  if (!text) return res.status(400).json({ error: "Tulis balasan dulu." });
  if (text.length > 2000) return res.status(400).json({ error: "Balasan terlalu panjang (maksimal 2000 huruf)." });
  const convo = store.getConvo(phone);
  if (!convo) return res.status(404).json({ error: "Belum ada percakapan dengan nomor ini." });
  const can = whatsapp.canReplyFreely(convo);
  if (!can.ok) return res.status(409).json({ error: can.reason });
  if (!auth.hit("wa-admin-reply", "admin", 300, 3600 * 1000)) return res.status(429).json({ error: "Terlalu banyak balasan dalam satu jam. Coba lagi nanti." });
  const result = await whatsapp.sendChat({ phone, text, memberId: convo.memberId, sender: "admin" });
  res.status(result.ok ? 200 : 502).json(result.ok ? { ok: true } : { error: result.error || "Gagal mengirim." });
});

// Kirim ulang kartu ke email + WhatsApp member
app.post("/api/admin/resend/:id", auth.requireAdmin, async (req, res) => {
  const member = store.findMemberById(req.params.id);
  if (!member) return res.status(404).json({ error: "Member tidak ditemukan." });
  const result = await deliverCard(member, req, "resend");
  res.json(result);
});

// Pratinjau tampilan email kartu di browser (tanpa mengirim apa pun)
app.get("/api/admin/email-preview/:id", auth.requireAdmin, async (req, res) => {
  const member = store.findMemberById(req.params.id);
  if (!member) return res.status(404).send("Member tidak ditemukan.");
  const mail = await mailer.buildCardEmail(member, memberUrls(member, req), { qrMode: "data" });
  res.type("html").send(mail.html);
});

// ---------- API: Buka alamat server (halaman poster QR, khusus admin) ----------
app.get("/api/server-info", auth.requireAdmin, (req, res) => {
  const resolved = resolvePublicUrl();
  res.json({
    port: PORT,
    addresses: getLocalAddresses(),
    interfaces: getLocalInterfaces(),
    publicUrl: resolved.url,
    staleUrl: resolved.stale, // alamat lama yang sudah tidak aktif di jaringan ini
  });
});

// ---------- API: Simpan alamat resmi untuk QR kartu (khusus admin) ----------
app.post("/api/config", auth.requireAdmin, (req, res) => {
  let url = String((req.body && req.body.publicUrl) || "").trim().replace(/\/+$/, "");
  if (url && !/^https?:\/\/[^\s]+$/i.test(url)) {
    return res.status(400).json({ error: "Alamat tidak valid. Contoh: https://member.namakamu.com" });
  }

  if (url) store.setConfig("publicUrl", url);
  else store.deleteConfig("publicUrl");
  res.json({ publicUrl: url || null });
});

// ---------- API: Ambil daftar level member (Silver/Gold/Platinum) ----------
app.get("/api/tiers", (req, res) => {
  res.json(TIERS);
});

// ---------- API: Ambil daftar menu Gacoan ----------
app.get("/api/menu", (req, res) => {
  res.json(MENU);
});

// ---------- API: Riwayat pesanan 1 member (pemilik via token, atau admin) ----------
app.get("/api/orders/:memberId", (req, res) => {
  const member = auth.authorizeMember(req, req.params.memberId);
  if (!member) return res.status(404).json({ error: "Kartu tidak ditemukan atau link tidak valid." });
  res.json(store.readOrdersByMember(member.id));
});

// ---------- API: Pesan menu -> otomatis dapat koin sesuai total belanja ----------

app.post("/api/order", (req, res) => {
  const { memberId, items } = req.body;

  if (!memberId || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: "ID member dan minimal 1 item menu wajib diisi." });
  }

  const member = auth.authorizeMember(req, String(memberId));
  if (!member) {
    return res.status(404).json({ error: "Kartu tidak ditemukan atau link tidak valid." });
  }

  // Validasi & hitung ulang harga dari data MENU di server (supaya tidak bisa dimanipulasi dari client)
  let total = 0;
  const validatedItems = [];

  for (const item of items) {
    const menuItem = MENU.find((m) => m.id === item.id);
    if (!menuItem) continue;
    const qty = Math.min(50, Math.max(1, parseInt(item.qty) || 1)); // batas 50 per item
    total += menuItem.price * qty;
    validatedItems.push({ id: menuItem.id, name: menuItem.name, price: menuItem.price, qty });
  }

  if (validatedItems.length === 0) {
    return res.status(400).json({ error: "Item menu tidak valid." });
  }

  // Diskon & koin dihitung dari level member SEKARANG (aturan di tiers.js).
  const subtotal = total;
  const tier = getTier(member.koin || 0);
  const calc = calcOrder(subtotal, tier);
  const koinEarned = calc.koinEarned;
  const newKoin = (member.koin || 0) + koinEarned;
  const newTier = getTier(newKoin).name;
  store.updateMemberKoin(member.id, newKoin, newTier, member.lastClaim);

  const order = {
    id: generateOrderId(),
    memberId,
    items: validatedItems,
    subtotal,
    discount: calc.discount,
    total: calc.total, // jumlah yang dibayar (setelah diskon)
    koinEarned,
    createdAt: new Date().toISOString(),
  };
  store.insertOrder(order);

  const updated = { ...member, koin: newKoin, tier: newTier };
  res.json({
    message: calc.discount > 0
      ? `Pesanan berhasil! Diskon ${tier.name} ${tier.discountPercent}% (hemat Rp${calc.discount.toLocaleString("id-ID")}). Kamu dapat ${koinEarned} koin dari belanja ini.`
      : `Pesanan berhasil! Kamu dapat ${koinEarned} koin dari belanja ini.`,
    order,
    koin: updated.koin,
    member: memberView(updated, req),
  });

  whatsapp.notifyOrder(updated, order);
  if (newTier !== member.tier) {
    mailer.sendCardEmail(updated, memberUrls(updated, req), "tier_up");
    whatsapp.notifyTierUp(updated, newTier);
  }
});

app.listen(PORT, "0.0.0.0", () => {  // 0.0.0.0 = bisa diakses dari HP di jaringan yang sama
  console.log(`\n✅ Server berjalan di http://localhost:${PORT}`);
  console.log(`   Buka browser dan akses alamat di atas untuk mulai mendaftar.`);
  const ips = getLocalAddresses();
  if (ips.length) {
    console.log(`\n📱 Alamat di bawah HANYA bisa dibuka dari WiFi yang sama (untuk tes).`);
    console.log(`   Supaya QR bisa discan dari data seluler & WiFi mana pun: jalankan  npm run public  (atau isi PUBLIC_URL di .env)`);
    ips.forEach((ip) => console.log(`   http://${ip}:${PORT}`));
  }
  const stale = resolvePublicUrl().stale;
  if (stale) {
    console.log(`\n⚠️  Alamat QR tersimpan (${stale}) bukan IP komputer ini lagi -> diabaikan otomatis.`);
  }
  console.log(`\n🗄️  Database SQL: data/gacoan.db (SQLite)`);
  console.log(`🔐 Admin: ${auth.ADMIN_ENABLED ? "AKTIF -> http://localhost:" + PORT + "/admin-login.html" : "BELUM AKTIF (isi ADMIN_PASSWORD minimal 8 karakter di .env)"}`);
  console.log(`✉️  Email Gmail: ${mailer.MAIL_ENABLED ? "AKTIF" : "belum diaktifkan (isi GMAIL_USER & GMAIL_APP_PASSWORD di .env)"}`);
  console.log(`📲 WhatsApp Business ${whatsapp.BUSINESS_DISPLAY}: tombol chat & link kirim manual AKTIF`);
  if (whatsapp.PROVIDER === "cloud") {
    console.log(`   Chat otomatis ke member: AKTIF (Cloud API resmi Meta)`);
    console.log(`   Kotak masuk admin      : ${whatsapp.INBOX_ENABLED ? "AKTIF -> http://localhost:" + PORT + "/inbox.html (webhook /webhook/whatsapp)" : "belum aktif (isi WA_APP_SECRET + WA_VERIFY_TOKEN lalu daftarkan webhook di Meta)"}`);
    console.log(`   Balasan otomatis (bot) : ${whatsapp.BOT_ENABLED ? "AKTIF, mode " + whatsapp.BOT_MODE : "mati"}`);
  } else if (whatsapp.PROVIDER === "fonnte") {
    console.log(`   Chat otomatis ke member: AKTIF (gateway Fonnte, bukan jalur resmi Meta)`);
    console.log(`   Kotak masuk admin      : ${whatsapp.INBOX_ENABLED ? "AKTIF -> http://localhost:" + PORT + "/inbox.html (webhook /webhook/fonnte?key=...)" : "belum aktif (isi FONNTE_WEBHOOK_KEY atau WA_VERIFY_TOKEN di .env lalu daftarkan webhook di Fonnte)"}`);
    console.log(`   Balasan otomatis (bot) : ${whatsapp.BOT_ENABLED ? "AKTIF, mode " + whatsapp.BOT_MODE : "mati"}`);
  } else {
    console.log(`   Chat otomatis ke member: belum aktif (isi WA_TOKEN + WA_PHONE_NUMBER_ID, atau FONNTE_TOKEN, di .env)`);
  }
  console.log(`\n🖨️  Poster QR pendaftaran: http://localhost:${PORT}/daftar-qr.html\n`);
});
