// ---------- Level Member (Silver / Gold / Platinum) ----------
// SATU-SATUNYA tempat untuk mengubah aturan level dan keuntungan.
// Server, email, PDF kartu, dan halaman "Keuntungan Member" semua membaca dari file ini,
// jadi angka di layar, di email, dan di perhitungan pesanan tidak mungkin berbeda.
//
// Kolom yang DIHITUNG OTOMATIS oleh aplikasi:
//   minKoin         : koin minimal untuk masuk level ini
//   dailyClaim      : koin yang didapat dari klaim harian
//   orderMultiplier : pengali koin dari belanja (dasar: 5 koin per Rp10.000 yang dibayar)
//   discountPercent : diskon otomatis pada setiap pesanan lewat halaman Pesan Menu
// Kolom "perks" adalah teks yang ditampilkan ke member. Poin yang bertanda
// "(dikelola outlet)" tidak dihitung aplikasi, jadi dijalankan manual oleh pihak outlet.

const KOIN_PER_10K = 5; // setiap kelipatan Rp10.000 yang dibayar = 5 koin (sebelum pengali level)

const TIERS = [
  {
    key: "silver",
    name: "Silver",
    minKoin: 0,
    dailyClaim: 20,
    orderMultiplier: 1,
    discountPercent: 0,
    perks: [
      "Kartu member digital, bisa diunduh PDF dari Gmail",
      "Koin dari setiap belanja (5 koin per Rp10.000)",
      "Klaim 20 koin setiap hari",
      "Riwayat pesanan tercatat",
      "Info promo member lewat email dan WhatsApp",
    ],
  },
  {
    key: "gold",
    name: "Gold",
    minKoin: 150,
    dailyClaim: 30,
    orderMultiplier: 1.5,
    discountPercent: 5,
    perks: [
      "Semua keuntungan Silver",
      "Koin belanja x1,5",
      "Klaim 30 koin setiap hari",
      "Diskon 5% untuk setiap pesanan lewat aplikasi",
      "Promo khusus member Gold (dikelola outlet)",
    ],
  },
  {
    key: "platinum",
    name: "Platinum",
    minKoin: 400,
    dailyClaim: 40,
    orderMultiplier: 2,
    discountPercent: 10,
    perks: [
      "Semua keuntungan Gold",
      "Koin belanja x2",
      "Klaim 40 koin setiap hari",
      "Diskon 10% untuk setiap pesanan lewat aplikasi",
      "Info menu baru dan promo lebih awal lewat WhatsApp (dikelola outlet)",
    ],
  },
];

function getTier(koin) {
  let current = TIERS[0];
  for (const t of TIERS) {
    if (koin >= t.minKoin) current = t;
  }
  return current;
}

function getTierByName(name) {
  return TIERS.find((t) => t.name === name) || TIERS[0];
}

// Hitung satu pesanan. Dipakai server.js, jadi harga/koin tidak bisa dimanipulasi dari browser.
//   subtotal : jumlah harga menu sebelum diskon
//   Hasil    : { discount, total (yang dibayar), koinEarned }
// Koin dihitung dari jumlah yang DIBAYAR (setelah diskon), seperti program loyalti pada umumnya.
function calcOrder(subtotal, tier) {
  const discount = Math.floor((subtotal * (tier.discountPercent || 0)) / 100);
  const total = subtotal - discount;
  const baseKoin = Math.floor(total / 10000) * KOIN_PER_10K;
  const koinEarned = Math.floor(baseKoin * tier.orderMultiplier);
  return { discount, total, koinEarned };
}

module.exports = { TIERS, KOIN_PER_10K, getTier, getTierByName, calcOrder };
