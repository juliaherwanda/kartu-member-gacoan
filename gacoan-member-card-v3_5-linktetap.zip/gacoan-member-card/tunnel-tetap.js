// Jalankan server + LINK PUBLIK TETAP (tidak berubah-ubah) memakai Cloudflare Tunnel bernama.
//
// Pemakaian:  npm run tetap
//
// Syarat (sekali saja, lihat LINK-TETAP.md):
//   1. Punya domain yang DNS-nya dikelola Cloudflare.
//   2. Buat Tunnel di Cloudflare Zero Trust, arahkan hostname (mis. member.domainkamu.com)
//      ke  http://localhost:3000
//   3. Isi di .env:
//        PUBLIC_URL=https://member.domainkamu.com
//        CLOUDFLARE_TUNNEL_TOKEN=token_dari_cloudflare
//
// Pakai SATU perintah ini saja. Jangan jalankan "npm start" atau "npm run public" bersamaan.
const fs = require("fs");
const { spawn } = require("child_process");
const { bin, install } = require("cloudflared");

require("./server.js"); // start server lokal sekaligus membaca .env
const store = require("./db");

const PORT = Number(process.env.PORT) || 3000;
const TOKEN = (process.env.CLOUDFLARE_TUNNEL_TOKEN || "").trim();
const PUBLIC_URL = (process.env.PUBLIC_URL || "").trim().replace(/\/+$/, "");

if (!TOKEN || !/^https:\/\//i.test(PUBLIC_URL)) {
  console.error("\n❌ Link tetap belum diatur di .env. Isi dua baris ini lalu jalankan lagi:");
  console.error("   PUBLIC_URL=https://member.domainkamu.com");
  console.error("   CLOUDFLARE_TUNNEL_TOKEN=token_dari_cloudflare");
  console.error("   Panduan: LINK-TETAP.md\n");
  process.exit(1);
}

// Alamat lama dari "npm run public" (trycloudflare) bisa tersisa di database kalau program
// dimatikan paksa. Alamat itu didahulukan server, jadi timpa dengan alamat tetap.
try { store.setConfig("publicUrl", PUBLIC_URL); } catch (e) { console.error("Gagal menyimpan alamat:", e.message); }

let cf = null;
let stopping = false;
let retryMs = 3000;
let announced = false;

function banner() {
  console.log("\n==============================================================");
  console.log("🌍 LINK TETAP AKTIF (HP mana saja, data seluler / WiFi lain):");
  console.log("   " + PUBLIC_URL);
  console.log("   QR, email, dan WhatsApp otomatis memakai link ini.");
  console.log(`   Tes dari HP (matikan WiFi, pakai data): ${PUBLIC_URL}/api/ping`);
  console.log(`   Admin  : http://localhost:${PORT}/admin-login.html`);
  console.log("   Poster : login admin, lalu buka /daftar-qr.html dan klik Perbarui QR.");
  console.log("   Link ini TIDAK berubah walau program dijalankan ulang.");
  console.log("   Komputer dan jendela ini harus tetap menyala. Tutup dengan Ctrl + C.");
  console.log("==============================================================\n");
}

function startTunnel() {
  if (stopping) return;
  cf = spawn(bin, ["tunnel", "--no-autoupdate", "run", "--token", TOKEN]);

  function onData(buf) {
    const text = buf.toString();
    if (/Registered tunnel connection|Connection .* registered/i.test(text)) {
      retryMs = 3000;
      if (!announced) { announced = true; banner(); }
    }
    if (/unauthorized|invalid token|failed to unmarshal|Provided Tunnel token is not valid/i.test(text)) {
      console.error("\n❌ Token Cloudflare ditolak. Salin ulang token dari Cloudflare Zero Trust ke CLOUDFLARE_TUNNEL_TOKEN.");
    }
  }
  cf.stdout.on("data", onData);
  cf.stderr.on("data", onData);

  cf.on("error", (err) => {
    console.error("\n❌ Gagal menjalankan cloudflared:", err.message);
    process.exit(1);
  });

  cf.on("exit", (code) => {
    if (stopping) return;
    console.error(`\n⚠️  Tunnel terputus (kode ${code}). Menyambung ulang dalam ${Math.round(retryMs / 1000)} detik...`);
    setTimeout(startTunnel, retryMs);
    retryMs = Math.min(retryMs * 2, 60000);
  });
}

async function main() {
  if (!fs.existsSync(bin)) {
    console.log("⬇️  Mengunduh cloudflared (hanya sekali, mohon tunggu)...");
    await install(bin);
    console.log("✅ cloudflared siap.\n");
  }
  startTunnel();

  function cleanup() {
    stopping = true;
    try { cf && cf.kill(); } catch {}
    process.exit(0);
  }
  process.on("SIGINT", cleanup);
  process.on("SIGTERM", cleanup);
}

main();
