// Jalankan server + buat LINK PUBLIK (https) supaya QR bisa dibuka dari HP SIAPA SAJA:
// data seluler maupun WiFi mana pun, tidak perlu satu jaringan dengan komputer.
//
// Pemakaian:  npm run public
//
// Alat tunnel (cloudflared) diunduh otomatis oleh paket npm "cloudflared" saat
// `npm install`. Butuh koneksi internet biasa di komputer ini.
// Kalau tunnel terputus (internet mati sebentar), program otomatis menyambung ulang.
const fs = require("fs");
const { spawn } = require("child_process");
const { bin, install } = require("cloudflared");

require("./server.js"); // start server lokal (port dari .env, default 3000)
const store = require("./db");

const PORT = Number(process.env.PORT) || 3000;

let cf = null;
let stopping = false;
let currentUrl = null;
let retryMs = 3000;

function banner(url, changed) {
  console.log("\n==============================================================");
  console.log(changed ? "🌍 LINK PUBLIK BARU AKTIF (HP mana saja, data seluler / WiFi lain):" : "🌍 LINK PUBLIK AKTIF (HP mana saja, data seluler / WiFi lain):");
  console.log("   " + url);
  console.log("   QR, email, dan WhatsApp otomatis memakai link ini.");
  console.log(`   Tes dari HP (matikan WiFi, pakai data): ${url}/api/ping`);
  console.log(`   Admin  : http://localhost:${PORT}/admin-login.html`);
  console.log("   Poster : login admin, lalu buka /daftar-qr.html dan klik Perbarui QR.");
  if (changed) {
    console.log("   ⚠️  Link berubah karena tunnel tersambung ulang -> cetak ulang poster QR.");
  } else {
    console.log("   Link ini BERUBAH tiap npm run public dijalankan ulang, jadi cetak");
    console.log("   poster SETELAH link muncul, dan biarkan jendela ini tetap terbuka.");
    console.log("   Mau link TETAP selamanya? Lihat PANDUAN bagian 8 (PUBLIC_URL).");
  }
  console.log("   Tutup dengan Ctrl + C.");
  console.log("==============================================================\n");
}

function startTunnel() {
  if (stopping) return;
  let found = false;
  cf = spawn(bin, ["tunnel", "--no-autoupdate", "--url", `http://localhost:${PORT}`]);

  function onData(buf) {
    const m = buf.toString().match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/i);
    if (m && !found) {
      found = true;
      retryMs = 3000;
      const changed = Boolean(currentUrl) && currentUrl !== m[0];
      currentUrl = m[0];
      store.setConfig("publicUrl", currentUrl);
      banner(currentUrl, changed);
    }
  }
  cf.stdout.on("data", onData);
  cf.stderr.on("data", onData);

  cf.on("error", (err) => {
    console.error("\n❌ Gagal menjalankan cloudflared:", err.message);
    process.exit(1);
  });

  cf.on("exit", (code) => {
    if (stopping) return;
    console.error(`\n⚠️  Tunnel terputus (kode ${code}). Menyambung ulang dalam ${Math.round(retryMs / 1000)} detik...`);
    setTimeout(startTunnel, retryMs);
    retryMs = Math.min(retryMs * 2, 60000);
  });
}

async function main() {
  if (!fs.existsSync(bin)) {
    console.log("⬇️  Mengunduh cloudflared (hanya sekali, mohon tunggu)...");
    await install(bin);
    console.log("✅ cloudflared siap.\n");
  }
  startTunnel();

  function cleanup() {
    stopping = true;
    try { store.deleteConfig("publicUrl"); } catch {}
    try { cf && cf.kill(); } catch {}
    process.exit(0);
  }
  process.on("SIGINT", cleanup);
  process.on("SIGTERM", cleanup);
}

main();
