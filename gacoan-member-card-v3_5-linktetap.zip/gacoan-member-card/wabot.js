// ---------- Balasan otomatis WhatsApp (bot) ----------
// Dipakai saat member / calon member mengirim chat ke nomor WhatsApp Business Gacoan.
// Fungsi murni: teks masuk -> teks balasan. Pengirimannya diurus whatsapp.js.
//
// Kata kunci (huruf besar/kecil bebas):
//   KOIN / POIN      -> saldo koin + level + sisa koin ke level berikutnya
//   KEUNTUNGAN       -> keuntungan level member + level di atasnya
//   KARTU / PDF      -> link kartu member + PDF
//   KLAIM            -> link klaim koin harian
//   MENU / ORDER     -> link pesan menu
//   BANTUAN / HELP   -> daftar perintah
//   (pesan lain)     -> sapaan + ringkasan akun
// Nomor yang belum terdaftar mendapat link pendaftaran.
//
// Mode bot (WA_BOT_MODE di .env):
//   keyword (bawaan) -> bot hanya menjawab kata kunci di atas. Pesan lain dibiarkan untuk admin
//                       (muncul di Kotak Masuk WhatsApp admin).
//   auto             -> bot menjawab SEMUA pesan member (sapaan + ringkasan akun) seperti dulu.
//   off              -> bot mati total, semua chat masuk ke Kotak Masuk admin.
// Setelah admin membalas satu nomor, bot diam untuk nomor itu selama WA_BOT_PAUSE_HOURS (bawaan 12 jam).
//
// Link kartu berisi token rahasia, tapi balasan HANYA dikirim ke nomor HP yang terdaftar
// sebagai pemilik kartu, jadi aman.
const { getTier } = require("./tiers");
const wa = require("./whatsapp");

const has = (t, re) => re.test(t);

// Kata kunci yang dikenali bot. Dipakai buildReply (isi balasan) dan isCommand (apakah perlu dibalas bot).
const RE = {
  koin: /\b(koin|poin|saldo|coin)\b/,
  benefit: /\b(keuntungan|benefit|manfaat|level|tier|silver|gold|platinum)\b/,
  claim: /\b(klaim|claim)\b/,
  menu: /\b(menu|order)\b/,
  card: /\b(kartu|card|pdf|unduh|download)\b/,
  help: /\b(bantuan|help|tolong|bantu)\b/,
};

// true kalau pesan berisi salah satu perintah di atas.
// Dipakai mode bot "keyword": pesan lain (pertanyaan bebas) dibiarkan untuk dibalas admin.
function isCommand(text) {
  const t = String(text || "").toLowerCase();
  return Object.values(RE).some((re) => re.test(t));
}

function commandList() {
  return [
    `Perintah yang bisa kamu kirim:`,
    `• KOIN — cek koin & level`,
    `• KEUNTUNGAN — keuntungan levelmu`,
    `• KARTU — link kartu member`,
    `• KLAIM — klaim koin harian`,
    `• MENU — pesan menu`,
  ].join("\n");
}

// member : data member (atau null kalau nomor belum terdaftar)
// urls   : memberUrls(member) (atau null)
// baseUrl: alamat publik website
function buildReply(text, member, urls, baseUrl) {
  const t = String(text || "").toLowerCase();

  if (!member) {
    return [
      `Halo! 👋 Nomor ini belum terdaftar sebagai member Gacoan.`,
      ``,
      `Daftar gratis, cuma 1 menit: ${baseUrl}/scan.html`,
      `Setelah daftar, kartu member dikirim otomatis ke WhatsApp ini.`,
    ].join("\n");
  }

  const koin = member.koin || 0;
  const tier = getTier(koin);

  if (has(t, RE.koin)) {
    return [
      `🪙 Koin kamu: ${koin}`,
      `🏅 Level: ${tier.name}`,
      ``,
      wa.nextTierLine(koin),
    ].join("\n");
  }

  if (has(t, RE.benefit)) {
    const lines = [`Keuntungan level ${tier.name} kamu:`, wa.perksBullets(tier), ``];
    const info = wa.nextTierInfo(koin);
    if (info) {
      lines.push(`Level berikutnya, ${info.next.name} (butuh ${info.next.minKoin} koin, kurang ${info.need}):`, wa.perksBullets(info.next));
    } else {
      lines.push(`Kamu sudah di level tertinggi, Platinum. 🎉`);
    }
    return lines.join("\n");
  }

  if (has(t, RE.claim)) {
    return `🪙 Klaim koin harian kamu (${tier.dailyClaim} koin) di sini:\n${urls.claimUrl}`;
  }

  if (has(t, RE.menu)) {
    return `🍜 Pesan menu Gacoan (diskon level ${tier.name}: ${tier.discountPercent}%):\n${urls.menuUrl}`;
  }

  if (has(t, RE.card)) {
    return [
      `💳 Kartu member ${member.id} (level ${tier.name}):`,
      `Buka kartu: ${urls.cardUrl}`,
      `Unduh PDF: ${urls.pdfUrl}`,
      ``,
      `Link ini pribadi, jangan dibagikan ke orang lain.`,
    ].join("\n");
  }

  if (has(t, RE.help)) {
    return commandList();
  }

  // Pesan apa pun dari member (mis. "Halo Gacoan, saya member GCN-...")
  return [
    `Halo ${member.name}! 👋 Terima kasih sudah menghubungi Gacoan.`,
    `🆔 ${member.id}  •  🏅 ${tier.name}  •  🪙 ${koin} koin`,
    ``,
    `💳 Kartu member: ${urls.cardUrl}`,
    ``,
    commandList(),
  ].join("\n");
}

module.exports = { buildReply, isCommand };
