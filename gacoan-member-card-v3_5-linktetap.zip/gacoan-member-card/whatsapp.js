// ---------- Integrasi WhatsApp Business Gacoan ----------
// Nomor WhatsApp Business: 089529705141 (bisa diganti di .env -> WA_BUSINESS_NUMBER).
//
// Yang dikerjakan modul ini:
//   1. Mengirim chat OTOMATIS ke nomor HP member yang sudah daftar:
//        - kartu member baru (saat daftar), kirim ulang kartu, klaim koin harian,
//          pesanan berhasil, dan naik level (Silver -> Gold -> Platinum)
//   2. Mencatat setiap pengiriman (terkirim / sampai / dibaca / gagal + alasannya) di tabel wa_log
//   3. Menerima webhook Meta: status pesan, dan membalas chat member otomatis (KOIN, KARTU, dst.)
//
// DUA JALUR PENGIRIMAN (dipilih otomatis lewat .env, atau paksa dengan WA_PROVIDER):
//
//   A. "cloud"  = WhatsApp Cloud API RESMI dari Meta (disarankan, aman untuk nomor bisnis).
//                 Butuh WA_TOKEN + WA_PHONE_NUMBER_ID milik nomor 089529705141 di Meta Business.
//                 Pesan PERTAMA ke member (di luar 24 jam sejak member chat) wajib memakai
//                 "Message Template" yang disetujui Meta -> jalankan:  npm run wa-setup
//
//   B. "fonnte" = layanan gateway pihak ketiga (fonnte.com). Nomor 089529705141 ditautkan dengan
//                 scan QR, TANPA template dan tanpa persetujuan Meta. Cuma butuh FONNTE_TOKEN.
//                 CATATAN: ini bukan jalur resmi Meta. WhatsApp melarang pengiriman otomatis lewat
//                 WhatsApp Web, sehingga ada risiko nomor dibatasi/diblokir. Pakai untuk uji coba
//                 atau volume kecil, dan jangan dipakai untuk blast/promosi massal.
//
// Semua fungsi notify* "aman gagal": kalau WhatsApp error, pendaftaran / klaim / pesanan
// member di aplikasi TETAP berhasil, dan kegagalannya tercatat di log untuk dilihat admin.
const crypto = require("crypto");
const store = require("./db");
const { TIERS, getTier } = require("./tiers");

// ---------- Konfigurasi ----------
const GRAPH_VERSION = process.env.WA_API_VERSION || "v25.0"; // bisa diganti lewat .env
const WA_TOKEN = process.env.WA_TOKEN || "";
const WA_PHONE_NUMBER_ID = process.env.WA_PHONE_NUMBER_ID || "";
const FONNTE_TOKEN = process.env.FONNTE_TOKEN || "";
const WA_VERIFY_TOKEN = process.env.WA_VERIFY_TOKEN || "";
const WA_APP_SECRET = process.env.WA_APP_SECRET || "";

const BUSINESS_NUMBER = process.env.WA_BUSINESS_NUMBER || "089529705141";

function pickProvider() {
  const cloudOk = Boolean(WA_TOKEN && WA_PHONE_NUMBER_ID);
  const fonnteOk = Boolean(FONNTE_TOKEN);
  const want = String(process.env.WA_PROVIDER || "auto").toLowerCase();
  if (want === "off") return "none";
  if (want === "cloud") return cloudOk ? "cloud" : "none";
  if (want === "fonnte") return fonnteOk ? "fonnte" : "none";
  return cloudOk ? "cloud" : fonnteOk ? "fonnte" : "none";
}
const PROVIDER = pickProvider(); // "cloud" | "fonnte" | "none"
const WA_ENABLED = PROVIDER !== "none";

// ---------- Kotak masuk admin + balasan otomatis (bot) ----------
// Chat MASUK dari customer hanya bisa diterima lewat webhook, jadi:
//   cloud  -> webhook Meta (/webhook/whatsapp), wajib WA_APP_SECRET supaya tanda tangan bisa diperiksa
//   fonnte -> webhook Fonnte (/webhook/fonnte?key=...), dilindungi kunci rahasia di alamat webhook
const FONNTE_WEBHOOK_KEY = process.env.FONNTE_WEBHOOK_KEY || WA_VERIFY_TOKEN;
const INBOX_ENABLED =
  (PROVIDER === "cloud" && Boolean(WA_APP_SECRET)) || (PROVIDER === "fonnte" && Boolean(FONNTE_WEBHOOK_KEY));

// WA_BOT_MODE: keyword (bawaan) | auto | off. Penjelasan ada di wabot.js.
const BOT_MODE = ["keyword", "auto", "off"].includes(String(process.env.WA_BOT_MODE || "").toLowerCase())
  ? String(process.env.WA_BOT_MODE).toLowerCase()
  : "keyword";
const BOT_ENABLED = INBOX_ENABLED && BOT_MODE !== "off";
// Setelah admin membalas satu nomor, bot diam untuk nomor itu selama sekian jam.
const BOT_PAUSE_HOURS = Math.max(0, Number(process.env.WA_BOT_PAUSE_HOURS) || 12);

// Nama template di Meta (hanya dipakai jalur "cloud"). Bisa diganti lewat .env.
const TEMPLATE_LANG = process.env.WA_TEMPLATE_LANG || "id";
const TEMPLATE_NAMES = {
  welcome: process.env.WA_TEMPLATE_WELCOME || "member_baru",
  claim: process.env.WA_TEMPLATE_CLAIM || "klaim_koin",
  order: process.env.WA_TEMPLATE_ORDER || "pesanan_sukses",
  tierUp: process.env.WA_TEMPLATE_TIERUP || "naik_level",
  test: process.env.WA_TEMPLATE_TEST || "hello_world", // template bawaan Meta untuk tes
};
const TEST_TEMPLATE_LANG = process.env.WA_TEMPLATE_TEST_LANG || "en_US";

// ---------- Format nomor ----------
// WhatsApp Cloud API butuh format internasional tanpa "+", mis. 6281234567890
function toInternationalId(phone) {
  let p = String(phone || "").replace(/\D/g, "");
  if (p.startsWith("0")) p = "62" + p.slice(1);
  else if (!p.startsWith("62")) p = "62" + p;
  return p;
}

// 6281234567890 -> 081234567890 (format lokal, dipakai Fonnte bersama countryCode 62)
function toLocalId(phone) {
  const p = String(phone || "").replace(/\D/g, "");
  return p.startsWith("62") ? "0" + p.slice(2) : p;
}

// 089529705141 -> "0895-2970-5141" (untuk ditampilkan ke manusia)
function formatDisplay(phone) {
  const p = toLocalId(phone);
  return p.replace(/^(\d{4})(\d{4})(\d+)$/, "$1-$2-$3");
}

const BUSINESS_INTL = toInternationalId(BUSINESS_NUMBER); // 6289529705141
const BUSINESS_DISPLAY = formatDisplay(BUSINESS_NUMBER); // 0895-2970-5141

// Link "klik untuk chat" ke nomor bisnis (dipakai tombol WhatsApp di website)
function businessChatUrl(text) {
  return `https://wa.me/${BUSINESS_INTL}` + (text ? `?text=${encodeURIComponent(text)}` : "");
}

// Link chat ke nomor MEMBER dengan pesan siap kirim (cadangan manual: tombol "WA" di halaman admin)
function memberChatUrl(phone, text) {
  return `https://wa.me/${toInternationalId(phone)}` + (text ? `?text=${encodeURIComponent(text)}` : "");
}

// ---------- Isi pesan ----------
const rupiah = (n) => Number(n || 0).toLocaleString("id-ID");

// Variabel template Meta tidak boleh berisi baris baru / tab / 4 spasi berurutan, dan tidak boleh kosong.
function param(v, max = 900) {
  const s = String(v ?? "").replace(/[\r\n\t]+/g, " ").replace(/ {4,}/g, "   ").trim().slice(0, max);
  return s || "-";
}

// Ringkasan keuntungan satu baris, mis. "diskon 5% tiap pesanan, koin belanja x1,5, klaim 30 koin per hari"
function tierSummary(tier) {
  const parts = [
    `koin belanja x${String(tier.orderMultiplier).replace(".", ",")}`,
    `klaim ${tier.dailyClaim} koin per hari`,
  ];
  if (tier.discountPercent > 0) parts.unshift(`diskon ${tier.discountPercent}% tiap pesanan`);
  return parts.join(", ");
}

function perksBullets(tier) {
  return tier.perks.map((p) => `• ${p}`).join("\n");
}

// Info level berikutnya: { next, need } atau null kalau sudah Platinum
function nextTierInfo(koin) {
  const cur = getTier(koin);
  const next = TIERS[TIERS.indexOf(cur) + 1];
  return next ? { next, need: Math.max(0, next.minKoin - koin) } : null;
}

function nextTierLine(koin) {
  const info = nextTierInfo(koin);
  return info
    ? `Kumpulkan ${info.need} koin lagi untuk naik ke level ${info.next.name} (${tierSummary(info.next)}).`
    : "Kamu sudah di level tertinggi, Platinum. Terima kasih sudah jadi member setia! 🎉";
}

function welcomeText(member, urls) {
  const tier = getTier(member.koin || 0);
  const lines = [
    `Halo ${member.name}! 👋`,
    `Selamat datang di Member Gacoan 🍜`,
    ``,
    `Kartu member kamu sudah aktif:`,
    `🆔 ${member.id}`,
    `🏅 Level ${tier.name}`,
    ``,
    `💳 Buka kartu: ${urls.cardUrl}`,
    `📄 Unduh PDF: ${urls.pdfUrl}`,
    ``,
    `Keuntungan level ${tier.name}:`,
    perksBullets(tier),
    ``,
    nextTierLine(member.koin || 0),
    ``,
    `Link di atas pribadi, jangan dibagikan ke orang lain.`,
  ];
  if (BOT_ENABLED) lines.push(`Balas pesan ini dengan KOIN, KEUNTUNGAN, atau KARTU kapan saja. Ada pertanyaan lain? Tulis saja, tim Gacoan akan membalas.`);
  else if (INBOX_ENABLED) lines.push(`Ada pertanyaan? Balas pesan ini, tim Gacoan akan membalas.`);
  return lines.join("\n");
}

function claimText(member, rewardKoin) {
  return [
    `Yeay ${member.name}! 🪙`,
    `Kamu dapat ${rewardKoin} koin Gacoan hari ini.`,
    `Total koin kamu sekarang ${member.koin} (level ${getTier(member.koin || 0).name}).`,
    ``,
    nextTierLine(member.koin || 0),
    `Sampai jumpa besok untuk klaim berikutnya!`,
  ].join("\n");
}

function orderText(member, order) {
  const lines = [
    `Pesanan ${order.id} berhasil ✅`,
    `Total bayar: Rp${rupiah(order.total)}`,
  ];
  if (order.discount > 0) lines.push(`Diskon level ${getTier(member.koin || 0).name}: Rp${rupiah(order.discount)}`);
  lines.push(`Kamu dapat ${order.koinEarned} koin. Total koin sekarang ${member.koin}.`, ``, `Terima kasih sudah makan di Gacoan! 🍜`);
  return lines.join("\n");
}

function tierUpText(member, tierName) {
  const tier = TIERS.find((t) => t.name === tierName) || getTier(member.koin || 0);
  return [
    `Selamat ${member.name}! 🎉`,
    `Level member Gacoan kamu naik menjadi ${tier.name}.`,
    ``,
    `Keuntungan barumu:`,
    perksBullets(tier),
    ``,
    `Terima kasih sudah setia bersama Gacoan!`,
  ].join("\n");
}

// ---------- Penerjemah error supaya admin langsung tahu apa yang harus dibenahi ----------
const CLOUD_HINTS = {
  10: "Token belum punya izin whatsapp_business_messaging.",
  100: "Parameter tidak valid. Cek WA_PHONE_NUMBER_ID.",
  190: "WA_TOKEN kedaluwarsa atau tidak valid. Buat token permanen lewat System User.",
  130429: "Batas kecepatan kirim tercapai. Coba lagi nanti.",
  131026: "Nomor penerima tidak terdaftar di WhatsApp.",
  131030: "Nomor penerima belum masuk daftar penerima uji (mode development). Tambahkan di Meta, atau jadikan app Live.",
  131047: "Sudah lewat 24 jam sejak member terakhir chat, jadi wajib memakai template.",
  131056: "Terlalu banyak pesan ke nomor yang sama. Coba lagi nanti.",
  132000: "Jumlah variabel tidak cocok dengan isi template di Meta.",
  132001: "Template belum dibuat / belum disetujui Meta. Jalankan: npm run wa-setup, lalu tunggu status APPROVED.",
  132012: "Format variabel tidak cocok dengan template di Meta.",
  133010: "Nomor pengirim belum terdaftar di WhatsApp Cloud API.",
};

class WaError extends Error {
  constructor(message, { transient = false } = {}) {
    super(message);
    this.transient = transient;
  }
}

function explainCloudError(code, message) {
  const hint = CLOUD_HINTS[code];
  const base = message || `Error ${code}`;
  return hint ? `${base} → ${hint}` : base;
}

// ---------- HTTP + percobaan ulang ----------
async function http(url, opts) {
  try {
    return await fetch(url, { ...opts, signal: AbortSignal.timeout(20000) });
  } catch (e) {
    throw new WaError(`Koneksi ke server WhatsApp gagal (${(e.cause && e.cause.code) || e.name || e.message})`, { transient: true });
  }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Gangguan sementara (internet putus, server sibuk) dicoba ulang sampai 3 kali.
async function withRetry(fn, tries = 3) {
  let delay = 1500;
  for (let i = 1; ; i++) {
    try {
      return await fn();
    } catch (e) {
      if (!e.transient || i >= tries) throw e;
      await sleep(delay);
      delay *= 3;
    }
  }
}

// ---------- Jalur A: WhatsApp Cloud API (resmi Meta) ----------
async function callGraphApi(payload) {
  const res = await http(`https://graph.facebook.com/${GRAPH_VERSION}/${WA_PHONE_NUMBER_ID}/messages`, {
    method: "POST",
    headers: { Authorization: `Bearer ${WA_TOKEN}`, "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = data && data.error ? data.error : {};
    const detail = (err.error_data && err.error_data.details) || err.message;
    throw new WaError(explainCloudError(err.code, detail || `HTTP ${res.status}`), {
      transient: res.status >= 500 || res.status === 429,
    });
  }
  return data && data.messages && data.messages[0] ? data.messages[0].id : "";
}

function cloudTemplate(phone, name, lang, params = []) {
  return callGraphApi({
    messaging_product: "whatsapp",
    to: toInternationalId(phone),
    type: "template",
    template: {
      name,
      language: { code: lang },
      components: params.length ? [{ type: "body", parameters: params.map((p) => ({ type: "text", text: param(p) })) }] : [],
    },
  });
}

// Teks bebas: HANYA boleh dalam 24 jam sejak member terakhir chat ke nomor bisnis (dipakai bot).
function cloudText(phone, text) {
  return callGraphApi({
    messaging_product: "whatsapp",
    to: toInternationalId(phone),
    type: "text",
    text: { body: text, preview_url: true },
  });
}

// ---------- Jalur B: Fonnte (gateway pihak ketiga) ----------
async function fonnteText(phone, text) {
  const form = new FormData();
  form.append("target", toLocalId(phone));
  form.append("message", text);
  form.append("countryCode", "62");
  const res = await http("https://api.fonnte.com/send", {
    method: "POST",
    headers: { Authorization: FONNTE_TOKEN }, // Fonnte: token langsung, tanpa "Bearer"
    body: form,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.status === false) {
    throw new WaError(`Fonnte: ${data.reason || `HTTP ${res.status}`}`, { transient: res.status >= 500 || res.status === 429 });
  }
  const id = Array.isArray(data.id) ? data.id[0] : data.id;
  return id ? String(id) : "";
}

// ---------- Pengiriman + pencatatan ----------
// spec = { template: { name, params }, text }
//   cloud  -> kirim template (pesan proaktif wajib template)
//   fonnte -> kirim teks lengkap
async function dispatch(kind, member, spec) {
  if (!WA_ENABLED) return { ok: false, skipped: true };
  let logId = null;
  try {
    logId = store.addWaLog({ memberId: member.id, phone: member.phone, kind, provider: PROVIDER, status: "queued" });
  } catch (e) {
    console.error("⚠️  Gagal mencatat log WhatsApp:", e.message);
  }
  try {
    const msgId = await withRetry(() =>
      PROVIDER === "cloud"
        ? cloudTemplate(member.phone, spec.template.name, spec.template.lang || TEMPLATE_LANG, spec.template.params)
        : fonnteText(member.phone, spec.text)
    );
    if (logId) store.updateWaLog(logId, { status: "sent", providerMsgId: msgId || null });
    recordSystemChat(kind, member, spec.text, { status: "sent", providerMsgId: msgId || null });
    console.log(`📲 WhatsApp "${kind}" terkirim ke ${member.phone} (${PROVIDER})`);
    return { ok: true };
  } catch (e) {
    if (logId) {
      try { store.updateWaLog(logId, { status: "failed", error: e.message }); } catch {}
    }
    recordSystemChat(kind, member, spec.text, { status: "failed", error: e.message });
    console.error(`⚠️  Gagal kirim WhatsApp "${kind}" ke ${member.phone}: ${e.message}`);
    return { ok: false, error: e.message };
  }
}

// Pesan otomatis sistem (kartu baru, klaim, pesanan, dst.) ikut tampil di riwayat percakapan admin,
// supaya admin tahu persis apa yang sudah diterima customer sebelum dia membalas.
function recordSystemChat(kind, member, text, result) {
  if (kind === "test" || !member || !member.phone || !text) return;
  try {
    store.addChatMessage({
      phone: toLocalId(member.phone), memberId: member.id, direction: "out", sender: "system",
      body: text, status: result.status, error: result.error, providerMsgId: result.providerMsgId,
    });
  } catch (e) {
    console.error("⚠️  Gagal mencatat percakapan WhatsApp:", e.message);
  }
}

// ---------- Notifikasi siap pakai untuk alur member Gacoan ----------
// urls = { cardUrl, pdfUrl, ... } dari memberUrls() di server.js
function notifyRegistration(member, urls, kind = "welcome") {
  return dispatch(kind, member, {
    template: { name: TEMPLATE_NAMES.welcome, params: [member.name, member.id, urls.cardUrl] },
    text: welcomeText(member, urls),
  });
}

// Kirim ulang kartu (tombol "Kirim ulang" admin & "Sudah Pernah Daftar" pelanggan)
function resendCard(member, urls) {
  return notifyRegistration(member, urls, "resend");
}

function notifyClaim(member, rewardKoin) {
  return dispatch("claim", member, {
    template: { name: TEMPLATE_NAMES.claim, params: [member.name, rewardKoin, member.koin] },
    text: claimText(member, rewardKoin),
  });
}

function notifyOrder(member, order) {
  return dispatch("order", member, {
    template: { name: TEMPLATE_NAMES.order, params: [order.id, rupiah(order.total), order.koinEarned] },
    text: orderText(member, order),
  });
}

function notifyTierUp(member, tierName) {
  const tier = TIERS.find((t) => t.name === tierName) || getTier(member.koin || 0);
  return dispatch("tier_up", member, {
    template: { name: TEMPLATE_NAMES.tierUp, params: [member.name, tier.name, tierSummary(tier)] },
    text: tierUpText(member, tierName),
  });
}

// Tes kirim dari halaman admin: cloud memakai template bawaan Meta "hello_world" (sudah disetujui
// otomatis), jadi bisa dipakai untuk memastikan token & Phone Number ID benar sebelum template buatan sendiri disetujui.
function sendTest(phone) {
  return dispatch("test", { id: null, phone }, {
    template: { name: TEMPLATE_NAMES.test, lang: TEST_TEMPLATE_LANG, params: [] },
    text: `Tes WhatsApp Gacoan ✅\nKalau pesan ini sampai, integrasi nomor ${BUSINESS_DISPLAY} sudah berjalan.`,
  });
}

// Kirim teks bebas (bukan template). Dipakai balasan admin dan balasan bot.
// cloud : HANYA boleh dalam 24 jam sejak customer terakhir chat (aturan Meta).
// fonnte: tidak ada batas 24 jam.
function sendFreeText(phone, text) {
  return PROVIDER === "cloud" ? cloudText(phone, text) : fonnteText(phone, text);
}

// Apakah balasan teks bebas ke percakapan ini masih diizinkan?
// convo = baris wa_convo (butuh lastInboundAt). Mengembalikan { ok, reason }.
function canReplyFreely(convo) {
  if (!WA_ENABLED) return { ok: false, reason: "Chat WhatsApp otomatis belum aktif. Isi WA_TOKEN + WA_PHONE_NUMBER_ID atau FONNTE_TOKEN di .env lalu restart server." };
  if (PROVIDER === "cloud") {
    const last = convo && convo.lastInboundAt ? new Date(convo.lastInboundAt).getTime() : 0;
    if (!last || Date.now() - last > 24 * 3600 * 1000) {
      return {
        ok: false,
        reason: "Sudah lewat 24 jam sejak customer terakhir chat, jadi WhatsApp resmi tidak mengizinkan balasan teks bebas. Pakai tombol \"Kirim ulang kartu\" (template) atau tunggu customer chat lagi.",
      };
    }
  }
  return { ok: true };
}

// Kirim balasan teks bebas + catat ke log dan riwayat percakapan.
// sender: "admin" | "bot"
async function sendChat({ phone, text, memberId, sender = "admin" }) {
  if (!WA_ENABLED) return { ok: false, error: "Chat WhatsApp otomatis belum aktif." };
  const local = toLocalId(phone);
  const kind = sender === "bot" ? "bot" : "admin";
  let logId = null;
  try { logId = store.addWaLog({ memberId, phone: local, kind, provider: PROVIDER, status: "queued" }); } catch {}
  let chat = null;
  try {
    chat = store.addChatMessage({ phone: local, memberId, direction: "out", sender, body: text, status: "queued" });
  } catch (e) {
    console.error("⚠️  Gagal mencatat percakapan WhatsApp:", e.message);
  }
  try {
    const msgId = await withRetry(() => sendFreeText(local, text));
    if (logId) store.updateWaLog(logId, { status: "sent", providerMsgId: msgId || null });
    if (chat && chat.id) store.setChatResult(chat.id, { status: "sent", providerMsgId: msgId || null });
    return { ok: true };
  } catch (e) {
    if (logId) { try { store.updateWaLog(logId, { status: "failed", error: e.message }); } catch {} }
    if (chat && chat.id) { try { store.setChatResult(chat.id, { status: "failed", error: e.message }); } catch {} }
    console.error(`⚠️  Gagal kirim chat WhatsApp (${kind}) ke ${local}: ${e.message}`);
    return { ok: false, error: e.message };
  }
}

// Balasan otomatis bot (dipertahankan sebagai nama lama)
function sendBotReply(phone, text, memberId) {
  return sendChat({ phone, text, memberId, sender: "bot" });
}

// ---------- Webhook Meta ----------
// Verifikasi awal saat alamat webhook didaftarkan di Meta (GET).
// Mengembalikan teks challenge kalau cocok, atau null kalau ditolak.
function verifyChallenge(query) {
  if (WA_VERIFY_TOKEN && query["hub.mode"] === "subscribe" && query["hub.verify_token"] === WA_VERIFY_TOKEN) {
    return query["hub.challenge"] || "";
  }
  return null;
}

// Setiap kiriman webhook ditandatangani Meta dengan App Secret (header X-Hub-Signature-256).
function verifySignature(rawBody, header) {
  if (!WA_APP_SECRET || !rawBody || !header) return false;
  const expected = "sha256=" + crypto.createHmac("sha256", WA_APP_SECRET).update(rawBody).digest("hex");
  const a = Buffer.from(expected);
  const b = Buffer.from(String(header));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

const MEDIA_LABEL = {
  image: "Foto", video: "Video", audio: "Pesan suara", voice: "Pesan suara", document: "Dokumen",
  sticker: "Stiker", location: "Lokasi", contacts: "Kontak",
};

// Proses isi webhook: perbarui status pesan di log, dan teruskan chat masuk ke onMessage({from, text, name}).
async function processWebhook(body, onMessage) {
  const entries = (body && body.entry) || [];
  for (const entry of entries) {
    for (const change of entry.changes || []) {
      const v = change.value || {};

      for (const st of v.statuses || []) {
        const err = st.errors && st.errors[0];
        const reason = err ? explainCloudError(err.code, err.message || err.title) : null;
        try { store.updateWaStatusByMsgId(st.id, st.status, reason); } catch {}
      }

      const contactName = (v.contacts && v.contacts[0] && v.contacts[0].profile && v.contacts[0].profile.name) || "";
      for (const m of v.messages || []) {
        let text = "";
        if (m.type === "text") text = (m.text && m.text.body) || "";
        else if (m.type === "button") text = (m.button && (m.button.text || m.button.payload)) || "";
        else if (m.type === "interactive") {
          const i = m.interactive || {};
          text = (i.button_reply && i.button_reply.title) || (i.list_reply && i.list_reply.title) || "";
        } else if (MEDIA_LABEL[m.type]) {
          // Foto / suara / dokumen dst.: admin cukup tahu jenisnya (isi file dibuka di aplikasi WhatsApp)
          const caption = (m[m.type] && m[m.type].caption) || "";
          text = `[${MEDIA_LABEL[m.type]}]` + (caption ? ` ${caption}` : "");
        }
        try {
          await onMessage({ id: m.id, from: m.from, text, name: contactName, type: m.type });
        } catch (e) { console.error("Webhook WhatsApp:", e.message); }
      }
    }
  }
}

// ---------- Webhook Fonnte (chat masuk saat jalur "fonnte") ----------
// Di fonnte.com -> Device -> Webhook, isi:  https://<alamat-publik>/webhook/fonnte?key=<FONNTE_WEBHOOK_KEY>
// Fonnte tidak menandatangani kirimannya, jadi pengamannya adalah "key" rahasia di alamat tersebut.
function verifyFonnteKey(key) {
  if (!FONNTE_WEBHOOK_KEY || !key) return false;
  const a = crypto.createHash("sha256").update(String(key)).digest();
  const b = crypto.createHash("sha256").update(FONNTE_WEBHOOK_KEY).digest();
  return crypto.timingSafeEqual(a, b);
}

// Bentuk kiriman Fonnte (JSON atau form): sender, message, name / pushname, id, ...
// Dibaca longgar karena Fonnte juga mengirim notifikasi lain (status device) yang tidak berisi pesan.
async function processFonnteWebhook(body, onMessage) {
  const b = body || {};
  const from = String(b.sender || b.from || "").replace(/\D/g, "");
  const message = String(b.message ?? b.text ?? "").trim();
  const url = b.url ? ` ${b.url}` : "";
  const media = b.extension || b.filename ? `[Lampiran${b.filename ? " " + b.filename : ""}]${url}` : "";
  const text = message || media;
  if (!from || !text) return;
  if (toInternationalId(from) === BUSINESS_INTL) return; // abaikan pesan dari nomor bisnis sendiri
  await onMessage({
    id: b.id || b.inboxid ? String(b.id || b.inboxid) : undefined,
    from,
    text,
    name: String(b.pushname || b.name || ""),
    type: message ? "text" : "media",
  });
}

module.exports = {
  WA_ENABLED,
  PROVIDER,
  INBOX_ENABLED,
  BOT_ENABLED,
  BOT_MODE,
  BOT_PAUSE_HOURS,
  BUSINESS_NUMBER,
  BUSINESS_INTL,
  BUSINESS_DISPLAY,
  TEMPLATE_NAMES,
  TEMPLATE_LANG,
  WEBHOOK_VERIFY_READY: Boolean(WA_VERIFY_TOKEN),
  WEBHOOK_SECRET_READY: Boolean(WA_APP_SECRET),
  toInternationalId,
  toLocalId,
  canReplyFreely,
  sendChat,
  verifyFonnteKey,
  processFonnteWebhook,
  FONNTE_WEBHOOK_READY: Boolean(FONNTE_WEBHOOK_KEY),
  businessChatUrl,
  memberChatUrl,
  tierSummary,
  perksBullets,
  nextTierInfo,
  nextTierLine,
  welcomeText,
  notifyRegistration,
  resendCard,
  notifyClaim,
  notifyOrder,
  notifyTierUp,
  sendTest,
  sendBotReply,
  verifyChallenge,
  verifySignature,
  processWebhook,
};

if (!WA_ENABLED) {
  console.log("ℹ️  Chat WhatsApp otomatis belum aktif. Isi WA_TOKEN + WA_PHONE_NUMBER_ID (resmi Meta) atau FONNTE_TOKEN di .env.");
}
